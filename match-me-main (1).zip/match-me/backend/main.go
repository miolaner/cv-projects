package main

import (
	"backend/database"
	"backend/handlers"
	"log"
	"net"
	"net/http"

	_ "github.com/lib/pq" // Import the PostgreSQL driver

	"github.com/gorilla/mux"
	"github.com/joho/godotenv"
	"github.com/rs/cors"
)

// getLocalIP returns the non loopback local IP of the host
func getLocalIP() (string, error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "", err
	}
	for _, address := range addrs {
		// check the address type and if it is not a loopback the display it
		if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String(), nil
			}
		}
	}
	return "", nil
}

func main() {

	// Load environment variables
	if err := godotenv.Load(); err != nil {
		log.Fatal("❌ Error loading .env file")
	}

	// Connect to the database
	database.ConnectDatabase()

	fs := http.FileServer(http.Dir("./static"))

	localIP, err := getLocalIP()
	if err != nil {
		log.Fatalf("Could not determine local IP address: %v", err)
	}

	router := mux.NewRouter()

	// Update these routes
	router.HandleFunc("/login", handlers.Login)
	router.HandleFunc("/home", handlers.Home)
	router.HandleFunc("/logout", handlers.Logout)
	router.HandleFunc("/profile", handlers.Profile)
	router.HandleFunc("/register", handlers.Register)
	router.HandleFunc("/recommendations", handlers.Recommendations)
	router.HandleFunc("/profile/edit", handlers.ProfileEdit)
	router.HandleFunc("/users/{id}", handlers.Users)
	router.HandleFunc("/users/{id}/bio", handlers.Bio)
	router.HandleFunc("/register/data", handlers.RegisterData)
	router.HandleFunc("/like/{id}", handlers.Like)
	router.HandleFunc("/dislike/{id}", handlers.Dislike)
	router.HandleFunc("/connections", handlers.GetConnections)
	router.HandleFunc("/connections/{id}/messages", handlers.GetMessages)
	router.HandleFunc("/messages", handlers.SendMessage)
	router.HandleFunc("/messages/read", handlers.MarkMessagesAsRead).Methods("POST")
	router.HandleFunc("/ws", handlers.HandleWebSocket)
	router.HandleFunc("/me", handlers.Me)
	router.HandleFunc("/me/profile", handlers.MeProfile)
	router.HandleFunc("/me/bio", handlers.MeBio)
	router.HandleFunc("/users/{id}/profile", handlers.UserProfile)
	router.HandleFunc("/connections/{id}", handlers.RemoveConnection).Methods("DELETE")
	router.HandleFunc("/connections/{id}/details", handlers.GetConnectionDetails)
	router.PathPrefix("/static/").Handler(http.StripPrefix("/static/", fs))
	router.HandleFunc("/pending", handlers.GetPendingConnections)

	handler := cors.New(cors.Options{
		AllowedOrigins:   []string{"http://localhost:3000", "http://" + localIP + ":3000", "ws://localhost:3000", "ws://" + localIP + ":3000"},
		AllowCredentials: true,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Authorization", "Content-Type", "Upgrade", "Connection"},
	}).Handler(router)

	log.Printf("Server started at http://%s:8000", localIP)
	log.Fatal(http.ListenAndServe(":8000", handler))
}
