package database

import (
	"time"

	"github.com/lib/pq"
	"gorm.io/gorm"
)

// User model
type User struct {
	gorm.Model
	UserID            uint
	Username          string `gorm:"unique;not null"`
	Email             string `gorm:"unique;not null"`
	PasswordHash      string `gorm:"not null"`
	ProfilePictureURL string
	ProfileID         uint
	Profile           Profile `gorm:"foreignKey:ProfileID"`
}

// Profile model
type Profile struct {
	ID      uint
	AboutMe string
	BioID   uint
	Bio     Bio `gorm:"foreignKey:BioID"`
}

// Bio struct
type Bio struct {
	ID                     uint
	Interests              pq.StringArray `gorm:"type:text[]"` // Use text[] type for Interests. Needs to be pq.StringArray for GORM
	Gender                 string
	LookingForGender       string
	LookingForLocations    pq.StringArray `gorm:"type:text[]"`
	LookingForAgeRange     pq.Int64Array  `gorm:"type:integer[]"`
	LookingForProfessional bool
	Age                    int
	Location               string
}

// Connection model
type Connection struct {
	gorm.Model
	User1ID  uint
	User2ID  uint
	Status   string    // pending, accepted, rejected
	Messages []Message // Add this to establish relationship with messages
}

// Message model
type Message struct {
	gorm.Model
	ConnectionID uint
	SenderID     uint
	Content      string
	ReadAt       *time.Time
	Status       string `gorm:"default:'sent'"` // 'sent', 'delivered', 'read'
}

// UserReaction model
type UserReaction struct {
	gorm.Model
	UserID uint `gorm:"not null;index"` // User who liked or disliked
	DestID uint `gorm:"not null;index"` // User who was liked or disliked
	Like   bool
}
