package database

import (
	"log"
	"math/rand"
	"time"

	"github.com/bxcodec/faker/v3"
	"github.com/lib/pq"
	"golang.org/x/crypto/bcrypt"
)

// Avatar URLs
var maleAvatarURL = "/static/avatars/male_avatar.png"
var femaleAvatarURL = "/static/avatars/female_avatar.png"

// Sample data for cities and interests
var allCities = []string{
	"Helsinki, Uusimaa", "Espoo, Uusimaa", "Tampere, Pirkanmaa", "Vantaa, Uusimaa",
	"Oulu, North Ostrobothnia", "Turku, Southwest Finland", "Jyväskylä, Central Finland",
	"Lahti, Päijät-Häme", "Kuopio, Northern Savonia", "Kouvola, Kymenlaakso",
	"Pori, Satakunta", "Joensuu, North Karelia", "Lappeenranta, South Karelia",
	"Hämeenlinna, Kanta-Häme", "Vaasa, Ostrobothnia", "Rovaniemi, Lapland",
	"Seinäjoki, South Ostrobothnia", "Mikkeli, South Savonia", "Kotka, Kymenlaakso",
	"Salo, Southwest Finland", "Porvoo, Uusimaa", "Kokkola, Central Ostrobothnia",
	"Lohja, Uusimaa", "Hyvinkää, Uusimaa", "Järvenpää, Uusimaa", "Nurmijärvi, Uusimaa",
	"Rauma, Satakunta", "Kirkkonummi, Uusimaa", "Tuusula, Uusimaa", "Kajaani, Kainuu",
	"Savonlinna, South Savonia", "Riihimäki, Kanta-Häme", "Vihti, Uusimaa",
	"Raisio, Southwest Finland", "Karhula, Kymenlaakso", "Raahe, North Ostrobothnia",
	"Ylöjärvi, Pirkanmaa", "Hamina, Kymenlaakso", "Kaarina, Southwest Finland",
	"Tornio, Lapland", "Heinola, Päijät-Häme", "Hollola, Päijät-Häme",
	"Valkeakoski, Pirkanmaa", "Siilinjärvi, Northern Savonia", "Kuusamo, North Ostrobothnia",
	"Sastamala, Pirkanmaa", "Kemi, Lapland", "Iisalmi, Northern Savonia",
	"Varkaus, Northern Savonia", "Mäntsälä, Uusimaa", "Forssa, Kanta-Häme",
	"Kangasala, Pirkanmaa", "Pietarsaari, Ostrobothnia", "Imatra, South Karelia",
	"Naantali, Southwest Finland", "Kauhajoki, South Ostrobothnia", "Uusikaupunki, Southwest Finland",
	"Kankaanpää, Satakunta", "Orimattila, Päijät-Häme", "Lieto, Southwest Finland",
	"Nokia, Pirkanmaa", "Keuruu, Central Finland", "Pieksämäki, South Savonia",
	"Jämsä, Central Finland", "Outokumpu, North Karelia", "Kitee, North Karelia",
	"Lieksa, North Karelia", "Nurmes, North Karelia", "Kontiolahti, North Karelia",
	"Liperi, North Karelia", "Polvijärvi, North Karelia", "Ilomantsi, North Karelia",
	"Juuka, North Karelia", "Tohmajärvi, North Karelia", "Rääkkylä, North Karelia",
	"Kuhmo, Kainuu", "Sotkamo, Kainuu", "Paltamo, Kainuu", "Ristijärvi, Kainuu",
	"Hyrynsalmi, Kainuu", "Suomussalmi, Kainuu", "Puolanka, Kainuu", "Vaala, Kainuu",
}

var allInterests = []string{
	// Ball Games
	"Football", "Basketball", "Volleyball", "Tennis", "Baseball",
	"Cricket", "Rugby", "Handball", "Softball", "Dodgeball",

	// Water Sports
	"Swimming", "Surfing", "Water Polo", "Diving", "Rowing",
	"Sailing", "Kayaking", "Snorkeling", "Scuba Diving", "Wakeboarding",

	// Outdoor Activities
	"Hiking", "Cycling", "Camping", "Rock Climbing", "Fishing",
	"Bird Watching", "Geocaching", "Orienteering", "Trail Running", "Backpacking",

	// Indoor Activities
	"Reading", "Painting", "Chess", "Cooking", "Yoga",
	"Knitting", "Scrapbooking", "Model Building", "Board Games", "Puzzles",

	// Music
	"Playing Guitar", "Playing Piano", "Singing", "Drumming", "Composing",
	"Playing Violin", "Playing Flute", "Playing Saxophone", "Playing Trumpet", "Playing Cello",

	// Card Games
	"Poker", "Bridge", "Hearts", "Spades", "Blackjack",
	"Solitaire", "Uno", "Go Fish", "Canasta", "Rummy",

	// Board Games
	"Monopoly", "Chess", "Checkers", "Settlers of Catan", "Clue",
	"Trivial Pursuit", "Ticket to Ride", "Carcassonne", "The Game of Life", "Scattergories",

	// Team Sports
	"Soccer", "Basketball", "Baseball", "Volleyball", "Rugby",
	"Cricket", "Field Hockey", "Ice Hockey", "Handball", "Ultimate Frisbee",

	// Racquet Sports
	"Tennis", "Badminton", "Squash", "Table Tennis", "Paddle Tennis",
	"Pickleball", "Racquetball", "Beach Tennis", "Platform Tennis", "Speedminton",

	// Dance
	"Ballroom Dancing", "Salsa", "Hip Hop", "Ballet", "Contemporary",
	"Tango", "Tap Dance", "Jazz Dance", "Folk Dance", "Line Dance",

	// Martial Arts
	"Karate", "Taekwondo", "Judo", "Jiu-Jitsu", "Kung Fu",
	"Aikido", "Muay Thai", "Krav Maga", "Capoeira", "Sambo",

	// Fitness
	"Running", "Weightlifting", "CrossFit", "Pilates", "Spinning",
	"Zumba", "Bodybuilding", "Calisthenics", "HIIT", "Stretching",

	// Crafts
	"Knitting", "Crocheting", "Quilting", "Sewing", "Embroidery",
	"Woodworking", "Pottery", "Jewelry Making", "Glass Blowing", "Leatherworking",

	// Collecting
	"Stamp Collecting", "Coin Collecting", "Antique Collecting", "Comic Book Collecting", "Art Collecting",
	"Card Collecting", "Autograph Collecting", "Vintage Toy Collecting", "Shell Collecting", "Rock Collecting",

	// Technology
	"Programming", "Robotics", "3D Printing", "Electronics", "Drone Flying",
	"Virtual Reality", "Augmented Reality", "App Development", "Web Development", "Game Development",

	// Writing
	"Creative Writing", "Poetry", "Journalism", "Blogging", "Screenwriting",
	"Technical Writing", "Copywriting", "Editing", "Grant Writing", "Travel Writing",

	// Gardening
	"Vegetable Gardening", "Flower Gardening", "Herb Gardening", "Container Gardening", "Hydroponic Gardening",
	"Organic Gardening", "Indoor Gardening", "Community Gardening", "Landscape Gardening", "Bonsai Gardening",

	// Photography
	"Portrait Photography", "Landscape Photography", "Wildlife Photography", "Macro Photography", "Street Photography",
	"Astrophotography", "Event Photography", "Travel Photography", "Underwater Photography", "Architectural Photography",

	// Travel
	"Backpacking", "Camping", "Road Trips", "Cruising", "Adventure Travel",
	"Ecotourism", "Cultural Travel", "Food Travel", "Historical Travel", "Volunteer Travel",
}

var genders = []string{"Male", "Female"}
var lookingForGenders = []string{"Male", "Female", "any"}

// SeedLargeDatabase creates diverse fake users
func SeedLargeDatabase(count int) {
	rand.Seed(time.Now().UnixNano())

	for i := 0; i < count; i++ {
		passwordHash, _ := bcrypt.GenerateFromPassword([]byte("password123"), bcrypt.DefaultCost)

		gender := randomItem(genders) // Randomly assign male or female

		user := User{
			Username:          faker.Username(),
			Email:             faker.Email(),
			PasswordHash:      string(passwordHash),
			ProfilePictureURL: selectAvatarByGender(gender), // Gender-based avatar
			Profile: Profile{
				AboutMe: faker.Sentence(),
				Bio: Bio{
					Interests:              pickRandomItems(allInterests, rand.Intn(4)+3),
					Gender:                 gender,
					LookingForGender:       randomItem(lookingForGenders),
					LookingForAgeRange:     randomLookingForAgeRange(),
					LookingForProfessional: randomProfessionalStatus(),
					Age:                    randomAge(),
					Location:               randomItem(allCities),
				},
			},
		}
		DB.Create(&user)

	}

	log.Printf("✅ Seeded %d diverse fake users with gender-based avatars.\n", count)
}

// Helper function to choose avatar based on gender
func selectAvatarByGender(gender string) string {
	if gender == "Male" {
		return maleAvatarURL
	}
	return femaleAvatarURL
}

// Helper to pick a random item from a list
func randomItem(list []string) string {
	return list[rand.Intn(len(list))]
}

// Helper to pick multiple random items
func pickRandomItems(list []string, count int) []string {
	rand.Shuffle(len(list), func(i, j int) {
		list[i], list[j] = list[j], list[i]
	})
	return list[:count]
}

// Helper to generate a random age between 18 and 99
func randomAge() int {
	return rand.Intn(82) + 18
}

// Helper to generate a random looking for age range
func randomLookingForAgeRange() pq.Int64Array {
	minAge := rand.Intn(10) + 18
	maxAge := rand.Intn(40) + minAge
	if maxAge > 99 {
		maxAge = 99
	}
	return pq.Int64Array{int64(minAge), int64(maxAge)}
}

// Helper to determine if the user is a professional player
func randomProfessionalStatus() bool {
	return rand.Intn(2) == 0
}
