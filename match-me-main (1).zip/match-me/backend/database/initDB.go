package database

import (
	"fmt"
	"log"
	"os"

	"github.com/lib/pq"
	_ "github.com/lib/pq"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var DB *gorm.DB

func ConnectDatabase() {
	dsn := fmt.Sprintf(
		"host=%s user=%s password=%s dbname=%s port=%s sslmode=disable",
		os.Getenv("DB_HOST"),
		os.Getenv("DB_USER"),
		os.Getenv("DB_PASSWORD"),
		os.Getenv("DB_NAME"),
		os.Getenv("DB_PORT"),
	)

	var err error
	DB, err = gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatal("❌ Failed to connect to the database:", err)
	}

	log.Println("✅ Database connected successfully!")

	// Auto migrate schema
	autoMigrateSchema()

	// Seed admin user
	seedAdminUser()
}

func autoMigrateSchema() {
	err := DB.AutoMigrate(&User{}, &Profile{}, &Connection{}, &Message{}, &UserReaction{}, &Bio{})
	if err != nil {
		log.Fatal("❌ Failed to migrate database schema:", err)
	}
	log.Println("✅ Database schema migrated successfully!")
}

func seedAdminUser() {
	var admin User
	hashedPassword, _ := bcrypt.GenerateFromPassword([]byte(os.Getenv("ADMIN_PASSWORD")), bcrypt.DefaultCost)
	result := DB.Preload("Profile.Bio").First(&admin, "username = ?", "admin")

	if result.Error == nil {
		// Update the existing admin user
		admin.Email = "admin@example.com"
		admin.PasswordHash = string(hashedPassword)
		admin.ProfilePictureURL = "/static/avatars/male_avatar.png"
		admin.Profile.AboutMe = "This is the admin profile.asdfasdf"
		admin.Profile.Bio.Interests = pq.StringArray{"Football", "Surfing", "Camping", "Poker", "Tennis"}
		admin.Profile.Bio.Location = "Kuopio"
		admin.Profile.Bio.Gender = "Male"
		admin.Profile.Bio.LookingForGender = "Any"
		admin.Profile.Bio.LookingForLocations = pq.StringArray{"Helsinki", "Espoo"}
		admin.Profile.Bio.LookingForAgeRange = pq.Int64Array{18, 99}
		admin.Profile.Bio.LookingForProfessional = false
		admin.Profile.Bio.Age = 30
		DB.Save(&admin.Profile.Bio)
		DB.Save(&admin.Profile)
		DB.Save(&admin)
		log.Println("✅ Admin user updated.")
	} else {
		// Create the admin user
		admin = User{
			Username:          "admin",
			Email:             "admin@example.com",
			PasswordHash:      string(hashedPassword),
			ProfilePictureURL: "/static/avatars/male_avatar.png",
			Profile: Profile{
				AboutMe: "This is the admin profile.",
				Bio: Bio{
					Interests:              pq.StringArray{"Football", "Surfing", "Camping", "Poker", "Tennis"},
					Location:               "Kuopio",
					Gender:                 "Male",
					LookingForGender:       "Any",
					LookingForLocations:    pq.StringArray{"Helsinki", "Espoo"},
					LookingForAgeRange:     pq.Int64Array{18, 99},
					LookingForProfessional: false,
					Age:                    30,
				},
			},
		}
		DB.Create(&admin)
		log.Println("✅ Admin user created.")
	}
}
