package handlers

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/dgrijalva/jwt-go"
)

func validateJWT(w http.ResponseWriter, r *http.Request) (bool, *jwt.Token, string, *Claims) {
	authHeader := r.Header.Get("Authorization")
	if authHeader == "" {
		http.Error(w, "Not Found", http.StatusNotFound)
		fmt.Println("Authorization header missing")
		return false, nil, "", nil
	}

	// Extract the Bearer token from the Authorization header
	tokenString := strings.TrimPrefix(authHeader, "Bearer ")
	if tokenString == authHeader {
		http.Error(w, "Not Found", http.StatusNotFound)
		fmt.Println("Bearer token missing")
		return false, nil, "", nil
	}

	// Check if the token has the correct number of segments
	if len(strings.Split(tokenString, ".")) != 3 {
		http.Error(w, "Invalid token format", http.StatusUnauthorized)
		fmt.Println("Invalid token format:", tokenString)
		return false, nil, "", nil
	}

	claims := &Claims{}

	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return secret, nil
	})
	if err != nil || !token.Valid {
		http.Error(w, "Not Found", http.StatusNotFound)
		fmt.Println("Error parsing token:", err)
		return false, nil, "", nil
	}

	return true, token, tokenString, claims
}
