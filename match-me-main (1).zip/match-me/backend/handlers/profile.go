package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"
)

func Profile(w http.ResponseWriter, r *http.Request) {
	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	// Query the database for the user and profile information
	var user database.User
	err := database.DB.Preload("Profile.Bio").Where("username = ?", claims.Username).First(&user).Error
	if err != nil {
		http.Error(w, "Database error", http.StatusInternalServerError)
		fmt.Println("Database error:", err)
		return
	}

	// Create a response with the user and profile information
	response := map[string]interface{}{
		"username":           user.Username,
		"email":              user.Email,
		"aboutMe":            user.Profile.AboutMe,
		"profileImage":       user.ProfilePictureURL,
		"interests":          user.Profile.Bio.Interests,
		"location":           user.Profile.Bio.Location,
		"gender":             user.Profile.Bio.Gender,
		"lookingForGender":   user.Profile.Bio.LookingForGender,
		"professional":       user.Profile.Bio.LookingForProfessional,
		"age":                user.Profile.Bio.Age,
		"lookingForAgeRange": user.Profile.Bio.LookingForAgeRange,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	fmt.Printf("Got Profile request from %s\n", claims.Username)
}
