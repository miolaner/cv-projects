package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strconv"

	"github.com/lib/pq"
)

func ProfileEdit(w http.ResponseWriter, r *http.Request) {
	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	// Handle GET request to fetch interests and locations
	if r.Method == http.MethodGet {
		interests, err := getInterests()
		if err != nil {
			fmt.Println("Failed to load interests:", err)
			http.Error(w, "Failed to load interests", http.StatusInternalServerError)
			return
		}

		locations, err := getLocations()
		if err != nil {
			fmt.Println("Failed to load locations:", err)
			http.Error(w, "Failed to load locations", http.StatusInternalServerError)
			return
		}

		response := map[string]interface{}{
			"interests": interests,
			"locations": locations,
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(response)
		return
	}

	fmt.Println("ProfileEdit handler called")

	// Handle POST request to update profile
	if r.Method == http.MethodPost {
		err := r.ParseMultipartForm(10 << 20) // 10 MB
		if err != nil {
			http.Error(w, "Failed to parse form data", http.StatusBadRequest)
			fmt.Println("Failed to parse form data:", err)
			return
		}

		var profileData database.Profile
		profileData.AboutMe = r.FormValue("aboutMe")

		// Check length of "About Me"
		if len(profileData.AboutMe) > 50 {
			http.Error(w, "About Me section exceeds 50 characters", http.StatusBadRequest)
			return
		}

		var bioData database.Bio
		bioData.Location = r.FormValue("location")
		bioData.Gender = r.FormValue("gender")
		bioData.LookingForGender = r.FormValue("lookingForGender")
		bioData.LookingForProfessional = r.FormValue("professional") == "Yes"
		bioData.Age, _ = strconv.Atoi(r.FormValue("age"))

		interests := r.FormValue("interests")
		if err := json.Unmarshal([]byte(interests), &bioData.Interests); err != nil {
			http.Error(w, "Invalid interests data", http.StatusBadRequest)
			fmt.Println("Invalid interests data:", err)
			return
		}

		// Check number of interests
		if len(bioData.Interests) > 20 {
			http.Error(w, "Number of interests exceeds 20", http.StatusBadRequest)
			return
		}

		var ageRange struct {
			Min interface{} `json:"min"`
			Max interface{} `json:"max"`
		}
		lookingForAgeRange := r.FormValue("lookingForAgeRange")
		fmt.Println("Looking for age range:", lookingForAgeRange)
		if err := json.Unmarshal([]byte(lookingForAgeRange), &ageRange); err != nil {
			http.Error(w, "Invalid looking for age range data", http.StatusBadRequest)
			fmt.Println("Invalid looking for age range data:", err)
			return
		}

		minAge, err := parseAge(ageRange.Min)
		if err != nil {
			http.Error(w, "Invalid min age value", http.StatusBadRequest)
			fmt.Println("Invalid min age value:", err)
			return
		}

		maxAge, err := parseAge(ageRange.Max)
		if err != nil {
			http.Error(w, "Invalid max age value", http.StatusBadRequest)
			fmt.Println("Invalid max age value:", err)
			return
		}

		// Check if min age is lower than max age
		if minAge >= maxAge {
			http.Error(w, "Min age must be lower than max age", http.StatusBadRequest)
			return
		}

		if minAge < 18 || maxAge > 100 {
			http.Error(w, "Age range must be between 18 and 100", http.StatusBadRequest)
			return
		}

		bioData.LookingForAgeRange = pq.Int64Array{minAge, maxAge}

		var user database.User
		err = database.DB.Preload("Profile.Bio").Where("username = ?", claims.Username).First(&user).Error
		if err != nil {
			http.Error(w, "User not found", http.StatusNotFound)
			return
		}

		// Check length of username
		if len(user.Username) > 25 {
			http.Error(w, "Username exceeds 25 characters", http.StatusBadRequest)
			return
		}

		user.Profile.AboutMe = profileData.AboutMe
		user.Profile.Bio.Interests = bioData.Interests
		user.Profile.Bio.Location = bioData.Location
		user.Profile.Bio.Gender = bioData.Gender
		user.Profile.Bio.LookingForGender = bioData.LookingForGender
		user.Profile.Bio.LookingForProfessional = bioData.LookingForProfessional
		user.Profile.Bio.Age = bioData.Age
		user.Profile.Bio.LookingForAgeRange = bioData.LookingForAgeRange

		// Check if user wants to remove profile picture
		removeProfilePic := r.FormValue("removeProfilePic")

		fmt.Println("Remove profile pic:", removeProfilePic)
		if removeProfilePic == "true" {
			// If the user has a profile picture, delete the file
			if user.ProfilePictureURL != "" {
				// Only attempt to delete if it's not a default profile picture
				if !isDefaultProfilePicture(user.ProfilePictureURL) {
					// Try to delete the file, but don't error if it fails
					_ = os.Remove(user.ProfilePictureURL)
				}
			}

			// Set a default profile picture based on gender
			if user.Profile.Bio.Gender == "Male" {
				user.ProfilePictureURL = "/static/avatars/male_avatar.png"
			} else if user.Profile.Bio.Gender == "Female" {
				user.ProfilePictureURL = "/static/avatars/female_avatar.png"
			} else {
				user.ProfilePictureURL = "/static/defaults/default_generic.png"
			}
		} else {

			fmt.Println("New profile pic")
			// Handle profile picture upload
			file, handler, err := r.FormFile("profilePic")
			if err == nil {
				defer file.Close()

				// If user is uploading a new profile pic, delete the old one if it exists
				if user.ProfilePictureURL != "" && !isDefaultProfilePicture(user.ProfilePictureURL) {
					_ = os.Remove(user.ProfilePictureURL)
				}

				uploadDir := "static/uploads"
				if err := os.MkdirAll(uploadDir, os.ModePerm); err != nil {
					http.Error(w, "Failed to create upload directory", http.StatusInternalServerError)
					fmt.Println("Failed to create upload directory:", err)
					return
				}
				filePath := filepath.Join(uploadDir, fmt.Sprintf("%s_%s", user.Username, handler.Filename))
				out, err := os.Create(filePath)
				if err != nil {
					http.Error(w, "Failed to save profile picture", http.StatusInternalServerError)
					fmt.Println("Failed to save profile picture:", err)
					return
				}
				defer out.Close()
				_, err = out.ReadFrom(file)
				if err != nil {
					http.Error(w, "Failed to save profile picture", http.StatusInternalServerError)
					fmt.Println("Failed to save profile picture:", err)
					return
				}
				user.ProfilePictureURL = filePath
			}
		}

		if err := database.DB.Save(&user).Error; err != nil {
			http.Error(w, "Failed to save user", http.StatusInternalServerError)
			fmt.Println("Failed to save user:", err)
			return
		}

		// Save the updated profile
		if err := database.DB.Save(&user.Profile).Error; err != nil {
			http.Error(w, "Failed to save profile", http.StatusInternalServerError)
			fmt.Println("Failed to save profile:", err)
			return
		}

		if err := database.DB.Save(&user.Profile.Bio).Error; err != nil {
			http.Error(w, "Failed to save profile bio", http.StatusInternalServerError)
			fmt.Println("Failed to save profile bio:", err)
			return
		}

		// Return the updated profile picture URL
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"profileImage": user.ProfilePictureURL,
		})
	}
}

// Helper function to check if a profile picture is a default one
func isDefaultProfilePicture(url string) bool {
	defaultPaths := []string{
		"/static/avatars/male_avatar.png",
		"/static/avatars/female_avatar.png",
	}

	for _, path := range defaultPaths {
		if url == path {
			return true
		}
	}
	return false
}

// Helper function to parse age from string or number
func parseAge(value interface{}) (int64, error) {
	switch v := value.(type) {
	case string:
		return strconv.ParseInt(v, 10, 64)
	case float64:
		return int64(v), nil
	default:
		return 0, fmt.Errorf("invalid type for age: %T", v)
	}
}
