package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"time"

	"github.com/dgrijalva/jwt-go"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// JWT secret key
var secret = []byte(os.Getenv("JWT_SECRET"))

type Credentials struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type Claims struct {
	Username string `json:"username"`
	Id       uint   `json:"id"`
	jwt.StandardClaims
}

func Login(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Login handler called")

	var creds Credentials
	if err := json.NewDecoder(r.Body).Decode(&creds); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		fmt.Println("Invalid request:", err)
		return
	}

	// Query the database for the user using GORM
	var user database.User
	err := database.DB.Where("username = ?", creds.Username).First(&user).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			http.Error(w, "Invalid user", http.StatusUnauthorized)
			fmt.Println("Invalid user credentials")
		} else {
			http.Error(w, "Database error", http.StatusInternalServerError)
			fmt.Println("Database error:", err)
		}
		return
	}

	// Compare hashed passwords
	err = bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(creds.Password))
	if err != nil {
		http.Error(w, "Invalid user", http.StatusUnauthorized)
		fmt.Println("Invalid user credentials")
		return
	}

	// Generate JWT token
	expirationTime := time.Now().Add(260 * time.Minute)
	claims := &Claims{
		Username: creds.Username,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(secret)
	if err != nil {
		http.Error(w, "Could not generate token", http.StatusInternalServerError)
		fmt.Println("Could not generate token:", err)
		return
	}

	// Set JWT in cookies
	cookie := &http.Cookie{
		Name:     "token",
		Value:    tokenString,
		Expires:  expirationTime,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteNoneMode, // Ensure the cookie is accessible
		Secure:   true,                  // Set to true if using HTTPS
	}
	http.SetCookie(w, cookie)

	fmt.Printf("Set cookie: %v\n", cookie)

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"token": tokenString})

	fmt.Printf("User %s logged in successfully\n", creds.Username)
}
