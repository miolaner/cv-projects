package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

type UserResponse struct {
	ID                uint   `json:"id"`
	Username          string `json:"username"`
	ProfilePictureURL string `json:"profilePicURL"`
}

func Users(w http.ResponseWriter, r *http.Request) {
	// Log the request headers for debugging
	fmt.Println("Request Headers:", r.Header)

	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	vars := mux.Vars(r)
	id := vars["id"]

	fmt.Println("ID: ", id) //

	if canSeeProfile(claims, r) {

		// For chat functionality - handle numeric IDs
		if userID, err := strconv.ParseUint(id, 10, 64); err == nil {
			var user database.User
			if err := database.DB.Preload("Profile.Bio").First(&user, userID).Error; err != nil {
				http.Error(w, "User not found", http.StatusNotFound)
				return
			}

			response := UserResponse{
				ID:                user.ID,
				Username:          user.Username,
				ProfilePictureURL: user.ProfilePictureURL,
			}

			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(response)
			return
		} else {
			http.Error(w, "Not Found", http.StatusNotFound)
			return
		}
	}

	// Original functionality for other pages
	if canSeeProfile(claims, r) { // keeping the original condition structure
		if r.Method == http.MethodGet {
			idint, err := strconv.Atoi(id)
			if err != nil {
				http.Error(w, "Invalid ID format", http.StatusBadRequest)
				return
			}

			var user database.User
			err = database.DB.Preload("Profile.Bio").Where("id = ?", idint).First(&user).Error
			if err != nil {
				http.Error(w, "Failed to load user", http.StatusInternalServerError)
				fmt.Println("Failed to load user:", err)
				return
			}

			response := map[string]interface{}{
				"username":          user.Username,
				"ProfilePictureURL": user.ProfilePictureURL,
				"profile":           user.Profile,
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(response)
			return
		} else {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
	} else {
		http.Error(w, "Not Found", http.StatusNotFound)
		return
	}
}

func Bio(w http.ResponseWriter, r *http.Request) {
	// Log the request headers for debugging
	fmt.Println("Request Headers:", r.Header)

	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	if canSeeProfile(claims, r) {
		// Handle GET request to fetch interests and locations
		if r.Method == http.MethodGet {
			id := getID(w, r)
			fmt.Println("ID: ", id)
			var user database.User
			err := database.DB.Preload("Profile.Bio").Where("id = ?", id).First(&user).Error
			if err != nil {
				http.Error(w, "Failed to load user", http.StatusInternalServerError)
				fmt.Println("Failed to load user:", err)
				return
			}

			response := map[string]interface{}{
				"bio": user.Profile.Bio,
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(response)
			return
		} else {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
	} else {
		http.Error(w, "Not Found", http.StatusNotFound)
		return
	}
}

func getID(w http.ResponseWriter, r *http.Request) int {

	vars := mux.Vars(r)
	id := vars["id"]

	idint, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID format", http.StatusBadRequest)
		return -1
	}

	return idint
}

func canSeeProfile(claims *Claims, r *http.Request) bool {
	// Add logic to check if the user can see the profile
	// Check if the user is the same as the requested user

	fmt.Println("Claims: ", claims.Username)

	// Check if the user is an admin
	if claims.Username == "admin" {
		return true
	}

	fmt.Println("Not admin")

	// Get ID of the claims username
	var user database.User
	err := database.DB.Where("username = ?", claims.Username).First(&user).Error
	if err != nil {
		fmt.Println("Failed to load user:", err)
		return false
	}

	vars := mux.Vars(r)
	userID, _ := strconv.Atoi(vars["id"])

	if user.ID == uint(userID) {
		return true
	}

	fmt.Println("Not same user ", userID, " ", user.ID)

	// Check to see if in connections
	var connection database.Connection
	err = database.DB.Where("(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)", user.ID, userID, userID, user.ID).First(&connection).Error
	if err == nil {
		return true
	}

	fmt.Println("Not in connections")

	// Check to see if has UserReaction
	var reaction database.UserReaction
	err = database.DB.Where("user_id = ? AND dest_id = ?", user.ID, userID).First(&reaction).Error
	if err == nil {
		return true
	}

	fmt.Println("Not in reactions")

	// Check if the other user has liked this user
	err = database.DB.Where("user_id = ? AND dest_id = ? AND \"like\" = true", userID, user.ID).First(&reaction).Error
	if err == nil {
		return true
	}

	fmt.Println("Other user has not liked this user")

	// Check if in recommendations
	listOfRecommendationIDs, err := SortRecommendations(claims)
	if err != nil {
		fmt.Println("Failed to sort recommendations:", err)
		return false
	}

	if contains(listOfRecommendationIDs, uint(userID)) {
		return true
	}

	fmt.Println("Cannot see the profile")

	return false
}

func Me(w http.ResponseWriter, r *http.Request) {
	// Log the request headers for debugging
	fmt.Println("Request Headers:", r.Header)

	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	var user database.User
	if err := database.DB.Preload("Profile.Bio").Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	response := UserResponse{
		ID:       user.ID,
		Username: user.Username,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func MeProfile(w http.ResponseWriter, r *http.Request) {
	// Log the request headers for debugging
	fmt.Println("Request Headers:", r.Header)

	type UserResponseProfile struct {
		ID      uint   `json:"id"`
		AboutMe string `json:"aboutMe"`
	}

	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	var user database.User
	if err := database.DB.Preload("Profile.Bio").Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	response := UserResponseProfile{
		ID:      user.ID,
		AboutMe: user.Profile.AboutMe,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func MeBio(w http.ResponseWriter, r *http.Request) {
	// Log the request headers for debugging
	fmt.Println("Request Headers:", r.Header)

	type UserResponseBio struct {
		ID                     uint `json:"id"`
		Gender                 string
		Location               string
		Interests              []string
		LookingForAgeRange     []int64
		LookingForProfessional bool
	}

	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	var user database.User
	if err := database.DB.Preload("Profile.Bio").Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	response := UserResponseBio{
		ID:                     user.ID,
		Gender:                 user.Profile.Bio.Gender,
		Location:               user.Profile.Bio.Location,
		Interests:              user.Profile.Bio.Interests,
		LookingForAgeRange:     user.Profile.Bio.LookingForAgeRange,
		LookingForProfessional: user.Profile.Bio.LookingForProfessional,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func UserProfile(w http.ResponseWriter, r *http.Request) {
	// Log the request headers for debugging
	fmt.Println("Request Headers:", r.Header)

	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	vars := mux.Vars(r)
	userID := vars["id"]

	if canSeeProfile(claims, r) {
		if r.Method == http.MethodGet {
			idint, err := strconv.Atoi(userID)
			if err != nil {
				http.Error(w, "Invalid ID format", http.StatusBadRequest)
				return
			}

			var user database.User
			err = database.DB.Preload("Profile.Bio").Where("id = ?", idint).First(&user).Error
			if err != nil {
				http.Error(w, "Failed to load user", http.StatusInternalServerError)
				fmt.Println("Failed to load user:", err)
				return
			}

			response := map[string]interface{}{
				"id":      user.ID,
				"aboutMe": user.Profile.AboutMe,
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(response)
			return
		} else {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
	} else {
		http.Error(w, "Not Found", http.StatusNotFound)
		return
	}

}
