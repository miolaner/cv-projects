package handlers

import (
	"backend/database"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

func Like(w http.ResponseWriter, r *http.Request) {
	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	// Get the user ID from the claims
	userID, _ := GetUserIDByUsername(claims.Username)

	// Get the destination ID from the URL
	vars := mux.Vars(r)
	destID := vars["id"]
	fmt.Println("User: ", userID, " Liked: ", destID)

	// Log the request data
	fmt.Println("Request data: ", r.Body)

	// Check if the user has already liked the destination
	var userReaction database.UserReaction
	result := database.DB.Where("user_id = ? AND dest_id = ?", userID, destID).First(&userReaction)
	if result.Error == nil {
		// User has already liked the destination
		http.Error(w, "User has already liked the destination", http.StatusBadRequest)
		return
	}

	destIDint, err := strconv.Atoi(destID)
	if err != nil {
		http.Error(w, "Failed to convert destination ID to integer", http.StatusInternalServerError)
		fmt.Println("Failed to convert destination ID to integer:", err)
		return
	}

	userIDint := int(userID)

	// Create a new UserReaction record
	newUserReaction := database.UserReaction{
		UserID: uint(userIDint),
		DestID: uint(destIDint),
		Like:   true,
	}
	result = database.DB.Create(&newUserReaction)
	if result.Error != nil {
		http.Error(w, "Failed to create UserReaction record", http.StatusInternalServerError)
		fmt.Println("Failed to create UserReaction record:", result.Error)
		return
	}

	// Check if the user has liked the destination
	check, err := CheckConnection(uint(userIDint), uint(destIDint))
	if err != nil {
		http.Error(w, "Failed to check connection", http.StatusInternalServerError)
		fmt.Println("Failed to check connection:", err)
		return
	}
	if check {
		fmt.Println("Connection established")
	} else {
		fmt.Println("Connection not established")
	}

	// Return success
	w.WriteHeader(http.StatusOK)
}

func Dislike(w http.ResponseWriter, r *http.Request) {
	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	// Get the user ID from the claims
	userID, _ := GetUserIDByUsername(claims.Username)

	fmt.Println(claims.Id)

	// Get the destination ID from the URL
	vars := mux.Vars(r)
	destID := vars["id"]

	//fmt.Println("User IDs: ", r.Body.User1ID, r.Body.User2ID)

	fmt.Println("User: ", userID, " Disliked: ", destID)

	// Check if the user has already liked the destination
	var userReaction database.UserReaction
	result := database.DB.Where("user_id = ? AND dest_id = ?", userID, destID).First(&userReaction)
	if result.Error == nil {
		// User has already liked the destination
		http.Error(w, "User has already liked the destination", http.StatusBadRequest)
		return
	}

	destIDint, err := strconv.Atoi(destID)
	if err != nil {
		http.Error(w, "Failed to convert destination ID to integer", http.StatusInternalServerError)
		fmt.Println("Failed to convert destination ID to integer:", err)
		return
	}

	// Create a new UserReaction record
	newUserReaction := database.UserReaction{
		UserID: userID,
		DestID: uint(destIDint),
		Like:   false,
	}
	result = database.DB.Create(&newUserReaction)
	if result.Error != nil {
		http.Error(w, "Failed to create UserReaction record", http.StatusInternalServerError)
		fmt.Println("Failed to create UserReaction record:", result.Error)
		return
	}

	// Return success
	w.WriteHeader(http.StatusOK)
}

func CheckConnection(user1 uint, user2 uint) (bool, error) {
	var user1LikedUser2 database.UserReaction
	var user2LikedUser1 database.UserReaction

	result := database.DB.Where("user_id = ? AND dest_id = ?", user1, user2).First(&user1LikedUser2)
	if result.Error != nil && result.Error.Error() != "record not found" {
		return false, fmt.Errorf("failed to find user1LikedUser2: %v", result.Error)
	}

	result = database.DB.Where("user_id = ? AND dest_id = ?", user2, user1).First(&user2LikedUser1)
	if result.Error != nil && result.Error.Error() != "record not found" {
		return false, fmt.Errorf("failed to find user2LikedUser1: %v", result.Error)
	}

	fmt.Println("User1 liked User2: ", user1LikedUser2.Like)
	fmt.Println("User2 liked User1: ", user2LikedUser1.Like)

	if user1LikedUser2.Like && user2LikedUser1.Like {
		err := CreateConnection(user1, user2)
		if err != nil {
			return false, fmt.Errorf("failed to create connection: %v", err)
		}
		fmt.Println("Both users have liked!")
		return true, nil
	}
	return false, nil
}

func CreateConnection(user1 uint, user2 uint) error {
	var connection database.Connection
	connectionResult := database.DB.Where("user1 = ? AND user2 = ?", user1, user2).Or("user1 = ? AND user2 = ?", user2, user1).First(&connection)
	if connectionResult.Error == nil {
		return fmt.Errorf("connection already exists")
	}

	connection = database.Connection{
		User1ID: user1,
		User2ID: user2,
		Status:  "accepted",
	}

	result := database.DB.Create(&connection)
	if result.Error != nil {
		return fmt.Errorf("failed to create connection: %v", result.Error)
	}

	// Send notification to the user
	err := sendNotification(user2, "You got a new connection!")
	if err != nil {
		return fmt.Errorf("failed to send notification: %v", err)
	}

	return nil
}

// Function to send notification to the user
func sendNotification(userID uint, message string) error {
	// Implement the logic to send notification to the user
	// This could be an email, push notification, etc.
	// For now, we'll just print the message to the console
	fmt.Printf("Notification sent to user %d: %s\n", userID, message)

	// Send the notification message to the frontend
	// This is a placeholder implementation, you need to integrate with your frontend notification system
	// For example, you could use WebSockets or Server-Sent Events (SSE) to send the message to the frontend

	return nil
}

// Function to get user ID by username
func GetUserIDByUsername(username string) (uint, error) {
	var user database.User
	err := database.DB.Where("username = ?", username).First(&user).Error
	if err != nil {
		return 0, fmt.Errorf("failed to find user: %v", err)
	}
	return user.ID, nil
}
