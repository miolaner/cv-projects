package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"github.com/dgrijalva/jwt-go"
	"golang.org/x/crypto/bcrypt"
)

// RegisterCredentials defines the structure for registration data
type RegisterCredentials struct {
	Username           string   `json:"username"`
	Email              string   `json:"email"`
	Password           string   `json:"password"`
	AboutMe            string   `json:"aboutMe"`
	Interests          []string `json:"interests"`
	Location           string   `json:"location"`
	Gender             string   `json:"gender"`
	LookingForGender   string   `json:"lookingForGender"`
	ProfilePic         string   `json:"profilePic"` // URL for profile picture
	Professional       bool     `json:"professional"`
	LookingForAgeRange struct {
		Min interface{} `json:"min"`
		Max interface{} `json:"max"`
	} `json:"lookingForAgeRange"`
	Age int `json:"age"`
}

// Register handles user registration
func Register(w http.ResponseWriter, r *http.Request) {
	err := r.ParseMultipartForm(10 << 20) // 10 MB
	if err != nil {
		http.Error(w, "Failed to parse form data", http.StatusBadRequest)
		fmt.Println("Failed to parse form data:", err)
		return
	}

	// Extract user data from the form
	var creds RegisterCredentials
	creds.Username = r.FormValue("username")
	creds.Email = r.FormValue("email")
	creds.Password = r.FormValue("password")
	creds.AboutMe = r.FormValue("aboutMe")
	creds.Location = r.FormValue("location")
	creds.Gender = r.FormValue("gender")
	creds.LookingForGender = r.FormValue("lookingForGender")
	creds.Professional = r.FormValue("professional") == "yes"
	creds.Age, _ = strconv.Atoi(r.FormValue("age"))

	// Check length of "About Me"
	if len(creds.AboutMe) > 50 {
		http.Error(w, "About Me section exceeds 50 characters", http.StatusBadRequest)
		return
	}

	// Check length of username
	if len(creds.Username) > 25 {
		http.Error(w, "Username exceeds 25 characters", http.StatusBadRequest)
		return
	}

	// Parse Interests from JSON string
	interests := r.FormValue("interests")
	if err := json.Unmarshal([]byte(interests), &creds.Interests); err != nil {
		http.Error(w, "Invalid interests data", http.StatusBadRequest)
		fmt.Println("Invalid interests data:", err)
		return
	}

	// Check number of interests
	if len(creds.Interests) > 20 {
		http.Error(w, "Number of interests exceeds 20", http.StatusBadRequest)
		return
	}

	// Parse LookingForAgeRange from JSON string
	lookingForAgeRange := r.FormValue("lookingForAgeRange")
	if err := json.Unmarshal([]byte(lookingForAgeRange), &creds.LookingForAgeRange); err != nil {
		http.Error(w, "Invalid looking for age range data", http.StatusBadRequest)
		fmt.Println("Invalid looking for age range data:", err)
		return
	}

	minAge, err := parseAge(creds.LookingForAgeRange.Min)
	if err != nil {
		http.Error(w, "Invalid min age value", http.StatusBadRequest)
		fmt.Println("Invalid min age value:", err)
		return
	}

	maxAge, err := parseAge(creds.LookingForAgeRange.Max)
	if err != nil {
		http.Error(w, "Invalid max age value", http.StatusBadRequest)
		fmt.Println("Invalid max age value:", err)
		return
	}

	// Check if min age is lower than max age
	if minAge >= maxAge {
		http.Error(w, "Min age must be lower than max age", http.StatusBadRequest)
		return
	}

	// Check if age range is valid
	if minAge < 18 || maxAge > 100 {
		http.Error(w, "Age range must be between 18 and 100", http.StatusBadRequest)
		return
	}

	// Hash the password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(creds.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "Could not hash password", http.StatusInternalServerError)
		return
	}

	// Check if user already exists
	var existingUser database.User
	result := database.DB.Where("username = ? OR email = ?", creds.Username, creds.Email).First(&existingUser)
	if result.Error == nil {
		http.Error(w, "Username or email already exists", http.StatusConflict)
		return
	}

	// Create the user
	user := database.User{
		Username:     creds.Username,
		Email:        creds.Email,
		PasswordHash: string(hashedPassword),
		ProfilePictureURL: func() string {
			if creds.Gender == "Male" {
				return "/static/avatars/male_avatar.png"
			} else {
				return "/static/avatars/female_avatar.png"
			}
		}(),
		Profile: database.Profile{
			AboutMe: creds.AboutMe,
			Bio: database.Bio{
				Interests:              creds.Interests,
				Location:               creds.Location,
				Gender:                 creds.Gender,
				LookingForGender:       creds.LookingForGender,
				LookingForLocations:    []string{"Helsinki", "Espoo"}, // Example locations
				LookingForAgeRange:     []int64{minAge, maxAge},
				LookingForProfessional: creds.Professional,
				Age:                    creds.Age,
			},
		},
	}

	// Handle profile picture upload
	profilePicURL := user.ProfilePictureURL
	file, handler, err := r.FormFile("profilePic")
	if err == nil {
		defer file.Close()
		uploadDir := "static/uploads"
		if err := os.MkdirAll(uploadDir, os.ModePerm); err != nil {
			http.Error(w, "Failed to create upload directory", http.StatusInternalServerError)
			fmt.Println("Failed to create upload directory:", err)
			return
		}
		filePath := filepath.Join(uploadDir, fmt.Sprintf("%s_%s", creds.Username, handler.Filename))
		out, err := os.Create(filePath)
		if err != nil {
			http.Error(w, "Failed to save profile picture", http.StatusInternalServerError)
			fmt.Println("Failed to save profile picture:", err)
			return
		}
		defer out.Close()
		_, err = out.ReadFrom(file)
		if err != nil {
			http.Error(w, "Failed to save profile picture", http.StatusInternalServerError)
			fmt.Println("Failed to save profile picture:", err)
			return
		}
		profilePicURL = filePath
	}

	user.ProfilePictureURL = profilePicURL

	if err := database.DB.Create(&user).Error; err != nil {
		http.Error(w, "Could not register user", http.StatusInternalServerError)
		return
	}

	// Create the user's profile
	profile := database.Profile{
		AboutMe: creds.AboutMe,
		Bio: database.Bio{
			Interests:              creds.Interests,
			Location:               creds.Location,
			Gender:                 creds.Gender,
			LookingForGender:       creds.LookingForGender,
			LookingForLocations:    []string{"Helsinki", "Espoo"}, // Example locations
			LookingForAgeRange:     []int64{minAge, maxAge},
			LookingForProfessional: creds.Professional,
			Age:                    creds.Age,
		},
	}

	if err := database.DB.Create(&profile).Error; err != nil {
		http.Error(w, "Could not create profile", http.StatusInternalServerError)
		return
	}

	// Create JWT token for the new user
	token, err := createToken(user.Username, user.ID)
	if err != nil {
		http.Error(w, "Could not create token", http.StatusInternalServerError)
		return
	}

	// Return success response with token
	response := map[string]interface{}{
		"message": "User registered successfully",
		"token":   token,
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(response)
}

func RegisterData(w http.ResponseWriter, r *http.Request) {
	// Ensure this is a GET request
	if r.Method != http.MethodGet {
		http.Error(w, "Invalid method", http.StatusMethodNotAllowed)
		return
	}

	// Fetch interests
	interests, err := getInterests()
	if err != nil {
		fmt.Println("Failed to load interests:", err)
		http.Error(w, "Failed to load interests", http.StatusInternalServerError)
		return
	}

	// Fetch locations
	locations, err := getLocations()
	if err != nil {
		fmt.Println("Failed to load locations:", err)
		http.Error(w, "Failed to load locations", http.StatusInternalServerError)
		return
	}

	// Return the data as JSON
	response := map[string]interface{}{
		"interests": interests,
		"locations": locations,
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func createToken(username string, userID uint) (string, error) {
	// Use the same expiration time as login
	expirationTime := time.Now().Add(260 * time.Minute)

	claims := &Claims{
		Username: username,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(secret)
	if err != nil {
		return "", err
	}

	return tokenString, nil
}
