package handlers

import (
	"backend/database"
	"encoding/json"
	"net/http"
	"time"

	"gorm.io/gorm"
)

type ChatResponse struct {
	ConnectionID uint      `json:"connectionId"`
	OtherUser    UserInfo    `json:"otherUser"`
	Messages     []Message   `json:"messages"`
}

type UserInfo struct {
	ID       uint   `json:"id"`
	Username string `json:"username"`
}

type Message struct {
	ID        uint      `json:"id"`
	Content   string    `json:"content"`
	SenderID  uint      `json:"senderId"`
	CreatedAt time.Time `json:"createdAt"`
	ReadAt    *time.Time `json:"readAt"`
	Status    string    `json:"status"`
}

// GetChats returns all chat conversations for the user
func GetChats(w http.ResponseWriter, r *http.Request) {
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	var user database.User
	if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	var connections []database.Connection
	err := database.DB.
		Preload("Messages", func(db *gorm.DB) *gorm.DB {
			return db.Order("created_at ASC")
		}).
		Where("user1_id = ? OR user2_id = ?", user.ID, user.ID).
		Where("status = ?", "accepted").
		Find(&connections).Error
	if err != nil {
		http.Error(w, "Database error", http.StatusInternalServerError)
		return
	}

	var response []ChatResponse
	for _, conn := range connections {
		var otherUserID uint
		if conn.User1ID == user.ID {
			otherUserID = conn.User2ID
		} else {
			otherUserID = conn.User1ID
		}

		var otherUser database.User
		if err := database.DB.First(&otherUser, otherUserID).Error; err != nil {
			continue
		}

		chatResp := ChatResponse{
			ConnectionID: conn.ID,
			OtherUser: UserInfo{
				ID:       otherUser.ID,
				Username: otherUser.Username,
			},
			Messages: make([]Message, len(conn.Messages)),
		}

		for i, msg := range conn.Messages {
			chatResp.Messages[i] = Message{
				ID:        msg.ID,
				Content:   msg.Content,
				SenderID:  msg.SenderID,
				CreatedAt: msg.CreatedAt,
				ReadAt:    msg.ReadAt,
				Status:    msg.Status,
			}
		}

		response = append(response, chatResp)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// SendMessage handles sending a new message
/*func SendMessage(w http.ResponseWriter, r *http.Request) {
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	var requestBody struct {
		ConnectionID uint   `json:"connectionId"`
		Content      string `json:"content"`
	}

	if err := json.NewDecoder(r.Body).Decode(&requestBody); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	var user database.User
	if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	message := database.Message{
		ConnectionID: requestBody.ConnectionID,
		SenderID:     user.ID,
		Content:      requestBody.Content,
		Status:       "sent",
	}

	if err := database.DB.Create(&message).Error; err != nil {
		http.Error(w, "Failed to send message", http.StatusInternalServerError)
		return
	}

	// Return the complete message data
	response := Message{
		ID:        message.ID,
		Content:   message.Content,
		SenderID:  message.SenderID,
		CreatedAt: message.CreatedAt,
		Status:    message.Status,
		ReadAt:    message.ReadAt,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)*/

