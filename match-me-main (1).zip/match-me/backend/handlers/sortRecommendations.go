package handlers

import (
	"backend/database"
	"fmt"
	"sort"
)

type Recommendation struct {
	UserID    uint
	Username  string
	AboutMe   string
	Interests []string
	Location  string
	Gender    string
	Score     int
}

// filterZeroScoreRecommendations removes recommendations with a score of zero
func filterZeroScoreRecommendations(recommendations []Recommendation) []Recommendation {
	var filtered []Recommendation
	for _, recommendation := range recommendations {
		if recommendation.Score > 0 {
			filtered = append(filtered, recommendation)
		}
	}
	return filtered
}

// SortRecommendations returns a list of user IDs sorted by the number of shared interests
func SortRecommendations(claims *Claims) ([]uint, error) {
	var user database.User
	err := database.DB.Preload("Profile.Bio").Where("username = ?", claims.Username).First(&user).Error
	if err != nil {
		return nil, fmt.Errorf("failed to find user: %v", err)
	}

	var allUsers []database.User
	err = database.DB.Preload("Profile.Bio").Find(&allUsers).Error
	if err != nil {
		return nil, fmt.Errorf("failed to load users: %v", err)
	}

	var recommendations []Recommendation
	for _, otherUser := range allUsers {
		if otherUser.ID == user.ID {
			continue
		}
		if user.Profile.Bio.LookingForAgeRange[0] > int64(otherUser.Profile.Bio.Age) || user.Profile.Bio.LookingForAgeRange[1] < int64(otherUser.Profile.Bio.Age) {
			continue
		}

		if user.Profile.Bio.LookingForProfessional && !otherUser.Profile.Bio.LookingForProfessional {
			continue
		}

		if user.Profile.Bio.Location != otherUser.Profile.Bio.Location {
			continue
		}

		if otherUser.Profile.Bio.Gender != user.Profile.Bio.LookingForGender && user.Profile.Bio.LookingForGender != "any" && user.Profile.Bio.LookingForGender != "Any" {
			continue
		}

		if user.Profile.Bio.Gender != otherUser.Profile.Bio.LookingForGender && otherUser.Profile.Bio.LookingForGender != "any" {
			continue
		}

		// Check if there is already a connection between the users
		var connection database.Connection
		connectionResult := database.DB.Where("user1_id = ? AND user2_id = ?", user.ID, otherUser.ID).Or("user1_id = ? AND user2_id = ?", otherUser.ID, user.ID).First(&connection)
		if connectionResult.Error == nil {
			continue
		}

		// Check if the user has already liked or disliked the other user
		var likedOrDisliked database.UserReaction
		likeResult := database.DB.Where("user_id = ? AND dest_id = ?", user.ID, otherUser.ID).First(&likedOrDisliked)
		if likeResult.Error == nil {
			continue
		}

		score := 0
		for _, interest := range user.Profile.Bio.Interests {
			for _, otherInterest := range otherUser.Profile.Bio.Interests {
				if interest == otherInterest {
					score++
				}
			}
		}

		recommendations = append(recommendations, Recommendation{
			UserID:    otherUser.ID,
			Username:  otherUser.Username,
			AboutMe:   otherUser.Profile.AboutMe,
			Interests: otherUser.Profile.Bio.Interests,
			Location:  otherUser.Profile.Bio.Location,
			Gender:    otherUser.Profile.Bio.Gender,
			Score:     score,
		})
	}

	recommendations = filterZeroScoreRecommendations(recommendations)

	sort.SliceStable(recommendations, func(i, j int) bool {
		return recommendations[i].Score > recommendations[j].Score
	})

	var sortedIDs []uint
	for _, recommendation := range recommendations {
		sortedIDs = append(sortedIDs, recommendation.UserID)
	}

	const maxRecommendations = 10
	if len(sortedIDs) > maxRecommendations {
		sortedIDs = sortedIDs[:maxRecommendations]
	}

	return sortedIDs, nil
}
