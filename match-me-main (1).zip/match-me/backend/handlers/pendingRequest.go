package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"

	"gorm.io/gorm"
)

// GetPendingConnections handles the request to get pending connections
func GetPendingConnections(w http.ResponseWriter, r *http.Request) {
	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	// Get the current user
	var user database.User
	err := database.DB.Where("username = ?", claims.Username).First(&user).Error
	if err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		fmt.Println("User not found:", err)
		return
	}

	// Get the list of user IDs who have liked the current user and have not been disliked by the current user
	likedUserIDs, err := getLikedUsers(user.ID)
	if err != nil {
		http.Error(w, "Failed to get liked users", http.StatusInternalServerError)
		fmt.Println("Failed to get liked users:", err)
		return
	}

	// Return the list of liked user IDs
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(likedUserIDs)
}

// getLikedUsers returns a list of user IDs who have liked the current user and have not been disliked or liked by the current user
func getLikedUsers(userID uint) ([]uint, error) {
	var likedUserIDs []uint

	// Get the list of users who have liked the current user
	var likes []database.UserReaction
	err := database.DB.Where("dest_id = ? AND \"like\" = true", userID).Find(&likes).Error
	if err != nil {
		return nil, err
	}

	// Check if the current user has disliked or liked any of the users who liked them
	for _, like := range likes {
		var reaction database.UserReaction
		err := database.DB.Where("user_id = ? AND dest_id = ?", userID, like.UserID).First(&reaction).Error
		if err != nil && err != gorm.ErrRecordNotFound {
			return nil, err
		}
		if err == gorm.ErrRecordNotFound {
			likedUserIDs = append(likedUserIDs, like.UserID)
		}
	}

	return likedUserIDs, nil
}
