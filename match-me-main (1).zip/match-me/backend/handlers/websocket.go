package handlers

import (
	"backend/database"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
    CheckOrigin: func(r *http.Request) bool {
        return true // For development
    },
}

type Client struct {
    UserID uint
    Conn   *websocket.Conn
}

var (
    clients    = make(map[*Client]bool)
    clientsMux sync.RWMutex
)

type WSMessage struct {
    Type    string      `json:"type"`
    Payload interface{} `json:"payload"`
}

func HandleWebSocket(w http.ResponseWriter, r *http.Request) {
    // Get token from URL query parameter
    token := r.URL.Query().Get("token")
    if token == "" {
        http.Error(w, "Missing token", http.StatusUnauthorized)
        return
    }

    // Use existing validateJWT function
    valid, _, _, claims := validateJWT(w, &http.Request{
        Header: http.Header{
            "Authorization": []string{"Bearer " + token},
        },
    })
    if !valid {
        return
    }

    var user database.User
    if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
        http.Error(w, "User not found", http.StatusNotFound)
        return
    }

    // Add CORS headers for WebSocket
    upgrader.CheckOrigin = func(r *http.Request) bool {
        return true // Be more restrictive in production
    }

    conn, err := upgrader.Upgrade(w, r, nil)
    if err != nil {
        log.Printf("Failed to upgrade connection: %v", err)
        return
    }

    client := &Client{
        UserID: user.ID,
        Conn:   conn,
    }

    clientsMux.Lock()
    clients[client] = true
    clientsMux.Unlock()

    defer func() {
        clientsMux.Lock()
        delete(clients, client)
        clientsMux.Unlock()
        conn.Close()
    }()

    for {
        _, _, err := conn.ReadMessage()
        if err != nil {
            break
        }
    }
}

func broadcastToUser(userID uint, message WSMessage) {
    clientsMux.RLock()
    defer clientsMux.RUnlock()

    for client := range clients {
        if client.UserID == userID {
            err := client.Conn.WriteJSON(message)
            if err != nil {
                log.Printf("Error broadcasting to user %d: %v", userID, err)
            }
        }
    }
} 