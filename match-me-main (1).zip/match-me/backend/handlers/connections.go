package handlers

import (
	"backend/database"
	"encoding/json"
	"net/http"
	"time"

	"github.com/gorilla/mux"
)

// ConnectionResponse follows the project requirement of returning only IDs
type ConnectionResponse struct {
	ID          uint      `json:"id"`
	OtherUserID uint      `json:"otherUserId"`
	CreatedAt   time.Time `json:"createdAt"`
}

// ConnectionDetails contains connection info for a specific user
type ConnectionDetails struct {
	ConnectionID uint      `json:"connectionId"`
	CreatedAt    time.Time `json:"createdAt"`
}

// GetConnections returns array of user IDs
func GetConnections(w http.ResponseWriter, r *http.Request) {
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	var user database.User
	if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	var connections []database.Connection
	if err := database.DB.Where(
		"user1_id = ? OR user2_id = ?", 
		user.ID, user.ID,
	).Find(&connections).Error; err != nil {
		http.Error(w, "Database error", http.StatusInternalServerError)
		return
	}

	// Return empty array instead of 404 when no connections exist
	otherUserIDs := []uint{}
	for _, conn := range connections {
		otherUserID := conn.User2ID
		if conn.User2ID == user.ID {
			otherUserID = conn.User1ID
		}
		otherUserIDs = append(otherUserIDs, otherUserID)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(otherUserIDs)
}

// Add this new function
func RemoveConnection(w http.ResponseWriter, r *http.Request) {
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	vars := mux.Vars(r)
	connectionID := vars["id"]

	var user database.User
	if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	// Start a transaction
	tx := database.DB.Begin()

	// Find the connection
	var connection database.Connection
	if err := tx.First(&connection, connectionID).Error; err != nil {
		tx.Rollback()
		http.Error(w, "Connection not found", http.StatusNotFound)
		return
	}

	// Verify user is part of this connection
	if connection.User1ID != user.ID && connection.User2ID != user.ID {
		tx.Rollback()
		http.Error(w, "Not authorized", http.StatusForbidden)
		return
	}

	// Delete all messages associated with this connection first
	if err := tx.Where("connection_id = ?", connectionID).Delete(&database.Message{}).Error; err != nil {
		tx.Rollback()
		http.Error(w, "Failed to remove messages", http.StatusInternalServerError)
		return
	}

	// Then delete the connection
	if err := tx.Delete(&connection).Error; err != nil {
		tx.Rollback()
		http.Error(w, "Failed to remove connection", http.StatusInternalServerError)
		return
	}

	// Commit the transaction
	if err := tx.Commit().Error; err != nil {
		tx.Rollback()
		http.Error(w, "Failed to commit transaction", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

// GetConnectionDetails returns connection details between authenticated user and given user ID
func GetConnectionDetails(w http.ResponseWriter, r *http.Request) {
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	vars := mux.Vars(r)
	otherUserID := vars["id"]

	var user database.User
	if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	// Find connection between the two users
	var connection database.Connection
	err := database.DB.Where(
		"(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)",
		user.ID, otherUserID, otherUserID, user.ID,
	).First(&connection).Error

	if err != nil {
		http.Error(w, "Connection not found", http.StatusNotFound)
		return
	}

	details := ConnectionDetails{
		ConnectionID: connection.ID,
		CreatedAt:    connection.CreatedAt,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(details)
}
