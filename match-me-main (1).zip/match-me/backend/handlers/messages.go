package handlers

import (
	"backend/database"
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gorilla/mux"
)

// MessageResponse contains only necessary message data
type MessageResponse struct {
    ID        uint       `json:"id"`
    Content   string     `json:"content"`
    SenderID  uint       `json:"senderId"`
    Timestamp string     `json:"timestamp"`
    Status    string     `json:"status"`
    ReadAt    *time.Time `json:"readAt"`
}

// Add this struct for the response
type MessagesResponse struct {
    Messages []MessageResponse `json:"messages"`
    Total    int64            `json:"total"`
}

// GetMessages returns messages for a specific connection
func GetMessages(w http.ResponseWriter, r *http.Request) {
    valid, _, _, claims := validateJWT(w, r)
    if !valid {
        return
    }

    vars := mux.Vars(r)
    connectionID, err := strconv.ParseUint(vars["id"], 10, 64)
    if err != nil {
        http.Error(w, "Invalid connection ID", http.StatusBadRequest)
        return
    }

    // Verify user has access to this connection
    var user database.User
    if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
        http.Error(w, "User not found", http.StatusNotFound)
        return
    }

    var connection database.Connection
    if err := database.DB.First(&connection, connectionID).Error; err != nil {
        http.Error(w, "Connection not found", http.StatusNotFound)
        return
    }

    // Verify user is part of this connection
    if connection.User1ID != user.ID && connection.User2ID != user.ID {
        http.Error(w, "Not authorized", http.StatusForbidden)
        return
    }

    // Get page from query params
    page := 1
    if pageStr := r.URL.Query().Get("page"); pageStr != "" {
        if p, err := strconv.Atoi(pageStr); err == nil {
            page = p
        }
    }

    limit := 5 // Changed to 5 for testing pagination
    offset := (page - 1) * limit

    var messages []database.Message
    if err := database.DB.Where("connection_id = ?", connectionID).
        Order("created_at DESC"). // Get newest messages first
        Limit(limit).
        Offset(offset).
        Find(&messages).Error; err != nil {
        http.Error(w, "Database error", http.StatusInternalServerError)
        return
    }

    // Reverse messages to show in ascending order
    for i, j := 0, len(messages)-1; i < j; i, j = i+1, j-1 {
        messages[i], messages[j] = messages[j], messages[i]
    }

    // Convert to response format
    messageResponses := make([]MessageResponse, len(messages))
    for i, msg := range messages {
        messageResponses[i] = MessageResponse{
            ID:        msg.ID,
            Content:   msg.Content,
            SenderID:  msg.SenderID,
            Timestamp: msg.CreatedAt.Format(time.RFC3339),
            Status:    msg.Status,
            ReadAt:    msg.ReadAt,
        }
    }

    // Get total count
    var total int64
    database.DB.Model(&database.Message{}).Where("connection_id = ?", connectionID).Count(&total)

    // Create final response
    finalResponse := MessagesResponse{
        Messages: messageResponses,
        Total:    total,
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(finalResponse)
}

// SendMessage handles sending a new message
func SendMessage(w http.ResponseWriter, r *http.Request) {
    valid, _, _, claims := validateJWT(w, r)
    if !valid {
        return
    }

    var requestBody struct {
        ConnectionID uint   `json:"connectionId"`
        Content      string `json:"content"`
    }

    if err := json.NewDecoder(r.Body).Decode(&requestBody); err != nil {
        log.Printf("Failed to decode request body: %v", err)
        http.Error(w, "Invalid request body", http.StatusBadRequest)
        return
    }

    log.Printf("Received message request: %+v", requestBody)

    var user database.User
    if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
        log.Printf("Failed to find user: %v", err)
        http.Error(w, "User not found", http.StatusNotFound)
        return
    }

    // Create and save the new message
    message := database.Message{
        ConnectionID: requestBody.ConnectionID,
        SenderID:    user.ID,
        Content:     requestBody.Content,
        Status:      "sent",
    }

    if err := database.DB.Create(&message).Error; err != nil {
        log.Printf("Failed to create message: %v", err)
        http.Error(w, "Failed to send message", http.StatusInternalServerError)
        return
    }

    log.Printf("Created message: %+v", message)

    // Get the connection to find the other user
    var connection database.Connection
    if err := database.DB.First(&connection, requestBody.ConnectionID).Error; err != nil {
        log.Printf("Failed to find connection: %v", err)
        http.Error(w, "Connection not found", http.StatusNotFound)
        return
    }

    // Determine the other user's ID
    otherUserID := connection.User2ID
    if connection.User2ID == user.ID {
        otherUserID = connection.User1ID
    }

    // Notify the other user via WebSocket
    broadcastToUser(otherUserID, WSMessage{
        Type: "new_message",
        Payload: map[string]interface{}{
            "connectionId": message.ConnectionID,
            "message": MessageResponse{
                ID:        message.ID,
                Content:   message.Content,
                SenderID:  message.SenderID,
                Timestamp: message.CreatedAt.Format(time.RFC3339),
                Status:    message.Status,
                ReadAt:    message.ReadAt,
            },
        },
    })

    // Return the message response
    response := MessageResponse{
        ID:        message.ID,
        Content:   message.Content,
        SenderID:  message.SenderID,
        Timestamp: message.CreatedAt.Format(time.RFC3339),
        Status:    message.Status,
        ReadAt:    message.ReadAt,
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(response)
}

// MarkMessagesAsRead marks messages as read
func MarkMessagesAsRead(w http.ResponseWriter, r *http.Request) {
    valid, _, _, claims := validateJWT(w, r)
    if !valid {
        return
    }

    var requestBody struct {
        ConnectionID uint `json:"connectionId"`
    }

    if err := json.NewDecoder(r.Body).Decode(&requestBody); err != nil {
        http.Error(w, "Invalid request body", http.StatusBadRequest)
        return
    }

    var user database.User
    if err := database.DB.Where("username = ?", claims.Username).First(&user).Error; err != nil {
        http.Error(w, "User not found", http.StatusNotFound)
        return
    }

    now := time.Now()
    
    if err := database.DB.Model(&database.Message{}).
        Where("connection_id = ? AND sender_id != ? AND status = ?", 
            requestBody.ConnectionID, user.ID, "sent").
        Updates(map[string]interface{}{
            "status": "read",
            "read_at": now,
        }).Error; err != nil {
        http.Error(w, "Failed to mark messages as read", http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusOK)
} 