package handlers

import (
	"backend/database"
	"encoding/json"
	"fmt"
	"net/http"
)

type RecommendationResponse struct {
	Username       string   `json:"username"`
	AboutMe        string   `json:"aboutMe"`
	Location       string   `json:"location"`
	ProfilePicPath string   `json:"profilePicPath"`
	Interests      []string `json:"interests"`
	UserID         uint     `json:"userID"`
}

type ConnectionRequest struct {
	User1ID uint `json:"user1ID"`
	User2ID uint `json:"user2ID"`
}

func Recommendations(w http.ResponseWriter, r *http.Request) {
	// Validate the JWT token
	valid, _, _, claims := validateJWT(w, r)
	if !valid {
		return
	}

	listOfRecommendationIDs, err := SortRecommendations(claims)
	if err != nil {
		http.Error(w, "Failed to sort recommendations", http.StatusInternalServerError)
		fmt.Println("Failed to sort recommendations:", err)
		return
	}

	if len(listOfRecommendationIDs) == 0 {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode([]RecommendationResponse{})
		fmt.Println("No recommendations available")
		return
	}

	fmt.Println("List of recommendations IDs: ", listOfRecommendationIDs)

	// Get the list of users the current user has already liked or disliked
	var reactedUserIDs []uint
	err = database.DB.Model(&database.UserReaction{}).Where("user_id = ?", claims.Id).Pluck("dest_id", &reactedUserIDs).Error
	if err != nil {
		http.Error(w, "Failed to load reacted users", http.StatusInternalServerError)
		fmt.Println("Failed to load reacted users:", err)
		return
	}

	// Filter out the reacted users from the recommendations
	var filteredRecommendationIDs []uint
	for _, id := range listOfRecommendationIDs {
		if !contains(reactedUserIDs, id) {
			filteredRecommendationIDs = append(filteredRecommendationIDs, id)
		}
	}

	fmt.Println("Filtered recommendations IDs: ", filteredRecommendationIDs)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(filteredRecommendationIDs)

	fmt.Printf("Got Recommendations request from %s\n", claims.Username)
}

// Helper function to check if a slice contains a specific element
func contains(slice []uint, element uint) bool {
	for _, item := range slice {
		if item == element {
			return true
		}
	}
	return false
}
