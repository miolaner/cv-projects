package main

import (
    "log"
    "backend/database"
    "github.com/joho/godotenv"
)

func main() {
    // Load environment variables
    if err := godotenv.Load(); err != nil {
        log.Fatal("Error loading .env file")
    }

    // Connect to the database
    database.ConnectDatabase()

    // Run the seeder
    database.SeedLargeDatabase(100)  // ✅ Change this number for more/less users

    log.Println("✅ Database seeded successfully!")
}
