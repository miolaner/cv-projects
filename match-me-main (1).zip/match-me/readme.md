# Match-Me

Match-Me is a web application that allows users to create profiles, connect with others, and chat. This project includes both the frontend and backend components.

## Table of Contents

- [How to start the project](#how-to-start-the-project)
- [Installation](#installation)
- [Backend Setup](#backend-setup)
- [Frontend Setup](#frontend-setup)
- [Environment Variables](#environment-variables)
- [Running the Application](#running-the-application)
- [Setting Up PostgreSQL](#setting-up-postgresql)
- [Using the start.sh Script](#using-the-startsh-script)
- [API Endpoints](#api-endpoints)
- [Seeder for review](#seeder-for-review)
- [Bonus](#bonus-features)

## How to start the project

There are 2 ways you can start the project, manually starting backend and frontend or using the start.sh script.

### Manually

First, make sure you have postgresql installed and database created. See [Install PostgreSQL](#install-postgresql) for details.

Second, [setup backend](#backend-setup) and [setup frontend](#frontend-setup)

Third, update / create `backend/.env` file and `frontend/.env.local` file. See [Configure PostgreSQL](#configure-postgresql) section 4 and [Frontend Setup](#frontend-setup)

Forth, starting the servers. See [Running the Application](#running-the-application)

### Using start script

First, make sure you have postgresql installed and database created. See [Install PostgreSQL](#install-postgresql) for details.

Second, create `.env` file(s) in `backend` folder (and in `backend/cmd/seeder` if using the seeder)

Third, start the start script. See [Using the start.sh Script](#using-start-script). See [Configure PostgreSQL](#configure-postgresql) section 4 and [Frontend Setup](#frontend-setup)

Start scipt automates the .env.local creating and/or updating. Collecting the correct local IP address and starting the backend and frontend.

## Installation

### Prerequisites

- [Go](https://golang.org/doc/install) (version 1.16 or higher)
- [Node.js](https://nodejs.org/) (version 14 or higher)
- [PostgreSQL](https://www.postgresql.org/download/)

### Backend Setup

1. Clone the repository:

   ```sh
   git clone https://gitea.koodsisu.fi/simonbrown/match-me
   cd match-me/backend
   ```

2. Install Go dependencies:

   ```sh
   go mod tidy
   ```

3. Set up the PostgreSQL database and update the connection details in the `.env` file.

4. Run the backend server:

   ```sh
   go run main.go
   ```

### Frontend Setup

1. Navigate to the frontend directory:

   ```sh
   cd ../frontend
   ```

2. Install Node.js dependencies:

   ```sh
   npm install
   ```

3. Update the `frontend/.env.local` file with the backend URL:

   ```sh
   echo "REACT_APP_BACKEND_URL=http://localhost:8000"
   ```

   Change the localhost to your machines local ip address.

4. Start the frontend development server:

   ```sh
   npm start
   ```

## Environment Variables

Create a `.env` file in the `backend` directory with the following variables:

```
DB_HOST=localhost
DB_PORT=5432
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=your_db_name
JWT_SECRET=my_secret_key
ADMIN_PASSWORD=admin
```

## Running the Application

1. Start the backend server:

   ```sh
   cd backend
   go run main.go
   ```

2. Start the frontend development server:

   ```sh
   cd ../frontend
   npm start
   ```

3. Open your browser and navigate to `http://localhost:3000`.

## Setting Up PostgreSQL

### Install PostgreSQL

#### On macOS

1. Install PostgreSQL using Homebrew:

   ```sh
   brew install postgresql@17
   ```

2. Start the PostgreSQL service:

   ```sh
   brew services start postgresql
   ```

3. Create a new PostgreSQL user and database:

   ```sh
   createuser --interactive
   createdb match_me_db
   ```

   CHANGE THE match_me_db TO THE SAME AS IN THE .ENV FILE!!

#### On Ubuntu

1. Install PostgreSQL:

   ```sh
   sudo apt update
   sudo apt install postgresql postgresql-contrib
   ```

2. Start the PostgreSQL service:

   ```sh
   sudo systemctl start postgresql
   ```

3. Create a new PostgreSQL user and database:

   ```sh
   sudo -i -u postgres
   createuser --interactive
   createdb match_me_db
   ```

#### On Windows

1. Download and install PostgreSQL from the [official website](https://www.postgresql.org/download/windows/).

2. Follow the installation instructions and create a new PostgreSQL user and database during the setup process.

### Configure PostgreSQL

1. Open the PostgreSQL interactive terminal:

   ```sh
   psql -U your_db_user -d match_me_db
   ```

2. Set a password for the PostgreSQL user:

   ```sql
   \password your_db_user
   ```

3. Exit the PostgreSQL interactive terminal:

   ```sql
   \q
   ```

4. Update the `.env` file in the `backend` directory with the PostgreSQL connection details:

   ```
   DB_HOST=localhost
   DB_PORT=5432
   DB_USER=your_db_user
   DB_PASSWORD=your_db_password
   DB_NAME=match_me_db
   JWT_SECRET=my_secret_key
   ADMIN_PASSWORD=admin
   ```

### Backend Setup

1. Clone the repository:

   ```sh
   cd match-me/backend
   ```

2. Install Go dependencies:

   ```sh
   go mod tidy
   ```

3. Set up the PostgreSQL database and update the connection details in the `.env` file. See [Environment Variables](#environment-variables)

4. Run the backend server:

   ```sh
   go run main.go
   ```

### Frontend Setup

1. Navigate to the frontend directory:

   ```sh
   cd ../frontend
   ```

2. Install Node.js dependencies:

   ```sh
   npm install
   ```

3. Update/create the `frontend/.env.local` file with the backend URL:

   ```sh
   REACT_APP_BACKEND_URL=http://<YOUR_IP_ADDRESS>:8000
   ```

   Change the YOUR_IP_ADDRESS to your machines local ip address. DO NOT USE localhost

4. Start the frontend development server:

   ```sh
   npm start
   ```

## Environment Variables

Create a `.env` file in the `backend` directory with the following variables:

```
DB_HOST=localhost
DB_PORT=5432
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=your_db_name
JWT_SECRET=my_secret_key
ADMIN_PASSWORD=admin
```

Replace the username, DB name and password with correspoding on your DB.
JWT Secret key is the key with what the JWT is crypted. DO NOT SHERE THIS WITH ANYONE!

Admin password will be created for the admin profile

If using seeder, crate `.env` file in `backend/cmd/seeder`

## Running the Application

1. Start the backend server:

   ```sh
   cd backend
   go run main.go
   ```

2. Start the frontend development server:

   ```sh
   cd ../frontend
   npm start
   ```

3. Open your browser and navigate to `http://localhost:3000`.

## Using the start.sh Script

The `start.sh` script automates the process of starting both the backend and frontend servers. It also updates the `frontend/.env.local` file with the local IP address of your machine.

### Usage

1. Make the script executable:

   ```sh
   chmod +x start.sh
   ```

2. Run the script:

   ```sh
   ./start.sh
   ```

The script will:

- Determine the local IP address of your machine.
- Update the `frontend/.env.local` file with the backend URL.
- Start the backend server and redirect output to `start_backend.log`.
- Start the frontend server and redirect output to `start_frontend.log`.

## API Endpoints

### Authentication

- POST /login

  - Request Body:

  ```json
  {
    "username": "string",
    "password": "string"
  }
  ```

  - User login with username and password
  - Returns JWT token in HTTP-only cookie

- POST /register

  - Request Body:

  ```json
  {
    "username": "string",
    "email": "string",
    "password": "string",
    "aboutMe": "string",
    "interests": ["string"],
    "location": "string",
    "gender": "string",
    "lookingForGender": "string",
    "lookingForAgeRange": {
      "min": number,
      "max": number
    },
    "lookingForProfessional": "yes" | "no",
    "age": number,
    "profilePic": File
  }
  ```

  - Create new user account with profile and bio
  - Returns JWT token in HTTP-only cookie

- POST /logout
  - Logs out user by clearing token cookie

### User Data

- GET /me

  - Get current user's basic info (id, profilePicURL, username)

- GET /me/profile

  - Get current user's profile info (aboutMe)

- GET /me/bio

  - Get current user's biographical info (interests, preferences)

- GET /users/{id}

  - Get basic info of specific user
  - Only visible if user is in recommendations/connections/reactions

- GET /users/{id}/profile

  - Get profile info of specific user
  - Same visibility rules as /users/{id}

- GET /users/{id}/bio
  - Get biographical info of specific user
  - Same visibility rules as /users/{id}

### Profile Management

- GET /profile/edit

  - Get available options for profile editing (interests list, locations)

- POST /profile/edit
  - Request Body:
  ```json
  {
    "aboutMe": "string",
    "interests": ["string"],
    "location": "string",
    "gender": "string",
    "lookingForGender": "string",
    "lookingForAgeRange": {
      "min": number,
      "max": number
    },
    "lookingForProfessional": "yes" | "no",
    "profilePic": File,
    "removeProfilePic": "true" | "false"
  }
  ```
  - Update user's profile, bio, and preferences
  - Can update profile picture

### Recommendations & Matching

- GET /recommendations

  - Get list of recommended user IDs
  - Filtered based on preferences and previous interactions

- POST /like/{id}

  - URL parameter: id (ID of user to like)
  - Authorization: Bearer token required
  - Response: 200 OK if successful
  - Creates connection if mutual like exists

- POST /dislike/{id}
  - URL parameter: id (ID of user to dislike)
  - Authorization: Bearer token required
  - Response: 200 OK if successful
  - Prevents future recommendations

### Connections

- GET /connections

  - Get list of accepted connections

- GET /pending

  - Get list of pending connection requests

- GET /connections/{userId}/details
  - Returns connection details between authenticated user and given user ID

- DELETE /connections/{id}
  - Remove connection and associated messages

### Chat

- GET /connections/{id}/messages

  - Get paginated message history for a connection

- POST /messages

  - Request Body:

  ```json
  {
    "connectionId": number,
    "content": "string"
  }
  ```

  - Send new message in a connection

- POST /messages/read

  - Request Body:

  ```json
  {
    "connectionId": number
  }
  - Mark messages as read in a connection

  ```

- GET /ws
  - WebSocket connection for real-time chat updates

## Seeder for review

```
DB_HOST=localhost
DB_PORT=5432
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=match_me_db
JWT_SECRET=my_secret_key
```

To seed the backend with 100 users (Remember to have the .env file in `backend/cmd/seeder` folder!):

```sh
go run backend/cmd/seeder/main.go
```

### Bonus features

None
