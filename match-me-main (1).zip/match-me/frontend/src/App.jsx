import './App.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import Home from './pages/Home';
import Recommendations from './pages/Recommendations';
import Chat from './pages/Chat';
import Profile from './pages/Profile';
import ProfileEdit from './pages/ProfileEdit'; // Import the new ProfileEdit page
import Toolbar from './components/Toolbar';
import Register from './pages/Register';
import { NotificationProvider } from './context/NotificationContext';
import { webSocketService } from './services/websocket';

const apiUrl = process.env.REACT_APP_BACKEND_URL; // Use the backend URL from environment variable

function App() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [error, setError] = useState("");

  console.log("Token:", document.cookie); // Debugging statement
  console.log("API URL:", apiUrl); // Debugging statement

  useEffect(() => {
    // Check if user is logged in (has token)
    const token = document.cookie.split('; ').find(row => row.startsWith('token='));
    console.log("Token from cookies:", token); // Debugging statement
    if (token) {
      setIsLoggedIn(true);
      webSocketService.connect(); // Connect WebSocket if already logged in
    }
  }, []);

  const handleLogin = async () => {
    console.log("handleLogin called"); // Debugging statement
    try {
      console.log(apiUrl);
      const response = await axios.post(`${apiUrl}/login`, { username, password }, { withCredentials: true });
      if (response.status === 200) {
        document.cookie = `token=${response.data.token}; path=/; SameSite=None; Secure`;
        setUsername(username);
        setIsLoggedIn(true);
        setError("");
        console.log("Login successful"); // Debugging statement
        console.log("Token set in cookies:", document.cookie); // Debugging statement
        webSocketService.connect(); // Connect WebSocket after successful login
      }
    } catch (err) {
      if (err.response && err.response.status === 401) {
        setError("Invalid user");
        console.log("Invalid user"); // Debugging statement
      } else {
        setError("An error occurred. Please try again.");
        console.log("An error occurred:", err); // Debugging statement
      }
    }
  };

  const handleRegister = async () => {
    console.log("handleRegister called"); // Debugging statement
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    try {
      const response = await axios.post(`${apiUrl}/register`, { username, email, password });
      if (response.status === 201) {
        setError("");
        console.log("Registration successful"); // Debugging statement
        // Log the user in right away
        await handleLogin();
      }
    } catch (err) {
      setError("An error occurred. Please try again.");
      console.log("An error occurred:", err); // Debugging statement
    }
  };

  const getToken = () => {
    const token = document.cookie.split('; ').find(row => row.startsWith('token='));
    console.log("Token from getToken:", token); // Debugging statement
    return token ? token.split('=')[1] : null;
  };

  const authAxios = axios.create({
    baseURL: apiUrl,
    headers: {
      Authorization: `Bearer ${getToken()}`
    },
    withCredentials: true, // Ensure credentials are included in requests
  });

  const ProtectedRoute = ({ element: Component, ...rest }) => {
    return isLoggedIn ? <Component {...rest} /> : <Navigate to="/" />;
  };

  const handleLogout = () => {
    document.cookie = 'token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    setIsLoggedIn(false);
    setUsername("");
    webSocketService.disconnect(); // Disconnect WebSocket on logout
  };

  return (
    <NotificationProvider>
      <Router>
        <div className="App">
          {isLoggedIn && <Toolbar handleLogout={handleLogout} />}
          <header className="App-header">
            <Routes>
              {!isLoggedIn ? (
                <>
                  <Route path="/" element={
                    <div className="login-container">
                      <h2>Login</h2>
                      <input
                        type="text"
                        placeholder="Username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                      />
                      <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button onClick={handleLogin}>Login</button>
                      {error && <p className="error">{error}</p>}
                      <p>Don't have an account? <Link to="/register">Register here</Link></p>
                    </div>
                  } />
                  <Route path="/register" element={
                    <Register 
                      setIsLoggedIn={setIsLoggedIn} 
                      setUsername={setUsername}
                    />
                  } />
                  
                </>
              ) : (
                <>
                  <Route path="/" element={<Home username={username} setUsername={setUsername} setIsLoggedIn={setIsLoggedIn} />} />
                  <Route path="/recommendations" element={<ProtectedRoute element={Recommendations} />} />
                  <Route path="/chat" element={<ProtectedRoute element={Chat} />} />
                  <Route path="/profile" element={<ProtectedRoute element={Profile} />} />
                  <Route path="/profile/edit" element={<ProtectedRoute element={ProfileEdit} />} /> {/* Add the new route */}
                  <Route path="/me" element={<ProtectedRoute element={Profile} />} />
                  <Route path="*" element={<Navigate to="/" />} />
                </>
              )}
            </Routes>
          </header>
        </div>
      </Router>
    </NotificationProvider>

  );
}

export default App;
