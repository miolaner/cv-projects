import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './styles/UserProfilePopup.css';

const UserProfilePopup = ({ userId, connectionId, onClose, onConnectionRemoved }) => {
    const [profile, setProfile] = useState(null);
    const [bio, setBio] = useState(null);
    const [error, setError] = useState("");

    const getToken = () => {
        const token = document.cookie.split('; ').find(row => row.startsWith('token='));
        return token ? token.split('=')[1] : null;
    };

    const handleRemoveConnection = async () => {
        try {
            const token = getToken();
            await axios.delete(
                `${process.env.REACT_APP_BACKEND_URL}/connections/${connectionId}`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true,
                }
            );
            onConnectionRemoved();
            onClose();
        } catch (err) {
            console.error("Error removing connection:", err);
            setError("Failed to remove connection");
        }
    };

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const token = getToken();
                const userResponse = await axios.get(
                    `${process.env.REACT_APP_BACKEND_URL}/users/${userId}`,
                    {
                        headers: { Authorization: `Bearer ${token}` },
                        withCredentials: true,
                    }
                );
                const profileResponse = await axios.get(
                    `${process.env.REACT_APP_BACKEND_URL}/users/${userId}/profile`,
                    {
                        headers: { Authorization: `Bearer ${token}` },
                        withCredentials: true,
                    }
                );
                const bioResponse = await axios.get(
                    `${process.env.REACT_APP_BACKEND_URL}/users/${userId}/bio`,
                    {
                        headers: { Authorization: `Bearer ${token}` },
                        withCredentials: true,
                    }
                );
                setProfile({ ...userResponse.data, ...profileResponse.data });
                setBio(bioResponse.data.bio);
            } catch (err) {
                console.error("Error fetching user data:", err);
                setError("Failed to load user data");
            }
        };

        fetchUserData();
    }, [userId]);

    const getProfileImage = () => {
        console.log(profile);
        if (profile.profilePicURL) {
            console.log(profile.profilePicURL);
            if (profile.profilePicURL.startsWith("/")) {
                return `${process.env.REACT_APP_BACKEND_URL}${profile.profilePicURL}`;
            } else {
                return `${process.env.REACT_APP_BACKEND_URL}/${profile.profilePicURL}`;
            }
        } else if (bio.Gender === 'female') {
            return `${process.env.REACT_APP_BACKEND_URL}/static/avatars/female_avatar.png`;
        } else {
            console.log("No profile picture found");
            return `${process.env.REACT_APP_BACKEND_URL}/static/avatars/male_avatar.png`;
        }
    };

    return (
        <>
            <div className="profile-popup-overlay" onClick={onClose} />
            <div className="profile-popup">
                <button className="close-profile-popup" onClick={onClose}>×</button>
                {error ? (
                    <p className="error-message">{error}</p>
                ) : !profile || !bio ? (
                    <p>Loading profile...</p>
                ) : (
                    <div className="profile-card">
                        <img
                            src={getProfileImage()}
                            alt={`${profile.username}'s profile`}
                            className="profile-image"
                        />
                        <div className="profile-details">
                            <h3>{profile.username}</h3>
                            <p><strong>About Me:</strong> {profile.aboutMe}</p>
                            <p><strong>Interests:</strong> {bio.Interests?.join(', ')}</p>
                            <p><strong>Location:</strong> {bio.Location}</p>
                            <p><strong>Gender:</strong> {bio.Gender}</p>
                            <p><strong>Age:</strong> {bio.Age}</p>
                            
                            <button 
                                className="remove-connection-btn"
                                onClick={handleRemoveConnection}
                            >
                                Remove Connection
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
};

export default UserProfilePopup;