import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faComments, faUser, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { useNotifications } from '../context/NotificationContext';
import './styles/Toolbar.css';

const Toolbar = ({ handleLogout }) => {
  const navigate = useNavigate();
  const { hasUnreadMessages } = useNotifications();

  const onLogout = () => {
    handleLogout();
    navigate('/');
  };

  return (
    <nav className="toolbar">
      <Link to="/recommendations">
        <FontAwesomeIcon icon={faHome} className="icon" />
        <span className="text">Recommendations</span>
      </Link>
      <Link to="/chat" className="chat-link">
        <FontAwesomeIcon icon={faComments} className="icon" />
        <span className="text">Chat</span>
        {hasUnreadMessages && <span className="toolbar-notification" />}
      </Link>
      <Link to="/profile">
        <FontAwesomeIcon icon={faUser} className="icon" />
        <span className="text">Profile</span>
      </Link>
      <button onClick={onLogout}>
        <FontAwesomeIcon icon={faSignOutAlt} className="icon" />
        <span className="text">Logout</span>
      </button>
    </nav>
  );
};

export default Toolbar;
