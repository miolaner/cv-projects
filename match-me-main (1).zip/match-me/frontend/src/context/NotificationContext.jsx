import React, { createContext, useState, useContext, useEffect } from 'react';
import { webSocketService } from '../services/websocket';
import axios from 'axios';

const NotificationContext = createContext();

export const NotificationProvider = ({ children }) => {
    const [hasUnreadMessages, setHasUnreadMessages] = useState(false);
    const [unreadChats, setUnreadChats] = useState({});

    const checkUnreadMessages = async () => {
        try {
            const getToken = () => {
                const token = document.cookie.split('; ')
                    .find(row => row.startsWith('token='))
                    ?.split('=')[1];
                if (!token) {
                    throw new Error('No token found');
                }
                return token;
            };

            const token = getToken();

            // First get current user's ID
            const userResponse = await axios.get(
                `${process.env.REACT_APP_BACKEND_URL}/me`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true
                }
            );
            const currentUserId = userResponse.data.id;
            
            // Get user's connections
            const connectionsResponse = await axios.get(
                `${process.env.REACT_APP_BACKEND_URL}/connections`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true
                }
            );

            // Handle no connections case
            if (!connectionsResponse.data || connectionsResponse.data.length === 0) {
                setUnreadChats({});
                setHasUnreadMessages(false);
                return;
            }

            const unreadStatus = {};
            let hasUnread = false;

            // 2. For each connection, get details and check messages
            await Promise.all(connectionsResponse.data.map(async (userId) => {
                // Get connection details first
                const detailsResponse = await axios.get(
                    `${process.env.REACT_APP_BACKEND_URL}/connections/${userId}/details`,
                    {
                        headers: { Authorization: `Bearer ${token}` },
                        withCredentials: true
                    }
                );
                const connectionId = detailsResponse.data.connectionId;

                // Then check messages
                const messagesResponse = await axios.get(
                    `${process.env.REACT_APP_BACKEND_URL}/connections/${connectionId}/messages`,
                    {
                        headers: { Authorization: `Bearer ${token}` },
                        withCredentials: true
                    }
                );
                
                // Check for unread messages
                const hasUnreadMessages = messagesResponse.data.messages.some(msg => 
                    msg.status === 'sent' && msg.senderId !== currentUserId
                );

                if (hasUnreadMessages) {
                    unreadStatus[connectionId] = true;
                    hasUnread = true;
                }
            }));

            setUnreadChats(unreadStatus);
            setHasUnreadMessages(hasUnread);

        } catch (err) {
            console.error("Error checking unread messages:", err);
            // Set default states on error
            setUnreadChats({});
            setHasUnreadMessages(false);
        }
    };

    // Check messages whenever a token exists
    useEffect(() => {
        const token = document.cookie.split('; ')
            .find(row => row.startsWith('token='));
        
        if (token) {
            console.log('🔑 Token found, checking messages...');
            checkUnreadMessages();
        } else {
            console.log('🔒 No token found, skipping message check');
        }
    }, [document.cookie]); // Re-run when cookie changes

    // WebSocket message handler
    useEffect(() => {
        const handleMessage = (data) => {
            if (data.type === 'new_message') {
                const { connectionId, message } = data.payload;
                
                if (message.status === 'sent') {
                    setUnreadChats(prev => ({
                        ...prev,
                        [connectionId]: true
                    }));
                    setHasUnreadMessages(true);
                }

                const event = new CustomEvent('new-chat-message', { 
                    detail: { connectionId, message } 
                });
                window.dispatchEvent(event);
            }
        };

        webSocketService.addListener(handleMessage);
        return () => webSocketService.removeListener(handleMessage);
    }, []);

    return (
        <NotificationContext.Provider value={{ 
            hasUnreadMessages, 
            setHasUnreadMessages,
            unreadChats,
            setUnreadChats,
            checkUnreadMessages
        }}>
            {children}
        </NotificationContext.Provider>
    );
};

export const useNotifications = () => useContext(NotificationContext); 