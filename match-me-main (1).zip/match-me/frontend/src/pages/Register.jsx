import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

const apiUrl = "http://localhost:8000";

const Register = ({ setIsLoggedIn, setUsername: setAppUsername }) => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordAgain, setPasswordAgain] = useState("");
  const [aboutMe, setAboutMe] = useState("");
  const [interests, setInterests] = useState([]);
  const [selectedInterests, setSelectedInterests] = useState([]);
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [gender, setGender] = useState("");
  const [lookingForGender, setLookingForGender] = useState("");
  const [lookingForAgeRange, setLookingForAgeRange] = useState({ min: 18, max: 99 });
  const [professional, setProfessional] = useState("");
  const [age, setAge] = useState("");
  const [profilePic, setProfilePic] = useState(null);
  const [previewPic, setPreviewPic] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

   // Fetch initial data for interests and locations
   useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${apiUrl}/register/data`);
        setInterests(response.data.interests || []);
        setLocations(response.data.locations || []);
        if (response.data.locations && response.data.locations.length > 0) {
          setSelectedLocation(response.data.locations[0]);
        }
      } catch (err) {
        console.error("Error fetching data:", err); // Debugging log
        setError("Failed to load data. Please try again.");
      }
    };
    fetchData();
  }, []);

  // Handle profile picture change
  const handleProfilePicChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePic(file);
      setPreviewPic(URL.createObjectURL(file));
    }
  };

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError("");
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error]);
  
  const handleRegister = async () => {
    // Validate required fields
    if (
      !username ||
      !email ||
      !password ||
      !passwordAgain ||
      !aboutMe ||
      selectedInterests.length < 3 ||  // Check if at least 3 interests are selected
      selectedInterests.length > 20 || // Check if no more than 20 interests are selected}
      !selectedLocation ||
      !gender ||
      !lookingForGender ||
      !age ||
      !lookingForAgeRange.min ||
      !lookingForAgeRange.max ||
      !professional ||
      !professional 
    ) {
      setError("All fields are required. You must select at least 3 interests but no more than 20.");
      return;
    }

    if (lookingForAgeRange.min > lookingForAgeRange.max) {
      setError("Minimum age range must be less than maximum age range.");
      return;
    }
  


    const formData = new FormData();
    formData.append("username", username);
    formData.append("email", email);
    formData.append("password", password);
    formData.append("aboutMe", aboutMe);
    formData.append("interests", JSON.stringify(selectedInterests));
    formData.append("location", selectedLocation);
    formData.append("gender", gender);
    formData.append("lookingForGender", lookingForGender);
    formData.append("lookingForAgeRange", JSON.stringify(lookingForAgeRange));
    formData.append("professional", professional);
    formData.append("age", age);
    if (profilePic) {
      formData.append("profilePic", profilePic);
    }

    try {
      // Register the user
      const registerResponse = await axios.post(`${apiUrl}/register`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (registerResponse.status === 201) {
        // Set the token in cookie
        document.cookie = `token=${registerResponse.data.token}; path=/; SameSite=None; Secure`;
        
        // Update the app state
        setIsLoggedIn(true);
        setAppUsername(username);
        
        // Navigate to home page
        navigate('/');
      }
    } catch (err) {
      console.error("Failed to register:", err);
      setError(err.response?.data || "Registration failed. Please try again.");
    }
  };

  return (
    <div className="register-container">
      <h2>Register</h2>
      {error && <p className="error-message">{error}</p>}

      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Confirm Password"
        value={passwordAgain}
        onChange={(e) => setPasswordAgain(e.target.value)}
        required
      />

      <textarea
        placeholder="About Me"
        value={aboutMe}
        onChange={(e) => setAboutMe(e.target.value)}
        required
      />

      <div className="form-group">
        <label htmlFor="interests">Interests:</label>
        <select
          id="interests"
          onChange={(e) => {
            const selected = e.target.value;
            if (selected && !selectedInterests.includes(selected)) {
              setSelectedInterests([...selectedInterests, selected]);
            }
          }}
        >
          <option value="">Select Interest</option>
          {interests.map((interest, index) => (
            <option key={index} value={interest}>
              {interest}
            </option>
          ))}
        </select>
        <div className="selected-interests">
          {selectedInterests.map((interest, index) => (
            <div key={index} className="interest-tag">
              {interest}
              <button
                type="button"
                className="remove-btn"
                onClick={() =>
                  setSelectedInterests(
                    selectedInterests.filter((i) => i !== interest)
                  )
                }
              >
                ✖
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="form-group">
        <label htmlFor="location">Location:</label>
        <select
          id="location"
          value={selectedLocation}
          onLoad={(e) => setSelectedLocation(e.target.value)}
          onChange={(e) => setSelectedLocation(e.target.value)}
        >
          {locations.map((location, index) => (
            <option key={index} value={location}>
              {location}
            </option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="gender">Gender:</label>
        <select
          id="gender"
          value={gender}
          onChange={(e) => setGender(e.target.value)}
        >
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </select>
        <select
                value={lookingForGender}
                onChange={(e) => setLookingForGender(e.target.value)}
            >
                <option value="">Looking For Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="any">Any</option>
            </select>
        </div>
      
      <div className="form-group">
        <label htmlFor="lookingForAgeRange">Looking for Age Range:</label>
        <div className="age-range-inputs">
          <span>Min:</span>
          <input
            type="number"
            id="ageRangeMin"
            value={lookingForAgeRange.min}
            min="18"
            max="99"
            onChange={(e) => setLookingForAgeRange({ ...lookingForAgeRange, min: e.target.value })}
          />
          <span>Max:</span>
          <input
            type="number"
            id="ageRangeMax"
            value={lookingForAgeRange.max}
            min="18"
            max="99"
            onChange={(e) => setLookingForAgeRange({ ...lookingForAgeRange, max: e.target.value })}
          />
        </div>
      </div>

      <div className="form-group">
        <label htmlFor="professional">Are you a professional player?</label>
        <select
          id="professional"
          value={professional}
          onChange={(e) => setProfessional(e.target.value)}
        >
          <option value="">Select an option</option>
          <option value="yes">Yes</option>
          <option value="no">No</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="age">Age:</label>
        <input
          type="number"
          id="age"
          value={age}
          min="18"
          max="99"
          onChange={(e) => setAge(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label htmlFor="profilePic">Profile Picture:</label>
        {previewPic && (
          <div className="profile-pic-preview">
            <img src={previewPic} alt="Profile Preview" />
          </div>
        )}
        <input
          id="profilePic"
          type="file"
          accept="image/*"
          onChange={handleProfilePicChange}
        />
      </div>

      <button className="button button-primary" onClick={handleRegister}>
        Register
      </button>
      <p>Already have an account? <Link to="/">Login here</Link></p>
    </div>
  );
};
export default Register;
