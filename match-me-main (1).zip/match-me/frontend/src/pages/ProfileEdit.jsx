import React, { useState, useEffect } from "react";
import axios from "axios";
import "./styles/edit.css";

const apiUrl = process.env.REACT_APP_BACKEND_URL;

const ProfileEdit = () => {
  const [aboutMe, setAboutMe] = useState("");
  const [lookingForAgeRange, setLookingForAgeRange] = useState({ min: 18, max: 99 });
  const [professional, setProfessional] = useState(""); 
  const [interests, setInterests] = useState([]);
  const [selectedInterests, setSelectedInterests] = useState([]);
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [gender, setGender] = useState("");
  const [lookingForGender, setLookingForGender] = useState("");
  const [profilePic, setProfilePic] = useState(null);
  const [previewPic, setPreviewPic] = useState("");
  const [currentProfilePic, setCurrentProfilePic] = useState("");
  const [removeProfilePic, setRemoveProfilePic] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [age, setAge] = useState("");

  const getToken = () => {
    const token = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));
    return token ? token.split("=")[1] : null;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const token = getToken();

        const { data } = await axios.get(`${apiUrl}/profile/edit`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });

        setInterests(data.interests);
        setLocations(data.locations);

        const profileResponse = await axios.get(`${apiUrl}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });

        const profile = profileResponse.data;

        console.log("Profile Loaded: ", profile); // Debugging loaded profile

        if (profile) {

          const maxAge = profile.lookingForAgeRange[1]
          const minAge = profile.lookingForAgeRange[0]
          setAboutMe(profile.aboutMe || "");
          setSelectedInterests(profile.interests || []);
          setSelectedLocation(profile.location || "");
          setGender(profile.gender || "");
          setLookingForGender(profile.lookingForGender || "");
          setLookingForAgeRange( { min: minAge, max: maxAge });
          setProfessional(profile.professional || ""); // Load professional status
          setAge(profile.age || "");
          
          // Set both the current profile pic and the preview
          if (profile.profileImage) {
            setCurrentProfilePic(profile.profileImage);
            if (profile.profileImage.startsWith("/")) {
              setPreviewPic(`${process.env.REACT_APP_BACKEND_URL}${profile.profileImage}`);
            } else {
              setPreviewPic(`${process.env.REACT_APP_BACKEND_URL}/${profile.profileImage}`);
            }
            console.log("Profile Pic Loaded:", profile.profileImage); // Debugging statement
            console.log("Preview pic: ", previewPic, " Should be: ", `${process.env.REACT_APP_BACKEND_URL}${profile.profileImage}`); // Debugging statement)
          }
        }
        
        setLoading(false);
      } catch (err) {
        console.error("Failed to load data:", err);
        setError("Failed to load data");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSave = async () => {
    try {
      const token = getToken();
      const formData = new FormData();
      formData.append("aboutMe", aboutMe);
      formData.append("interests", JSON.stringify(selectedInterests));
      formData.append("location", selectedLocation);
      formData.append("gender", gender);
      formData.append("lookingForGender", lookingForGender);
      formData.append("lookingForAgeRange", JSON.stringify(lookingForAgeRange));
      formData.append("professional", professional); // Append professional status
      formData.append("age", age);
      formData.append("removeProfilePic", removeProfilePic.toString());
  
      // Only append profile pic if we're not removing it and have a new one
      if (!removeProfilePic && profilePic && typeof profilePic !== 'string') {
        formData.append("profilePic", profilePic);
        console.log("Appended profile pic")
      }

      console.log(formData)
  
      const response = await axios.post(`${apiUrl}/profile/edit`, formData, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
  
      // Update the preview and current profile pic with the returned profile image URL
      if (response.data && response.data.profileImage) {
        setPreviewPic(`${process.env.REACT_APP_BACKEND_URL}/${response.data.profileImage}`);
        setCurrentProfilePic(response.data.profileImage);
      }
  
      setError("");
      setRemoveProfilePic(false); // Reset the remove flag after saving
      setProfilePic(null); // Reset the new profile pic after saving
      alert("Profile updated successfully");
    } catch (err) {
      console.error("Failed to update profile:", err);
      setError("Failed to update profile");
    }
  };

  const handleProfilePicChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePic(file);
      setPreviewPic(URL.createObjectURL(file));
      console.log("Profile Pic changed:", URL.createObjectURL(file)); // Debugging statement
      setRemoveProfilePic(false); // If user selects a new pic, they're not removing it
    }
  };

  const handleRemoveProfilePic = () => {
    setRemoveProfilePic(true);
    setProfilePic(null);
    // Show a placeholder based on gender
    const defaultPic = gender === "Male" 
      ? `${process.env.REACT_APP_BACKEND_URL}/static/avatars/male_avatar.png` 
      : gender === "Female" 
        ? `${process.env.REACT_APP_BACKEND_URL}/static/avatars/female_avatar.png` 
        : "/static/defaults/default_generic.png";
    setPreviewPic(defaultPic);
  };

  const handleCancelChanges = () => {
    // Reset to the current profile pic
    setPreviewPic(`${process.env.REACT_APP_BACKEND_URL}${currentProfilePic}`);
    setProfilePic(null);
    setRemoveProfilePic(false);
  };

  // Determine if profile pic has been changed
  const profilePicChanged = removeProfilePic || 
    (profilePic && typeof profilePic !== 'string');

  return (
    <div className="profile-edit-container">
      <h2>Edit Profile</h2>
      {error && <p className="error-message">{error}</p>}
      
      {loading ? (
        <p>Loading your profile...</p>
      ) : (
        <>
          <div className="form-group">
            <label htmlFor="aboutMe">About Me:</label>
            <textarea
              id="aboutMe"
              value={aboutMe}
              onChange={(e) => setAboutMe(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label htmlFor="interests">Interests:</label>
            <select
              id="interests"
              onChange={(e) => {
                const selected = e.target.value;
                if (selected && !selectedInterests.includes(selected)) {
                  setSelectedInterests([...selectedInterests, selected]);
                }
              }}
            >
              <option value="">Select Interest</option>
              {interests.map((interest, index) => (
                <option key={index} value={interest}>
                  {interest}
                </option>
              ))}
            </select>
          </div>

          <div className="selected-interests">
            {selectedInterests.map((interest, index) => (
              <div key={index} className="interest-tag">
                {interest}
                <button
                  type="button"
                  className="remove-btn"
                  onClick={() =>
                    setSelectedInterests(
                      selectedInterests.filter((i) => i !== interest)
                    )
                  }
                >
                  ✖
                </button>
              </div>
            ))}
          </div>

          <div className="form-group">
            <label htmlFor="location">Location:</label>
            <select
              id="location"
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
            >
              {locations.map((location, index) => (
                <option key={index} value={location}>
                  {location}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="gender">Gender:</label>
            <select
              id="gender"
              value={gender}
              onChange={(e) => setGender(e.target.value)}
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="lookingForGender">Looking For Gender:</label>
            <select
              id="lookingForGender"
              value={lookingForGender}
              onChange={(e) => setLookingForGender(e.target.value)}
            >
              <option value="">Select Preference</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="any">Any</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="lookingForAgeRange">Looking for Age Range:</label>
            <div className="age-range-inputs">
              <input
                type="number"
                id="ageRangeMin"
                value={lookingForAgeRange.min}
                min="18"
                max="99"
                onChange={(e) => setLookingForAgeRange({ ...lookingForAgeRange, min: e.target.value })}
              />
              <span>to</span>
              <input
                type="number"
                id="ageRangeMax"
                value={lookingForAgeRange.max}
                min="18"
                max="99"
                onChange={(e) => setLookingForAgeRange({ ...lookingForAgeRange, max: e.target.value })}
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="professional">Are you a professional player?</label>
            <select
              id="professional"
              value={professional}
              onChange={(e) => setProfessional(e.target.value)}
            >
              <option value="">Select an option</option>
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="age">Age:</label>
            <input
              type="number"
              id="age"
              value={age}
              min="18"
              max="99"
              onChange={(e) => setAge(e.target.value)}
            />
          </div>

          <div className="form-group profile-picture-container">
            <label>Profile Picture:</label>
            <div className="profile-pic-actions">
              <div className="upload-section">
                <input
                  id="profilePic"
                  type="file"
                  accept="image/*"
                  onChange={handleProfilePicChange}
                  disabled={removeProfilePic}
                />
                <div className="pic-buttons">
                  <button 
                    type="button" 
                    className="button button-danger"
                    onClick={handleRemoveProfilePic}
                    disabled={!currentProfilePic || removeProfilePic}
                  >
                    Remove Profile Picture
                  </button>
                  
                  {profilePicChanged && (
                    <button
                      type="button"
                      className="button button-secondary"
                      onClick={handleCancelChanges}
                    >
                      Cancel Changes
                    </button>
                  )}
                </div>
              </div>
              
              {/* Always show preview if there's any picture to preview */}
              {previewPic && (
                <div className="preview-section">
                  <img src={`${previewPic}`} alt="Profile Preview" className="profile-preview" />
                  {removeProfilePic && (
                    <p className="status-message">Default profile picture will be used</p>
                  )}
                  {profilePic && typeof profilePic !== 'string' && (
                    <p className="status-message">New profile picture selected</p>
                  )}
                </div>
              )}
            </div>
          </div>

          <button className="button button-primary" onClick={handleSave}>
            Save
          </button>
        </>
      )}
    </div>
  );
};

export default ProfileEdit;