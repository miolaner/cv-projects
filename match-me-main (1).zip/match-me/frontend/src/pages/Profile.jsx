import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './styles/profile.css';

const Profile = () => {
  const [profile, setProfile] = useState({});
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Utility to get the token from cookies
  const getToken = () => {
    const token = document.cookie.split('; ').find(row => row.startsWith('token='));
    return token ? token.split('=')[1] : null;
  };

  // Fetch profile data on component mount
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = getToken();
        const response = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        setProfile(response.data);
      } catch (err) {
        console.error("Error fetching profile information:", err);
        setError("An error occurred while fetching profile information.");
      }
    };

    fetchProfile();
  }, []);

  // Navigate to edit profile page
  const handleEdit = () => {
    navigate('/profile/edit');
  };

  return (
    <div className="profile-container">
      <h2 className="profile-header">Profile</h2>
      {error && <p className="error-message">{error}</p>}
      {profile.username ? (
        <div className="profile-card">
          {console.log( `${process.env.REACT_APP_BACKEND_URL}${profile.profileImage}`)}
          <img
            src={profile.profileImage ? `${process.env.REACT_APP_BACKEND_URL}/${profile.profileImage}` : "/default-profile.png"} // Use the profile picture URL from the backend
            alt={`${profile.username}'s profile`}
            className="profile-image"
          />
          <div className="profile-details">
            <h3>{profile.username}</h3>
            <p><strong>Email:</strong> {profile.email}</p>
            <p><strong>About Me:</strong> {profile.aboutMe}</p>
            <p><strong>Age:</strong> {profile.age}</p>
            <p><strong>Interests:</strong> {profile.interests?.join(', ')}</p>
            <p><strong>Location:</strong> {profile.location}</p>
            <p><strong>Gender:</strong> {profile.gender}</p>
            <p><strong>Looking For Gender:</strong> {profile.lookingForGender}</p>
            <p><strong>Looking for between ages:</strong>{profile.lookingForAgeRange[0]} - {profile.lookingForAgeRange[1]} </p>
            <button className="button button-primary" onClick={handleEdit}>
              Edit Profile
            </button>
          </div>
        </div>
      ) : (
        <p>Loading profile...</p>
      )}
    </div>
  );
};

export default Profile;
