import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './styles/chat.css';
import { useNotifications } from '../context/NotificationContext';
import UserProfilePopup from '../components/UserProfilePopup';

const Chat = () => {
  const { setHasUnreadMessages, unreadChats, setUnreadChats } = useNotifications();

  const saveUnreadCounts = (counts) => {
    localStorage.setItem('unreadCounts', JSON.stringify(counts));
  };

  const loadUnreadCounts = () => {
    const saved = localStorage.getItem('unreadCounts');
    return saved ? JSON.parse(saved) : {};
  };

  const [connections, setConnections] = useState([]);
  const [activeChats, setActiveChats] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState('');
  const [showChatPopup, setShowChatPopup] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [user, setUser] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMoreMessages, setHasMoreMessages] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const getToken = () => {
    const token = document.cookie.split('; ').find(row => row.startsWith('token='));
    return token ? token.split('=')[1] : null;
  };

  const fetchChats = async () => {
    try {
        const token = getToken();
        
        const connectionsResponse = await axios.get(
            `${process.env.REACT_APP_BACKEND_URL}/connections`,
            {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            }
        );

        // Add null check
        if (!connectionsResponse.data || connectionsResponse.data.length === 0) {
            setConnections([]);
            setActiveChats([]);
            return;
        }

        // 1. Get array of user IDs
        const connectionsResponseData = await axios.get(
            `${process.env.REACT_APP_BACKEND_URL}/connections`,
            {
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                withCredentials: true
            }
        );
        console.log("User IDs received:", connectionsResponseData.data);

        // 2. Get details for each connection
        const chatsPromises = connectionsResponseData.data.map(async (userId) => {
            console.log("Processing user ID:", userId);
            
            // Get connection details
            const detailsResponse = await axios.get(
                `${process.env.REACT_APP_BACKEND_URL}/connections/${userId}/details`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true
                }
            );
            console.log("Connection details for user", userId, ":", detailsResponse.data);
            
            // Get messages using connection ID
            const messagesResponse = await axios.get(
                `${process.env.REACT_APP_BACKEND_URL}/connections/${detailsResponse.data.connectionId}/messages?page=1`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true
                }
            );

            // Get user details
            const userResponse = await axios.get(
                `${process.env.REACT_APP_BACKEND_URL}/users/${userId}`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true
                }
            );

            return {
                connectionId: detailsResponse.data.connectionId,
                otherUser: userResponse.data,
                messages: messagesResponse.data.messages,
                lastMessageTime: messagesResponse.data.messages.length > 0 
                    ? new Date(messagesResponse.data.messages[messagesResponse.data.messages.length - 1].timestamp).getTime()
                    : 0,
                createdAt: detailsResponse.data.createdAt
            };
        });

        const chatsData = await Promise.all(chatsPromises);

        // Sort chats by last message time (most recent first)
        chatsData.sort((a, b) => b.lastMessageTime - a.lastMessageTime);

        // Separate into active chats and matches
        const chatsWithMessages = chatsData.filter(chat => chat.messages.length > 0);
        const matchesWithoutMessages = chatsData.filter(chat => chat.messages.length === 0);
        
        // Sort matches by creation time (newest first)
        matchesWithoutMessages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        setActiveChats(chatsWithMessages);
        setConnections(matchesWithoutMessages);

        // Update selected chat if needed
        if (selectedChat) {
            const updatedChat = chatsData.find(
                chat => chat.connectionId === selectedChat.connectionId
            );
            if (updatedChat) {
                setSelectedChat(updatedChat);
            }
        }
    } catch (err) {
        console.error("Error in fetchChats:", err);
        if (err.response?.status === 404) {
            // Handle 404 - no connections
            setConnections([]);
            setActiveChats([]);
            setError("No connections found. Try matching with some profiles first!");
        } else {
            setError(`Failed to fetch chats: ${err.response?.data || err.message}`);
        }
    }
};

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedChat) return;

    try {
        const token = getToken();
        
        // Get connection details first
        const detailsResponse = await axios.get(
            `${process.env.REACT_APP_BACKEND_URL}/connections/${selectedChat.otherUser.id}/details`,
            {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            }
        );
        const connectionId = detailsResponse.data.connectionId;

        const response = await axios.post(
            `${process.env.REACT_APP_BACKEND_URL}/messages`,
            {
                connectionId,  // Use the connectionId from details
                content: newMessage
            },
            {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            }
        );
        
        // Just append the new message instead of refetching
        setSelectedChat(prev => ({
            ...prev,
            messages: [...prev.messages, response.data]
        }));

        setNewMessage('');
        
        // Update active chats list without refetching messages
        const updatedChat = {
            ...selectedChat,
            lastMessageTime: new Date().getTime()
        };
        
        setActiveChats(prev => {
            const others = prev.filter(chat => chat.connectionId !== selectedChat.connectionId);
            return [updatedChat, ...others].sort((a, b) => b.lastMessageTime - a.lastMessageTime);
        });

        // Move user from "New Matches" to "Active Conversations"
        setConnections(prev => prev.filter(conn => conn.connectionId !== selectedChat.connectionId));

        // Update unread status in context
        setUnreadChats(prev => {
            const updated = {
                ...prev,
                [connectionId]: false
            };
            
            // Check if there are ANY remaining unread chats
            const hasAnyUnread = Object.values(updated).some(isUnread => isUnread);
            setHasUnreadMessages(hasAnyUnread);
            
            return updated;
        });

    } catch (err) {
        console.error("Send message error:", err);
        setError(`Failed to send message: ${err.response?.data || err.message}`);
    }
};

  const handleChatSelect = async (chat) => {
    console.log("handleChatSelect called with chat:", chat);
    if (!chat || !chat.connectionId) {
        console.error("Invalid chat selected:", chat);
        return;
    }
    
    setSelectedChat(chat);
    setShowChatPopup(true);
    setCurrentPage(1);
    
    try {
        const token = getToken();
        
        // First get connection details
        const detailsResponse = await axios.get(
            `${process.env.REACT_APP_BACKEND_URL}/connections/${chat.otherUser.id}/details`,
            {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            }
        );

        // Then use connectionId from details for all operations
        const connectionId = detailsResponse.data.connectionId;
        
        // Mark messages as read
        await axios.post(
            `${process.env.REACT_APP_BACKEND_URL}/messages/read`,
            { connectionId },
            {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            }
        );

        // Update unread status in context
        setUnreadChats(prev => {
            const updated = {
                ...prev,
                [connectionId]: false
            };
            
            // Check if there are ANY remaining unread chats
            const hasAnyUnread = Object.values(updated).some(isUnread => isUnread);
            setHasUnreadMessages(hasAnyUnread);
            
            return updated;
        });

        // Fetch first page of messages
        await fetchMessages(connectionId, 1);
        
    } catch (err) {
        console.error("Failed to handle chat selection:", err);
    }
};

  const fetchMessages = async (connectionId, page = 1) => {
    try {
        // Add check for undefined connectionId
        if (!connectionId) {
            console.error("Attempted to fetch messages with undefined connectionId");
            return;
        }

        setIsLoadingMore(page > 1);
        const token = getToken();
        console.log("Fetching messages for connection:", connectionId); // Debug log

        const response = await axios.get(
            `${process.env.REACT_APP_BACKEND_URL}/connections/${connectionId}/messages?page=${page}`,
            {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            }
        );
        
        const newMessages = response.data.messages;
        setHasMoreMessages(response.data.total > page * 5);

        // Store scroll position before updating messages
        const messagesContainer = document.querySelector('.popup-messages-container');
        const scrollPos = messagesContainer?.scrollTop || 0;

        if (page === 1) {
            setSelectedChat(prev => ({
                ...prev,
                messages: newMessages
            }));
        } else {
            setSelectedChat(prev => ({
                ...prev,
                messages: [...newMessages, ...prev.messages]
            }));
            // Restore scroll position after adding messages
            if (messagesContainer) {
                setTimeout(() => {
                    messagesContainer.scrollTop = scrollPos;
                }, 0);
            }
        }
    } catch (err) {
        console.error("Failed to fetch messages:", err);
    } finally {
        setIsLoadingMore(false);
    }
  };

  const handleLoadMore = () => {
    if (selectedChat) {
      setCurrentPage(prev => prev + 1);
      fetchMessages(selectedChat.connectionId, currentPage + 1);
    }
  };

  useEffect(() => {
    fetchChats();
  }, []);

  useEffect(() => {
    if (selectedChat && showChatPopup) {
        const messagesContainer = document.querySelector('.popup-messages-container');
        if (messagesContainer) {
            if (isLoadingMore) {
                // Keep scroll position when loading more
                const oldHeight = messagesContainer.scrollHeight;
                setTimeout(() => {
                    const newHeight = messagesContainer.scrollHeight;
                    messagesContainer.scrollTop = newHeight - oldHeight;
                }, 0);
            } else {
                // Scroll to bottom for new messages
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
        }
    }
  }, [selectedChat?.messages?.length, showChatPopup, isLoadingMore]);

  useEffect(() => {
    const handleNewMessage = async (e) => {
        const { connectionId, message } = e.detail;
        
        // Update active chats order regardless of selected chat
        setActiveChats(prev => {
            const updatedChats = [...prev];
            const chatIndex = updatedChats.findIndex(chat => chat.connectionId === connectionId);
            
            if (chatIndex !== -1) {
                const chat = updatedChats[chatIndex];
                // Remove chat from current position
                updatedChats.splice(chatIndex, 1);
                // Add chat to beginning of array with updated lastMessageTime
                updatedChats.unshift({
                    ...chat,
                    messages: [...chat.messages, message],
                    lastMessageTime: new Date(message.timestamp).getTime()
                });
            }
            
            return updatedChats;
        });

        if (selectedChat?.connectionId === connectionId) {
            // Append the new message
            setSelectedChat(prev => ({
                ...prev,
                messages: [...prev.messages, message]
            }));

            // If chat is open and we're the receiver, mark as read
            if (showChatPopup && message.senderId !== user?.id) {
                try {
                    const token = getToken();
                    await axios.post(
                        `${process.env.REACT_APP_BACKEND_URL}/messages/read`,
                        { connectionId },
                        {
                            headers: { Authorization: `Bearer ${token}` },
                            withCredentials: true
                        }
                    );

                    // Update unread status
                    setUnreadChats(prev => {
                        const updated = {
                            ...prev,
                            [connectionId]: false
                        };
                        
                        // Check if there are ANY remaining unread chats
                        const hasAnyUnread = Object.values(updated).some(isUnread => isUnread);
                        setHasUnreadMessages(hasAnyUnread);
                        
                        return updated;
                    });
                } catch (err) {
                    console.error("Failed to mark messages as read:", err);
                }
            } else if (message.senderId !== user?.id) {
                // If chat is not open and we're the receiver, mark as unread
                setUnreadChats(prev => {
                    const updated = {
                        ...prev,
                        [connectionId]: true
                    };
                    setHasUnreadMessages(true);
                    return updated;
                });
            }
        } else if (message.senderId !== user?.id) {
            // Message is for a different chat and we're the receiver
            setUnreadChats(prev => {
                const updated = {
                    ...prev,
                    [connectionId]: true
                };
                setHasUnreadMessages(true);
                return updated;
            });
        }
    };

    window.addEventListener('new-chat-message', handleNewMessage);
    return () => window.removeEventListener('new-chat-message', handleNewMessage);
}, [selectedChat, showChatPopup, user]);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = getToken();
        const response = await axios.get(
          `${process.env.REACT_APP_BACKEND_URL}/me`,
          {
            headers: { Authorization: `Bearer ${token}` },
            withCredentials: true
          }
        );
        setUser(response.data);
      } catch (err) {
        console.error("Failed to fetch user info:", err);
      }
    };
    fetchUser();
  }, []);

  const renderMessagesWithDateSeparators = (messages) => {
    let currentDate = null;
    return messages.map((message, index) => {
        const messageDate = new Date(message.timestamp);
        const dateStr = messageDate.toLocaleDateString();
        
        let dateSeparator = null;
        if (dateStr !== currentDate) {
            currentDate = dateStr;
            dateSeparator = (
                <div key={`date-${dateStr}`} className="date-separator">
                    <span className="date-line"></span>
                    <span className="date-text">{dateStr}</span>
                    <span className="date-line"></span>
                </div>
            );
        }

        return (
            <React.Fragment key={`msg-group-${message.id}`}>
                {dateSeparator}
                <div
                    className={`message ${message.senderId === selectedChat.otherUser.id ? 'received' : 'sent'}`}
                >
                    <p>{message.content}</p>
                    <span className="timestamp">
                        {message.timestamp ? new Date(message.timestamp).toLocaleTimeString() : ''}
                    </span>
                </div>
            </React.Fragment>
        );
    });
  };

  return (
    <div className="chat-page-container">
      <div className="matches-section">
        <h2>New Matches</h2>
        <div className="matches-list">
          {connections.length === 0 ? (
            <div className="empty-state">
              No new matches yet. Try liking some profiles!
            </div>
          ) : (
            connections.map(connection => (
              <div
                key={connection.connectionId}
                className="match-item"
                onClick={() => handleChatSelect(connection)}
              >
                <h3>{connection.otherUser.username}</h3>
                <p>Start chatting!</p>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="conversations-section">
        <h2>Active Conversations</h2>
        <div className="conversations-list">
          {activeChats.length === 0 ? (
            <div className="empty-state">
              No active conversations. Start chatting with your matches!
            </div>
          ) : (
            activeChats.map(chat => (
              <div
                key={chat.connectionId}
                className={`conversation-item ${unreadChats[chat.connectionId] ? 'unread' : ''}`}
                onClick={() => handleChatSelect(chat)}
              >
                <h3>{chat.otherUser.username}</h3>
                {unreadChats[chat.connectionId] > 0 && (
                  <div className="unread-badge" />
                )}
                {chat.messages.length > 0 && (
                  <p className={`last-message ${unreadChats[chat.connectionId] ? 'unread' : ''}`}>
                    {chat.messages[chat.messages.length - 1].content}
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {showChatPopup && selectedChat && (
        <>
          <div className="chat-popup-overlay" onClick={() => setShowChatPopup(false)} />
          <div className="chat-popup">
            <div className="popup-header">
              <h3>
                Chat with{' '}
                <span 
                  className="clickable-username"
                  onClick={() => setShowUserProfile(true)}
                >
                  {selectedChat.otherUser.username}
                </span>
              </h3>
              <button 
                className="close-popup"
                onClick={() => setShowChatPopup(false)}
              >
                ×
              </button>
            </div>
            <div className="popup-messages-container">
              {hasMoreMessages && (
                <button 
                  className="load-more-btn" 
                  onClick={handleLoadMore}
                >
                  Load More Messages
                </button>
              )}
              {renderMessagesWithDateSeparators(selectedChat.messages)}
            </div>
            <div className="popup-message-input">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Type a message..."
              />
              <button onClick={sendMessage}>Send</button>
            </div>
          </div>
          {showUserProfile && (
            <UserProfilePopup
              userId={selectedChat.otherUser.id}
              connectionId={selectedChat.connectionId}
              onClose={() => setShowUserProfile(false)}
              onConnectionRemoved={() => {
                setShowChatPopup(false);
                setSelectedChat(null);
                fetchChats();
              }}
            />
          )}
        </>
      )}

      {error && <div className="error-message">{error}</div>}
    </div>
  );
};

export default Chat;
