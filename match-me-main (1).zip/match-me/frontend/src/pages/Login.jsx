import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './styles/styles.css';
import { webSocketService } from '../services/websocket';
import { useNotifications } from '../context/NotificationContext';

const Login = ({ setUsername, setIsLoggedIn }) => {
  const [usernameInput, setUsernameInput] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { checkUnreadMessages } = useNotifications();

  const handleLogin = async () => {
    try {
      console.log('🔑 Attempting login...');
      const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/login`, 
        { username: usernameInput, password }
      );
      
      if (response.status === 200) {
        console.log('✅ Login successful');
        // Set cookie first to trigger the effect
        document.cookie = `token=${response.data.token}; path=/`;
        console.log('🍪 Token set in cookie');
        
        setUsername(usernameInput);
        setIsLoggedIn(true);
        webSocketService.connect();
        
        // Small delay to ensure cookie is set
        setTimeout(() => {
          navigate('/');
        }, 100);
      }
    } catch (err) {
      console.error('❌ Login failed:', err);
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <input
        type="text"
        placeholder="Username"
        value={usernameInput}
        onChange={(e) => setUsernameInput(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
