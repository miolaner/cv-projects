import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './styles/styles.css';

const Home = ({ username, setUsername, setIsLoggedIn }) => {
  const navigate = useNavigate();


  const handleLogout = () => {
    console.log("Logging out..."); // Debugging statement
    setIsLoggedIn(false);
    document.cookie = 'token=; Max-Age=0; path=/';
    navigate('/');
  };

  if (!username) {
    console.log("No username found, returning null."); // Debugging statement
    return null; // or a loading spinner
  }

  console.log("Rendering Home component with username:", username); // Debugging statement
  return (
    <div className="home-container">
      <h1>Welcome, {username}!</h1>
    </div>
  );
};

export default Home;
