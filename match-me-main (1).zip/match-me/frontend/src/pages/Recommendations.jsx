import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import './styles/recommendations.css';

const Recommendations = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [error, setError] = useState("");

  const getToken = () => {
    const token = document.cookie.split('; ').find(row => row.startsWith('token='));
    return token ? token.split('=')[1] : null;
  };

  const fetchPendingRequests = useCallback(async () => {
    try {
      const token = getToken();
      const response = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/pending`, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      const pendingIDs = response.data || [];
      const pendingProfiles = await Promise.all(pendingIDs.map(async (userID) => {
        const userResponse = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/users/${userID}`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        const bioResponse = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/users/${userID}/bio`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        const profileInfo = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/users/${userID}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        return { ...userResponse.data, bio: bioResponse.data.bio, aboutMe: profileInfo.data.aboutMe };
      }));

      setPendingRequests(pendingProfiles);
      console.log("Pending requests fetched successfully:", pendingProfiles);

      // Fetch recommendations after pending requests are fetched
      fetchRecommendations(pendingProfiles);
    } catch (err) {
      setError("An error occurred while fetching pending requests.");
      console.log("Error fetching pending requests:", err);
    }
  }, []);

  const fetchRecommendations = useCallback(async (pendingProfiles) => {
    try {
      const token = getToken();
      const response = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/recommendations`, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });

      const userIDs = response.data || [];
      const userProfiles = await Promise.all(userIDs.map(async (userID) => {
        const userResponse = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/users/${userID}`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        const bioResponse = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/users/${userID}/bio`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        const profileInfo = await axios.get(`${process.env.REACT_APP_BACKEND_URL}/users/${userID}/profile`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        return { ...userResponse.data, bio: bioResponse.data.bio, aboutMe: profileInfo.data.aboutMe };
      }));

      // Filter out recommendations that are in pending requests
      const filteredRecommendations = userProfiles.filter(
        (profile) => !pendingProfiles.some((pending) => pending.id === profile.id)
      );

      setRecommendations(filteredRecommendations);
      console.log("Recommendations fetched successfully:", filteredRecommendations);
    } catch (err) {
      setError("An error occurred while fetching recommendations.");
      console.log("Error fetching recommendations:", err);
    }
  }, []);

  useEffect(() => {
    fetchPendingRequests();
  }, [fetchPendingRequests]);

  const handleDislike = async (userID) => {
    try {
      const token = getToken();
      await axios.post(`${process.env.REACT_APP_BACKEND_URL}/dislike/${userID}`, { user1ID: userID, user2ID: userID }, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
      fetchPendingRequests();
    } catch (err) {
      setError("An error occurred while processing dislike.");
      console.log("Error processing dislike:", err);
    }
  };

  const handleLike = async (userID) => {
    try {
      const token = getToken();
      await axios.post(`${process.env.REACT_APP_BACKEND_URL}/like/${userID}`, { user1ID: userID, user2ID: userID }, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
      fetchPendingRequests();
    } catch (err) {
      setError("An error occurred while processing like.");
      console.log("Error processing like:", err);
    }
  };

  const handleReject = async (userID) => {
    try {
      await handleDislike(userID);
      setPendingRequests((prev) => prev.filter((req) => req.id !== userID));
    } catch (err) {
      setError("An error occurred while processing reject.");
      console.log("Error processing reject:", err);
    }
  };

  const handleAccept = async (userID) => {
    try {
      await handleLike(userID);
      setPendingRequests((prev) => prev.filter((req) => req.id !== userID));
    } catch (err) {
      setError("An error occurred while processing accept.");
      console.log("Error processing accept:", err);
    }
  };

  return (
    <div className="recommendations-container">
      {pendingRequests.length > 0 && (
        <div className="pending-requests-section">
          <h3>Pending Requests</h3>
          <div className="pending-requests-list">
            {pendingRequests.map((req, index) => (
              <div key={index} className="pending-request-card recommendation-card" style={{ backgroundColor: 'lightblue' }}>
                <img src={req.profilePicURL ? `${process.env.REACT_APP_BACKEND_URL}/${req.profilePicURL}` : (req.bio.gender === 'female' ? `${process.env.REACT_APP_BACKEND_URL}/static/avatars/female_avatar.png` : `${process.env.REACT_APP_BACKEND_URL}/static/avatars/male_avatar.png`)} alt={`${req.username}'s profile`} className="pending-request-profile-image recommendation-profile-image" />
                <div className="pending-request-content recommendation-content">
                  <h3 className="pending-request-username recommendation-username">{req.username}</h3>
                  <p><strong>About Me:</strong> {req.aboutMe}</p>
                  <p><strong>Interests:</strong> {(req.bio.Interests || []).join(', ')}</p>
                  <p><strong>Location:</strong> {req.bio.Location}</p>
                </div>
                <div className="action-buttons">
                  <button className="nav-button reject-button" onClick={() => handleReject(req.id)}>Reject</button>
                  <button className="nav-button accept-button" onClick={() => handleAccept(req.id)}>Accept</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      <h2 className="recommendations-header">Recommendations</h2>
      {error && <p className="error-message">{error}</p>}
      {recommendations.length > 0 ? (
        <div className="recommendations-list">
          {recommendations.map((rec, index) => (
            <div key={index} className="recommendation-card">
              <img src={rec.profilePicURL ? `${process.env.REACT_APP_BACKEND_URL}/${rec.profilePicURL}` : (rec.bio.gender === 'female' ? `${process.env.REACT_APP_BACKEND_URL}/static/avatars/female_avatar.png` : `${process.env.REACT_APP_BACKEND_URL}/static/avatars/male_avatar.png`)} alt={`${rec.username}'s profile`} className="recommendation-profile-image" />
              <div className="recommendation-content">
                <h3 className="recommendation-username">{rec.username}</h3>
                <p><strong>About Me:</strong> {rec.aboutMe}</p>
                <p><strong>Interests:</strong> {(rec.bio.Interests || []).join(', ')}</p>
                <p><strong>Location:</strong> {rec.bio.Location}</p>
              </div>
              <div className="action-buttons">
                <button className="nav-button dislike-button" onClick={() => handleDislike(rec.id)}>Dislike</button>
                <button className="nav-button like-button" onClick={() => handleLike(rec.id)}>Like</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="no-recommendations-message">No recommendations available.</p>
      )}
    </div>
  );
};

export default Recommendations;
