class WebSocketService {
    constructor() {
        console.log('🔧 WebSocket Service: Created');
        this.ws = null;
        this.listeners = new Set();
    }

    connect() {
        const token = document.cookie.split('; ')
            .find(row => row.startsWith('token='))
            ?.split('=')[1];

        if (!token) {
            console.log('❌ WebSocket Service: No token found');
            return;
        }

        if (this.ws) {
            console.log('ℹ️ WebSocket Service: Already connected');
            return;
        }

        console.log('🔄 WebSocket Service: Connecting...');
        this.ws = new WebSocket(`ws://${process.env.REACT_APP_BACKEND_URL.split('//')[1]}/ws?token=${token}`);

        this.ws.onopen = () => {
            console.log('✅ WebSocket Service: Connected successfully');
            console.log('🔌 Connection Status:', this.ws.readyState === WebSocket.OPEN ? 'OPEN' : 'CLOSED');
        };

        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            console.log('📨 WebSocket Service: Received message:', data);
            this.listeners.forEach(listener => {
                console.log('🎯 Notifying listener about message');
                listener(data);
            });
        };

        this.ws.onclose = () => {
            console.log('🔌 WebSocket Service: Connection closed');
            console.log('❌ Connection Status: CLOSED');
            this.ws = null;
        };

        this.ws.onerror = (error) => {
            console.error('❌ WebSocket Service: Error occurred', error);
        };
    }

    addListener(callback) {
        this.listeners.add(callback);
        console.log(`👂 WebSocket Service: Listener added (total: ${this.listeners.size})`);
        console.log('🎯 Current listeners count:', this.listeners.size);
    }

    removeListener(callback) {
        this.listeners.delete(callback);
        console.log(`🗑️ WebSocket Service: Listener removed (total: ${this.listeners.size})`);
        console.log('🎯 Current listeners count:', this.listeners.size);
    }

    disconnect() {
        if (this.ws) {
            console.log('🔌 WebSocket Service: Disconnecting...');
            this.ws.close();
            this.ws = null;
            console.log('✅ WebSocket Service: Disconnected successfully');
            console.log('❌ Connection Status: CLOSED');
        } else {
            console.log('ℹ️ WebSocket Service: Already disconnected');
        }
    }
}

export const webSocketService = new WebSocketService();

// Add a global error boundary
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
}); 