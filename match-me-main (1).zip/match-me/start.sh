#!/bin/bash

# Function to get the local IP address
get_local_ip() {
  if command -v ip > /dev/null; then
    ip addr show | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d'/' -f1 | head -n 1
  elif command -v ifconfig > /dev/null; then
    ifconfig | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | head -n 1
  else
    echo "No compatible command found to get local IP address" >&2
    exit 1
  fi
}

# Get the local IP address
LOCAL_IP=$(get_local_ip)
if [ -z "$LOCAL_IP" ]; then
  echo "Could not determine local IP address" >&2
  exit 1
fi
echo "Local IP address: $LOCAL_IP"

# Update the .env.local file with the local IP address
ENV_FILE="frontend/.env.local"
echo "REACT_APP_BACKEND_URL=http://$LOCAL_IP:8000" > $ENV_FILE
echo "Updated $ENV_FILE with REACT_APP_BACKEND_URL=http://$LOCAL_IP:8000"

# Create a log file
LOG_FILE_FR="start_frontend.log"
LOG_FILE_BE="start_backend.log"
echo "Creating log file at $LOG_FILE_FR and $LOG_FILE_BE"
touch $LOG_FILE_BE
touch $LOG_FILE_FR

# Start the backend and redirect output to the log file
echo "Starting backend..."
cd backend
go run main.go >> ../$LOG_FILE_BE 2>&1 &
BACKEND_PID=$!
cd ..

# Start the frontend and redirect output to the log file
echo "Starting frontend..."
cd frontend
npm start >> ../$LOG_FILE_FR 2>&1 &
FRONTEND_PID=$!
cd ..

# Wait for the backend and frontend to finish
wait $BACKEND_PID
wait $FRONTEND_PID