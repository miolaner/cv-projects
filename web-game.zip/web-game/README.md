# Terrain Takedown GAME

A multiplayer browser-based game where players collect points while navigating different terrains.

## Table of Contents

1. [Game Overview](#game-overview)
2. [How to Play](#how-to-play)
3. [Installation & Setup](#installation--setup)
4. [Game Controls](#game-controls)
5. [Game Elements](#game-elements)
6. [Terrain Types](#terrain-types)
7. [Powerups](#powerups)
8. [Multiplayer Features](#multiplayer-features)
9. [Game Modes](#game-modes)
10. [Troubleshooting](#troubleshooting)
11. [Using NGROK](#using-ngrok)
12. [Technical Overview](#technical-overview)
13. [Credits](#credits)

## Game Overview

Terrain Takedown is a fun, competitive multiplayer game where players navigate through various terrain types to collect points and powerups. The player with the highest score when the timer runs out wins!

The game features:

- Real-time multiplayer gameplay
- Different terrain types that affect movement speed
- Collectible powerups
- Scoreboard to track points
- Host and join game functionality

## How to Play

The objective is simple: collect as many yellow points as possible before the timer runs out!

1. Enter your username
2. Choose to host a new game or join an existing one
3. If hosting, wait for other players to join and click "Start Game"
4. If joining, select an available room from the list
5. Use arrow keys to move your character (blue circle)
6. Collect yellow circles for points
7. Pick up special powerups for temporary advantages
8. Navigate different terrain types strategically
9. The player with the most points when the timer ends wins!

## Installation & Setup

### Requirements

- Web browser (Chrome, Firefox, Edge recommended)
- Node.js (v14.0 or higher)

### Server Setup

1. Download the game files from the repository
2. Open a terminal/command prompt
3. Navigate to the game folder: `cd path/to/game`
4. Install dependencies: `npm install`
5. Start the server: `node server.js`
6. The server will start on port 3000 by default

### Client Setup

1. Open your web browser
2. Go to: `http://localhost:3000`
3. You should see the game login screen
4. Enter your username and choose to host or join a game

## Game Controls

- **Arrow Keys (↑, ↓, ←, →)**: Move your character
- **P**: Pause/unpause the game

## Game Elements

### Players

- **Blue Circle**: Your character
- **Pink Circle**: Other players

### Collectibles

- **Yellow Circle**: Point worth 1 score
- **Turkois Circle**: Speed powerup (increases movement speed for 5 seconds)
- **Red Cirlce**: Point multiplier powerup (doubles points for 5 seconds)

## Terrain Types

The game features different terrain types that affect your movement speed:

- **Grass (Green)**: Normal movement speed (100%)
- **Mud (Yellow/Brown)**: Reduced movement speed (80%)
- **Water (Blue)**: Greatly reduced movement speed (60%)
- **Wall (Gray/Black)**: Blocks movement completely

Strategic navigation of terrain is key to collecting points faster than your opponents!

## Powerups

### Speed Powerup

- **Appearance**: Green square
- **Effect**: Doubles your movement speed
- **Duration**: 5 seconds

### Point Multiplier Powerup

- **Appearance**: Orange/Red square
- **Effect**: Doubles points collected
- **Duration**: 5 seconds

## Multiplayer Features

### Hosting a Game

1. Enter your username
2. Click "Host Game"
3. Wait for players to join your room
4. Click "Start Game" when ready

### Joining a Game

1. Enter your username
2. Click "Join Game"
3. Select an available room from the list
4. Wait for the host to start the game

### In-Game Communication

- The game displays notifications when players join or leave
- The scoreboard updates in real-time to show everyone's score

## Game Modes

Currently, the game offers a time-based competitive mode:

- Players compete to collect the most points within a set time limit
- When the timer reaches zero, the game ends and displays the final scoreboard
- The player with the highest score wins!

## Troubleshooting

### Game Won't Connect

- Make sure the server is running (check terminal for errors)
- Verify you're using the correct URL (http://localhost:3000)
- Check your internet connection

### Performance Issues

- Close other browser tabs and applications
- Reduce the number of players in a game
- Try a different browser

### Controls Not Working

- Make sure the game window is in focus
- Check if your keyboard is functioning properly
- Verify that the game is not paused

## Using NGROK

NGROK allows you to expose your local server to the internet, making it easier for others to join your game without being on the same local network.

### Steps to Use NGROK:

#### 1. Download and Install NGROK:

Visit NGROK's official website and download the appropriate version for your operating system.
Follow the installation instructions provided on the website.
https://ngrok.com/docs/getting-started/

#### 2. Start Your Game Server:

Open a terminal/command prompt.
Navigate to your game folder:\
`cd path/to/game`\
Start the server:\
`node server.js`

#### 3. Expose Your Local Server:

Open a new terminal/command prompt.
Run the following command to expose your local server (assuming it runs on port 3000):\
`ngrok http 3000`

#### 4. Share the Public URL:

NGROK will provide a public URL (e.g., https://abcd1234.ngrok.io).
Share this URL with other players so they can join your game.

#### 5. Join the Game:

Other players can open the NGROK URL in their browser to access the game.\
\
Notes:
Ensure that your firewall allows NGROK to connect to the internet.
NGROK free accounts may occasionally change the public URL, so you may need to restart NGROK and share the new URL if the session expires.
For a more stable experience, consider using a paid NGROK plan to reserve a custom domain.

## Technical Overview

For those interested in the technical aspects of the game:

### Files Structure

- **server.js**: Main server file handling game logic and WebSocket connections
- **index.html**: Main HTML file
- **styles.css**: CSS styling for the game
- **game.js**: Main client-side game logic
- **login.js**: Handles login, room creation and joining
- **timer.js**: Manages the game timer
- **info.js**: Manages game instructions

### Technologies Used

- **HTML/CSS/JavaScript**: Front-end
- **WebSockets**: Real-time communication
- **Node.js**: Server-side logic

## Credits

Created by

Simon Brown,\
Mio Karolus Lanér,\
Petri Timonen
