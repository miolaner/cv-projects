# PDF to SVG Renderer

A web application that renders PDFs as SVG and allows measurement of vector elements.

## Features

- Upload and render PDFs as SVG
- Zoom and pan navigation
- Page navigation for multi-page PDFs
- Select and measure individual vector elements (lines, paths, polylines, rectangles)
- Auto Line Selector - automatically select connected lines in the same direction
- Calibrate measurements using real-world distances
- Download SVG output
- Mobile-friendly with touch support

## File Structure

The application is organized into the following files:

- `index.html` - Main HTML structure
- `styles.css` - CSS styling
- `app.js` - Main application logic and state management
- `pdfrenderer.js` - PDF to SVG rendering functionality
- `measurement.js` - Line measurement and selection functionality
- `calibration.js` - Scale calibration features
- `ui.js` - User interface interactions and zoom/pan functionality

## Usage

1. Upload a PDF file (max 10MB)
2. Click "Render as SVG" to display the PDF as SVG
3. Navigate between pages using the page controls
4. Use mouse wheel or buttons to zoom in/out, and drag to pan
5. Click on vector elements to select and measure them
6. Use shift+click to select multiple elements
7. Enable the "Auto Line Selector" to automatically select connected lines in the same direction
8. Calibrate measurements using real-world distances
9. Download the SVG if needed

## Auto Line Selector

The Auto Line Selector is a feature that helps you quickly select a sequence of connected lines that continue in approximately the same direction:

1. Enable the "Auto Line Selector" checkbox in the options
2. Click on a line element in the SVG
3. The application will automatically select any connected lines that continue in roughly the same direction (within 20° tolerance)
4. This is particularly useful for measuring complex polylines or paths that are composed of multiple line segments

## Calibration

There are two ways to calibrate measurements:

1. **Point Calibration**: Click "Calibrate by Points", select two points, and enter the real-world distance.
2. **Line Calibration**: Select one or more lines, click "Calibrate from Lines", and enter the real-world length.

## Dependencies

- [PDF.js](https://mozilla.github.io/pdf.js/) - For PDF parsing and rendering

## Browser Compatibility

Works in modern browsers that support SVG and PDF.js:

- Chrome
- Firefox
- Safari
- Edge

## Limitations

- The SVG backend in PDF.js is deprecated and may have rendering issues with some PDFs
- Complex PDF elements might not render correctly
- Maximum file size is limited to 10MB
- Auto Line Selector works best with clean, well-defined line elements

## Development

To modify or extend this application:

1. Clone the repository
2. Make changes to the relevant files
3. Test in a web server (e.g., using Live Server in VSCode)

No build step is required as this is a pure HTML/CSS/JavaScript application.
