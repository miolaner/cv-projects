/**
 * measurement.js
 * Provides functionality for measuring SVG elements in the PDF to SVG Renderer.
 */

// Configuration constants
const MEASURABLE_TYPES = ['line', 'path', 'polyline', 'rect', 'circle', 'polygon'];
const HIT_DETECTION_THRESHOLD = 10;
const CONNECTION_TOLERANCE = 5; // Maximum distance to consider lines connected
const DIRECTION_TOLERANCE = 20; // Maximum angle difference in degrees

/**
 * Initialize measurement functionality
 */
function initLineSelection() {
    console.log('Initializing measurement module...');
    
    // Remove previous handlers to avoid duplicates
    if (elements.svgContent) {
        elements.svgContent.removeEventListener('click', handleSvgClick);
        elements.svgContent.addEventListener('click', handleSvgClick);
        console.log('Click handler attached to SVG content');
    } else {
        console.warn('SVG content element not found for click handler');
    }
    
    // Initialize Auto Line Selector UI and functionality
    const autoLineSelectCheckbox = document.getElementById('highlight-mode-checkbox');
    if (autoLineSelectCheckbox) {
        autoLineSelectCheckbox.addEventListener('change', function() {
            appState.autoLineSelectEnabled = this.checked;
        });
        
        // Set initial state
        appState.autoLineSelectEnabled = autoLineSelectCheckbox.checked;
    }
    
    // Add global handler
    window.handleSvgClick = handleSvgClick;
    
    console.log('Measurement module initialized');
}

/**
 * Handle clicks on SVG elements for measurement
 */
function handleSvgClick(event) {
    console.log('SVG click detected');
    
    // Ignore clicks if dragging or calibrating
    if (appState.isDragging || appState.isCalibrating) {
        console.log('Ignoring click - dragging or calibrating');
        return;
    }
    
    event.stopPropagation();
    const isMultiSelect = event.shiftKey;
    
    // Debug the click coordinates
    const svgContainerRect = elements.svgContainer.getBoundingClientRect();
    const clickX = event.clientX - svgContainerRect.left;
    const clickY = event.clientY - svgContainerRect.top;
    console.log(`Click coordinates: (${clickX}, ${clickY})`);
    
    // Adjust for current viewport position and scale
    const svgX = (clickX - appState.viewportX) / appState.currentScale;
    const svgY = (clickY - appState.viewportY) / appState.currentScale;
    console.log(`Adjusted SVG coordinates: (${svgX}, ${svgY})`);
    
    // Find the element that was clicked
    let target = findTargetElement(event);
    
    if (!target) {
        console.log('No target element found');
        if (!isMultiSelect) {
            clearAllSelections();
        }
        return;
    }
    
    console.log('Target element found:', target.tagName);
    
    // Get the element type and handle the selection
    const elementType = getNormalizedElementType(target);
    console.log('Element type:', elementType);
    
    if (MEASURABLE_TYPES.includes(elementType)) {
        ensureElementHasId(target);
        
        if (isMultiSelect) {
            handleMultiSelection(target, elementType);
        } else {
            handleSingleSelection(target, elementType);
        }
        
        updateMeasurementsDisplay();
    } else if (!isMultiSelect) {
        clearAllSelections();
    }
}

/**
 * Find the target element at the click position
 */
function findTargetElement(event) {
    let target = event.target;
    console.log('Initial target element:', target.tagName);
    
    // If event.target is SVG or a container, find the closest measurable element
    if (!isMeasurableElement(target)) {
        console.log('Target is not directly measurable, searching for closest element');
        target = findClosestMeasurableElement(event);
    }
    
    return target;
}

/**
 * Get normalized element type from SVG element
 */
function getNormalizedElementType(element) {
    if (!element || !element.tagName) return null;
    const tagName = element.tagName.toLowerCase();
    return tagName.includes(':') ? tagName.split(':')[1] : tagName;
}

/**
 * Ensure element has a unique ID for tracking
 */
function ensureElementHasId(element) {
    if (!element.uniqueId) {
        element.uniqueId = Math.random().toString(36).substring(2, 11);
    }
}

/**
 * Handle multi-selection (shift+click)
 */
function handleMultiSelection(element, elementType) {
    const elementIndex = findElementIndexInSelection(element);
    
    if (elementIndex !== -1) {
        // Element already selected - remove it
        element.classList.remove('highlight');
        appState.selectedElements.splice(elementIndex, 1);
        console.log('Removed element from selection');
    } else {
        // Add to selection
        element.classList.add('highlight');
        appState.selectedElements.push({
            element: element,
            elementType: elementType
        });
        console.log('Added element to selection');
    }
}

/**
 * Handle single element selection
 */
function handleSingleSelection(element, elementType) {
    // Clear previous selections
    clearAllSelections();
    
    // Add the new selection
    element.classList.add('highlight');
    appState.selectedElements.push({
        element: element,
        elementType: elementType
    });
    appState.highlightedElement = element;
    console.log('Single element selected');
    
    // Apply auto line selection if enabled
    if (appState.autoLineSelectEnabled && elementType === 'line') {
        console.log('Auto line selection enabled, finding connected lines');
        selectConnectedLines(element);
    }
}

/**
 * Select connected lines in the same direction
 */
function selectConnectedLines(startLine) {
    // Get line coordinates
    const lineCoords = getLineCoordinates(startLine);
    if (!lineCoords) {
        console.warn('Could not get line coordinates for auto selection');
        return;
    }
    
    // Calculate the direction of this line
    const direction = calculateDirection(lineCoords);
    
    // Continue selecting connected lines in both directions
    let processedLines = new Set([startLine.uniqueId]);
    
    // Find all lines in the document
    const allLines = Array.from(document.querySelectorAll('#svg-content line'));
    console.log(`Found ${allLines.length} lines in SVG`);
    
    // Forward direction (from end point)
    findConnectedLinesInDirection(
        lineCoords.x2, lineCoords.y2, 
        direction, 
        allLines, 
        processedLines
    );
    
    // Backward direction (from start point) - reverse the direction vector
    findConnectedLinesInDirection(
        lineCoords.x1, lineCoords.y1, 
        { x: -direction.x, y: -direction.y }, 
        allLines, 
        processedLines
    );
}

/**
 * Find connected lines in a specific direction
 */
function findConnectedLinesInDirection(startX, startY, direction, allLines, processedLines) {
    let continueSearch = true;
    let currentX = startX;
    let currentY = startY;
    
    while (continueSearch) {
        continueSearch = false;
        
        // Calculate the baseline angle
        const baseAngle = Math.atan2(direction.y, direction.x) * 180 / Math.PI;
        
        // Find the closest connected line
        let bestMatch = null;
        let bestDistance = CONNECTION_TOLERANCE;
        
        for (const line of allLines) {
            // Skip already processed lines
            if (processedLines.has(line.uniqueId)) continue;
            
            const coords = getLineCoordinates(line);
            if (!coords) continue;
            
            // Check distance from current point to both endpoints of this line
            const distToStart = distance(currentX, currentY, coords.x1, coords.y1);
            const distToEnd = distance(currentX, currentY, coords.x2, coords.y2);
            
            // Find the closest endpoint
            if (distToStart < bestDistance || distToEnd < bestDistance) {
                // Determine which endpoint is closest
                const isStartClosest = distToStart < distToEnd;
                const closestDist = isStartClosest ? distToStart : distToEnd;
                
                // Calculate the direction of this line
                let lineDirection;
                if (isStartClosest) {
                    // Line starts from the connection point, direction is x1->x2
                    lineDirection = { 
                        x: coords.x2 - coords.x1, 
                        y: coords.y2 - coords.y1 
                    };
                } else {
                    // Line ends at the connection point, direction is x2->x1
                    lineDirection = { 
                        x: coords.x1 - coords.x2, 
                        y: coords.y1 - coords.y2 
                    };
                }
                
                // Normalize the direction
                const length = Math.sqrt(lineDirection.x * lineDirection.x + lineDirection.y * lineDirection.y);
                if (length > 0) {
                    lineDirection.x /= length;
                    lineDirection.y /= length;
                }
                
                // Calculate angle between directions
                const lineAngle = Math.atan2(lineDirection.y, lineDirection.x) * 180 / Math.PI;
                let angleDiff = Math.abs(lineAngle - baseAngle);
                if (angleDiff > 180) angleDiff = 360 - angleDiff;
                
                // If the angle is within tolerance, consider this line
                if (angleDiff <= DIRECTION_TOLERANCE) {
                    bestMatch = {
                        line: line,
                        coords: coords,
                        distance: closestDist,
                        isStartClosest: isStartClosest
                    };
                    bestDistance = closestDist;
                }
            }
        }
        
        // If we found a matching line, select it and continue the search
        if (bestMatch) {
            // Add this line to selection
            bestMatch.line.classList.add('highlight');
            appState.selectedElements.push({
                element: bestMatch.line,
                elementType: 'line'
            });
            
            // Mark as processed
            processedLines.add(bestMatch.line.uniqueId);
            
            // Update current point to the other end of the line
            if (bestMatch.isStartClosest) {
                currentX = bestMatch.coords.x2;
                currentY = bestMatch.coords.y2;
            } else {
                currentX = bestMatch.coords.x1;
                currentY = bestMatch.coords.y1;
            }
            
            // Continue the search
            continueSearch = true;
        }
    }
}

/**
 * Calculate the direction vector of a line
 */
function calculateDirection(lineCoords) {
    const dx = lineCoords.x2 - lineCoords.x1;
    const dy = lineCoords.y2 - lineCoords.y1;
    const length = Math.sqrt(dx * dx + dy * dy);
    
    return {
        x: length > 0 ? dx / length : 0,
        y: length > 0 ? dy / length : 0
    };
}

/**
 * Get line coordinates from a line element
 */
function getLineCoordinates(line) {
    if (!line) return null;
    
    try {
        return {
            x1: parseFloat(line.getAttribute('x1') || 0),
            y1: parseFloat(line.getAttribute('y1') || 0),
            x2: parseFloat(line.getAttribute('x2') || 0),
            y2: parseFloat(line.getAttribute('y2') || 0)
        };
    } catch (error) {
        console.error('Error getting line coordinates:', error);
        return null;
    }
}

/**
 * Calculate distance between two points
 */
function distance(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

/**
 * Find element in the selection array
 */
function findElementIndexInSelection(element) {
    for (let i = 0; i < appState.selectedElements.length; i++) {
        if (appState.selectedElements[i].element === element) {
            return i;
        }
    }
    return -1;
}

/**
 * Clear all selected elements
 */
function clearAllSelections() {
    appState.selectedElements.forEach(item => {
        if (item.element && item.element.classList) {
            item.element.classList.remove('highlight');
        }
    });
    
    appState.selectedElements = [];
    appState.highlightedElement = null;
    
    if (elements.infoPanel) {
        elements.infoPanel.classList.add('hidden');
    }
    
    console.log('All selections cleared');
}

/**
 * Update the measurement display panel
 */
function updateMeasurementsDisplay() {
    const count = appState.selectedElements.length;
    console.log(`Updating measurements display for ${count} elements`);
    
    if (count === 0) {
        if (elements.infoPanel) {
            elements.infoPanel.classList.add('hidden');
        }
        return;
    }
    
    // Show the info panel
    if (elements.infoPanel) {
        elements.infoPanel.classList.remove('hidden');
    }
    
    if (elements.selectionCountDisplay) {
        elements.selectionCountDisplay.textContent = count;
    }
    
    if (count === 1) {
        showSingleElementMeasurement();
    } else {
        showMultipleElementMeasurement();
    }
    
    // Update status bar
    if (elements.statusSelection) {
        elements.statusSelection.textContent = `${count} items selected`;
    }
}

/**
 * Show measurement for a single element
 */
function showSingleElementMeasurement() {
    const item = appState.selectedElements[0];
    let length = calculateElementLength(item.element, item.elementType);
    
    // Apply scale if available
    if (appState.scaleValue !== null) {
        length = length * appState.scaleValue;
    }
    
    if (elements.lineLengthDisplay) {
        elements.lineLengthDisplay.textContent = length.toFixed(2);
    }
    
    if (elements.totalLengthInfo) {
        elements.totalLengthInfo.classList.add('hidden');
    }
}

/**
 * Show measurement for multiple elements
 */
function showMultipleElementMeasurement() {
    let totalLength = 0;
    
    appState.selectedElements.forEach(item => {
        totalLength += calculateElementLength(item.element, item.elementType);
    });
    
    // Apply scale if available
    if (appState.scaleValue !== null) {
        totalLength = totalLength * appState.scaleValue;
    }
    
    if (elements.totalLengthDisplay) {
        elements.totalLengthDisplay.textContent = totalLength.toFixed(2);
    }
    
    if (elements.totalLengthInfo) {
        elements.totalLengthInfo.classList.remove('hidden');
    }
}

/**
 * Check if an element is measurable
 */
function isMeasurableElement(element) {
    if (!element || !element.tagName) return false;
    
    const tagName = element.tagName.toLowerCase();
    const elementType = tagName.includes(':') ? tagName.split(':')[1] : tagName;
    
    return MEASURABLE_TYPES.includes(elementType);
}

/**
 * Find the closest measurable element to a click point
 */
function findClosestMeasurableElement(event) {
    try {
        const coords = getClickCoordinates(event);
        if (!coords) {
            console.warn('Could not get click coordinates');
            return null;
        }
        
        const allElements = getAllMeasurableElements();
        if (!allElements || allElements.length === 0) {
            console.warn('No measurable elements found');
            return null;
        }
        
        console.log(`Found ${allElements.length} measurable elements to test`);
        
        // Convert threshold to SVG coordinates based on current scale
        const hitThreshold = HIT_DETECTION_THRESHOLD / appState.currentScale;
        
        let closestElement = null;
        let minDistance = Infinity;
        
        allElements.forEach(element => {
            const distance = getDistanceToElement(element, coords.x, coords.y);
            
            if (distance < minDistance && distance <= hitThreshold) {
                minDistance = distance;
                closestElement = element;
            }
        });
        
        if (closestElement) {
            console.log(`Closest element found: ${getNormalizedElementType(closestElement)} at distance ${minDistance}`);
        }
        
        return closestElement;
    } catch (error) {
        console.error("Error finding closest element:", error);
        return null;
    }
}

/**
 * Get adjusted click coordinates in SVG space
 */
function getClickCoordinates(event) {
    try {
        if (!elements.svgContainer) {
            console.warn('SVG container not found');
            return null;
        }
        
        const rect = elements.svgContainer.getBoundingClientRect();
        
        // Calculate raw coordinates relative to container
        const rawX = event.clientX - rect.left;
        const rawY = event.clientY - rect.top;
        
        // Factor in the current view transformation (pan and zoom)
        const svgX = (rawX - appState.viewportX) / appState.currentScale;
        const svgY = (rawY - appState.viewportY) / appState.currentScale;
        
        return { x: svgX, y: svgY, rawX, rawY };
    } catch (error) {
        console.error('Error getting click coordinates:', error);
        return null;
    }
}

/**
 * Get all measurable elements in the SVG
 */
function getAllMeasurableElements() {
    try {
        return Array.from(document.querySelectorAll(
            '#svg-content path, #svg-content line, #svg-content polyline, #svg-content rect, #svg-content circle, #svg-content polygon'
        ));
    } catch (error) {
        console.error('Error getting all measurable elements:', error);
        return [];
    }
}

/**
 * Get distance from a point to an element
 */
function getDistanceToElement(element, x, y) {
    const elementType = getNormalizedElementType(element);
    
    switch (elementType) {
        case 'line':
            return getDistanceToLine(element, x, y);
        case 'rect':
            return getDistanceToRect(element, x, y);
        case 'circle':
            return getDistanceToCircle(element, x, y);
        case 'path':
        case 'polyline':
        case 'polygon':
            return getDistanceToBoundingBox(element, x, y);
        default:
            return Infinity;
    }
}

/**
 * Get distance from a point to a line
 */
function getDistanceToLine(element, x, y) {
    try {
        const coords = getLineCoordinates(element);
        if (!coords) return Infinity;
        
        return distancePointToLineSegment(
            x, y, 
            coords.x1, coords.y1, 
            coords.x2, coords.y2
        );
    } catch (error) {
        console.error('Error calculating distance to line:', error);
        return Infinity;
    }
}

/**
 * Get distance from a point to a rectangle
 */
function getDistanceToRect(element, x, y) {
    try {
        const rectX = parseFloat(element.getAttribute('x') || 0);
        const rectY = parseFloat(element.getAttribute('y') || 0);
        const width = parseFloat(element.getAttribute('width') || 0);
        const height = parseFloat(element.getAttribute('height') || 0);
        
        // Check if point is inside rectangle
        if (x >= rectX && x <= rectX + width && y >= rectY && y <= rectY + height) {
            return 0;
        }
        
        // Calculate distance to nearest edge
        const distX = Math.max(rectX - x, 0, x - (rectX + width));
        const distY = Math.max(rectY - y, 0, y - (rectY + height));
        return Math.sqrt(distX * distX + distY * distY);
    } catch (error) {
        console.error('Error calculating distance to rectangle:', error);
        return Infinity;
    }
}

/**
 * Get distance from a point to a circle
 */
function getDistanceToCircle(element, x, y) {
    try {
        const cx = parseFloat(element.getAttribute('cx') || 0);
        const cy = parseFloat(element.getAttribute('cy') || 0);
        const r = parseFloat(element.getAttribute('r') || 0);
        
        // Calculate distance from point to center
        const dist = distance(x, y, cx, cy);
        
        // Return distance to circle edge (negative if inside)
        return Math.max(0, dist - r);
    } catch (error) {
        console.error('Error calculating distance to circle:', error);
        return Infinity;
    }
}

/**
 * Get distance from a point to an element's bounding box
 */
function getDistanceToBoundingBox(element, x, y) {
    try {
        const bbox = element.getBBox();
        const expandedPixels = 5; // Slightly expand bounding box for better hit detection
        
        // Check if inside expanded bounding box
        if (x >= bbox.x - expandedPixels && 
            x <= bbox.x + bbox.width + expandedPixels && 
            y >= bbox.y - expandedPixels && 
            y <= bbox.y + bbox.height + expandedPixels) {
            
            // Return distance to center as an approximation
            const centerX = bbox.x + bbox.width / 2;
            const centerY = bbox.y + bbox.height / 2;
            return distance(x, y, centerX, centerY);
        }
        
        // Calculate distance to nearest edge of bounding box
        const distX = Math.max(bbox.x - x, 0, x - (bbox.x + bbox.width));
        const distY = Math.max(bbox.y - y, 0, y - (bbox.y + bbox.height));
        return Math.sqrt(distX * distX + distY * distY);
    } catch (error) {
        console.error('Error calculating distance to bounding box:', error);
        return Infinity;
    }
}

/**
 * Calculate the distance from a point to a line segment
 */
function distancePointToLineSegment(px, py, x1, y1, x2, y2) {
    const lineLength = distance(x1, y1, x2, y2);
    
    if (lineLength === 0) return distance(px, py, x1, y1);
    
    // Calculate projection onto the line
    const t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / (lineLength * lineLength);
    
    if (t < 0) return distance(px, py, x1, y1); // Beyond start point
    if (t > 1) return distance(px, py, x2, y2); // Beyond end point
    
    // Calculate the point on the line
    const projX = x1 + t * (x2 - x1);
    const projY = y1 + t * (y2 - y1);
    
    return distance(px, py, projX, projY);
}

/**
 * Calculate the length of an element
 */
function calculateElementLength(element, elementType) {
    switch (elementType) {
        case 'line':
            return calculateLineLength(element);
        case 'rect':
            return calculateRectPerimeter(element);
        case 'circle':
            return calculateCirclePerimeter(element);
        case 'path':
            return calculatePathLength(element);
        case 'polyline':
        case 'polygon':
            return calculatePolylineLength(element);
        default:
            return 0;
    }
}

/**
 * Calculate the length of a line
 */
function calculateLineLength(element) {
    try {
        const coords = getLineCoordinates(element);
        if (!coords) return 0;
        
        return distance(coords.x1, coords.y1, coords.x2, coords.y2);
    } catch (error) {
        console.error('Error calculating line length:', error);
        return 0;
    }
}

/**
 * Calculate the perimeter of a rectangle
 */
function calculateRectPerimeter(element) {
    try {
        const width = parseFloat(element.getAttribute('width') || 0);
        const height = parseFloat(element.getAttribute('height') || 0);
        
        return 2 * (width + height);
    } catch (error) {
        console.error('Error calculating rectangle perimeter:', error);
        return 0;
    }
}

/**
 * Calculate the perimeter of a circle
 */
function calculateCirclePerimeter(element) {
    try {
        const r = parseFloat(element.getAttribute('r') || 0);
        return 2 * Math.PI * r;
    } catch (error) {
        console.error('Error calculating circle perimeter:', error);
        return 0;
    }
}

/**
 * Calculate the length of a path
 */
function calculatePathLength(pathElement) {
    try {
        // Use built-in method if available
        if (typeof pathElement.getTotalLength === 'function') {
            return pathElement.getTotalLength();
        }
        
        // Fallback to manual calculation
        const d = pathElement.getAttribute('d');
        if (!d) return 0;
        
        return calculatePathDataLength(d);
    } catch (error) {
        console.error('Error calculating path length:', error);
        return 0;
    }
}

/**
 * Calculate length from SVG path data
 */
function calculatePathDataLength(pathData) {
    try {
        let length = 0;
        let currentX = 0;
        let currentY = 0;
        let startX = 0;
        let startY = 0;
        
        // Parse path commands
        const commands = pathData.match(/[a-df-z][^a-df-z]*/gi) || [];
        
        for (const cmd of commands) {
            const type = cmd[0];
            const args = cmd.slice(1).trim().split(/[\s,]+/).map(parseFloat);
            const isRelative = type.toLowerCase() === type;
            
            switch (type.toLowerCase()) {
                case 'm': // moveto
                    if (args.length >= 2) {
                        currentX = isRelative ? currentX + args[0] : args[0];
                        currentY = isRelative ? currentY + args[1] : args[1];
                        startX = currentX;
                        startY = currentY;
                    }
                    break;
                    
                case 'l': // lineto
                    if (args.length >= 2) {
                        const x = isRelative ? currentX + args[0] : args[0];
                        const y = isRelative ? currentY + args[1] : args[1];
                        length += distance(currentX, currentY, x, y);
                        currentX = x;
                        currentY = y;
                    }
                    break;
                    
                case 'h': // horizontal lineto
                    if (args.length >= 1) {
                        const x = isRelative ? currentX + args[0] : args[0];
                        length += Math.abs(x - currentX);
                        currentX = x;
                    }
                    break;
                    
                case 'v': // vertical lineto
                    if (args.length >= 1) {
                        const y = isRelative ? currentY + args[0] : args[0];
                        length += Math.abs(y - currentY);
                        currentY = y;
                    }
                    break;
                    
                case 'z': // closepath
                    length += distance(currentX, currentY, startX, startY);
                    currentX = startX;
                    currentY = startY;
                    break;
            }
        }
        
        return length;
    } catch (error) {
        console.error('Error calculating path data length:', error);
        return 0;
    }
}

/**
 * Calculate the length of a polyline or polygon
 */
function calculatePolylineLength(polyElement) {
    try {
        const points = polyElement.getAttribute('points');
        if (!points) return 0;
        
        // Parse points string (format: "x1,y1 x2,y2 x3,y3 ...")
        const pointsArray = points.trim().split(/\s+/).map(p => {
            const [x, y] = p.split(',').map(parseFloat);
            return { x, y };
        });
        
        if (pointsArray.length < 2) return 0;
        
        // Calculate length by summing distances between consecutive points
        let length = 0;
        for (let i = 1; i < pointsArray.length; i++) {
            length += distance(
                pointsArray[i-1].x, pointsArray[i-1].y,
                pointsArray[i].x, pointsArray[i].y
            );
        }
        
        // If this is a polygon, add the closing segment
        if (getNormalizedElementType(polyElement) === 'polygon') {
            const last = pointsArray.length - 1;
            length += distance(
                pointsArray[last].x, pointsArray[last].y,
                pointsArray[0].x, pointsArray[0].y
            );
        }
        
        return length;
    } catch (error) {
        console.error('Error calculating polyline/polygon length:', error);
        return 0;
    }
}

/**
 * Save a measurement
 */
function saveMeasurement() {
    if (appState.selectedElements.length === 0) {
        console.warn('No elements selected for measurement');
        return;
    }
    
    const label = elements.measurementLabel ? elements.measurementLabel.value : 'Measurement';
    const color = elements.measurementColor ? elements.measurementColor.value : '#ff3366';
    
    // Calculate total length and bounding box
    let totalLength = 0;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    
    appState.selectedElements.forEach(item => {
        const length = calculateElementLength(item.element, item.elementType);
        totalLength += length;
        
        // Update bounding box based on element type
        updateBoundingBoxForElement(item.element, item.elementType, minX, minY, maxX, maxY);
    });
    
    // Apply scale if available
    const scaledLength = appState.scaleValue !== null ? totalLength * appState.scaleValue : totalLength;
    const unit = appState.scaleUnit || 'units';
    
    // Calculate center of bounding box for label placement
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    
    // Create the measurement object
    const measurement = {
        id: generateId(),
        label: label,
        color: color,
        elements: appState.selectedElements.map(item => ({
            elementId: item.element.id || item.element.uniqueId,
            elementType: item.elementType
        })),
        length: scaledLength,
        unit: unit,
        rawLength: totalLength,
        centerX: centerX,
        centerY: centerY,
        timestamp: new Date().toISOString()
    };
    
    // Add to saved measurements
    appState.savedMeasurements.push(measurement);
    
    // Update the UI
    updateSavedMeasurementsList();
    
    // Clear the label input field
    if (elements.measurementLabel) {
        elements.measurementLabel.value = '';
    }
    
    console.log('Measurement saved:', measurement);
}

/**
 * Update bounding box based on element type
 */
function updateBoundingBoxForElement(element, elementType, minX, minY, maxX, maxY) {
    try {
        if (!element) return;
        
        switch (elementType) {
            case 'line':
                const coords = getLineCoordinates(element);
                if (coords) {
                    minX = Math.min(minX, coords.x1, coords.x2);
                    minY = Math.min(minY, coords.y1, coords.y2);
                    maxX = Math.max(maxX, coords.x1, coords.x2);
                    maxY = Math.max(maxY, coords.y1, coords.y2);
                }
                break;
                
            default:
                // For other element types, use the getBBox method if available
                if (typeof element.getBBox === 'function') {
                    const bbox = element.getBBox();
                    minX = Math.min(minX, bbox.x);
                    minY = Math.min(minY, bbox.y);
                    maxX = Math.max(maxX, bbox.x + bbox.width);
                    maxY = Math.max(maxY, bbox.y + bbox.height);
                }
                break;
        }
    } catch (error) {
        console.error('Error updating bounding box:', error);
    }
}

/**
 * Update the saved measurements list in the UI
 */
function updateSavedMeasurementsList() {
    if (!elements.measurementList) {
        console.warn('Measurement list element not found');
        return;
    }
    
    if (appState.savedMeasurements.length === 0) {
        elements.measurementList.innerHTML = `
            <div class="empty-state">
                <p>No saved measurements yet</p>
            </div>
        `;
        return;
    }
    
    elements.measurementList.innerHTML = '';
    
    appState.savedMeasurements.forEach(measurement => {
        const measurementItem = document.createElement('div');
        measurementItem.className = 'measurement-item';
        measurementItem.dataset.id = measurement.id;
        
        const formattedLength = measurement.length.toFixed(2);
        const label = measurement.label || 'Measurement';
        
        measurementItem.innerHTML = `
            <div class="measurement-item-info">
                <span class="measurement-item-label">${label}</span>
                <span class="measurement-item-value">${formattedLength} ${measurement.unit}</span>
            </div>
            <div class="measurement-item-actions">
                <button class="icon-button highlight-measurement" title="Highlight">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">
                        <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                    </svg>
                </button>
                <button class="icon-button delete-measurement" title="Delete">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">
                        <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                    </svg>
                </button>
            </div>
        `;
        
        elements.measurementList.appendChild(measurementItem);
        
        // Add event listeners
        measurementItem.querySelector('.highlight-measurement').addEventListener('click', (e) => {
            e.stopPropagation();
            highlightMeasurement(measurement.id);
        });
        
        measurementItem.querySelector('.delete-measurement').addEventListener('click', (e) => {
            e.stopPropagation();
            deleteMeasurement(measurement.id);
        });
        
        // Click on item to highlight
        measurementItem.addEventListener('click', () => {
            highlightMeasurement(measurement.id);
        });
    });
}

/**
 * Highlight a saved measurement
 */
function highlightMeasurement(measurementId) {
    const measurement = appState.savedMeasurements.find(m => m.id === measurementId);
    if (!measurement) {
        console.warn(`Measurement with ID ${measurementId} not found`);
        return;
    }
    
    // Clear current selection
    clearAllSelections();
    
    // Find and highlight all elements in this measurement
    measurement.elements.forEach(element => {
        // Try to find by ID first
        let el = document.getElementById(element.elementId);
        
        // If not found by ID, try to find by uniqueId
        if (!el) {
            const allElements = getAllMeasurableElements();
            el = allElements.find(e => e.uniqueId === element.elementId);
        }
        
        if (el) {
            // Add to selection
            el.classList.add('highlight');
            appState.selectedElements.push({
                element: el,
                elementType: element.elementType
            });
        }
    });
    
    // Update the measurement display
    updateMeasurementsDisplay();
    
    console.log(`Highlighted measurement: ${measurement.label}`);
}

/**
 * Delete a saved measurement
 */
function deleteMeasurement(measurementId) {
    if (confirm('Are you sure you want to delete this measurement?')) {
        const index = appState.savedMeasurements.findIndex(m => m.id === measurementId);
        if (index !== -1) {
            appState.savedMeasurements.splice(index, 1);
            updateSavedMeasurementsList();
            
            // If the deleted measurement was selected, clear the selection
            if (appState.selectedMeasurementId === measurementId) {
                clearAllSelections();
                appState.selectedMeasurementId = null;
            }
        }
    }
}

/**
 * Export measurements as CSV
 */
function exportMeasurements() {
    if (appState.savedMeasurements.length === 0) {
        alert('No measurements to export.');
        return;
    }
    
    // Create CSV header
    let csv = 'Label,Length,Unit,Date\n';
    
    // Add each measurement
    appState.savedMeasurements.forEach(m => {
        const label = m.label.replace(/,/g, ';'); // Escape commas
        const length = m.length.toFixed(2);
        const unit = m.unit;
        const date = new Date(m.timestamp).toLocaleString();
        
        csv += `"${label}",${length},${unit},"${date}"\n`;
    });
    
    // Download the CSV
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'measurements.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Export functions to window object
window.initLineSelection = initLineSelection;
window.handleSvgClick = handleSvgClick;
window.clearAllSelections = clearAllSelections;
window.saveMeasurement = saveMeasurement;
window.deleteMeasurement = deleteMeasurement;
window.exportMeasurements = exportMeasurements;
window.updateMeasurementsDisplay = updateMeasurementsDisplay;