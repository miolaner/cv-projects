/**
 * Component Loader - Loads HTML components into the main workspace
 */
document.addEventListener('DOMContentLoaded', function() {
    // List of components to load
    const components = [
        { id: 'header-container', file: 'components/header.html' },
        { id: 'sidebar-container', file: 'components/sidebar.html' },
        { id: 'properties-container', file: 'components/properties-panel.html' },
        { id: 'modals-container', file: 'components/modals.html' }
    ];
    
    // Load each component
    components.forEach(component => {
        loadComponent(component.id, component.file);
    });
    
    /**
     * Loads HTML content from specified file into the target element
     * @param {string} targetId - ID of the element to load content into
     * @param {string} filePath - Path to the HTML file
     */
    function loadComponent(targetId, filePath) {
        const target = document.getElementById(targetId);
        if (!target) {
            console.error(`Target element with ID "${targetId}" not found.`);
            return;
        }
        
        fetch(filePath)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Failed to load ${filePath}: ${response.status} ${response.statusText}`);
                }
                return response.text();
            })
            .then(html => {
                // Don't replace the element itself, insert the content inside it
                target.innerHTML = html;
                
                // Dispatch event to notify that the component has been loaded
                window.dispatchEvent(new CustomEvent('componentLoaded', {
                    detail: { id: targetId, path: filePath }
                }));
            })
            .catch(error => {
                console.error(`Error loading component ${filePath}:`, error);
                target.innerHTML = `<div class="error-message">Failed to load component. Please refresh the page.</div>`;
            });
    }
});

/**
 * Ensure the loading overlay is hidden after some time
 */
function ensureLoadingOverlayIsHidden() {
    // Wait for a short time to ensure rendering is complete
    setTimeout(() => {
        const loadingOverlay = document.getElementById('loading-overlay');
        if (loadingOverlay && !loadingOverlay.classList.contains('hidden')) {
            console.log('Force hiding loading overlay');
            loadingOverlay.classList.add('hidden');
        }
    }, 5000); // Give it 5 seconds before force hiding
}

// Listen for component loaded events to initialize any component-specific functionality
window.addEventListener('componentLoaded', function(event) {
    // Get details about which component was loaded
    const { id, path } = event.detail;
    console.log(`Component loaded: ${id} from ${path}`);
    
    // Check if this is the last component to load
    if (id === 'modals-container') {
        // After a short delay to ensure elements are available
        setTimeout(() => {
            initializeAllEvents();
            ensureLoadingOverlayIsHidden();
        }, 300);
    }
});

/**
 * Initialize all events after components are loaded
 */
function initializeAllEvents() {
    // Initialize header events
    initializeHeaderEvents();
    
    // Initialize toolbar events
    initializeToolbarEvents();
    
    // Initialize properties panel events
    initializePropertiesPanelEvents();
    
    // Initialize modal events
    initializeModalEvents();
    
    // Make sure the main app initialization runs
    if (window.cacheWorkspaceElements) {
        window.cacheWorkspaceElements();
        
        if (window.initTools) {
            window.initTools();
        }
        
        if (window.loadProjectFromURL) {
            window.loadProjectFromURL();
        }
    } else {
        console.warn("cacheWorkspaceElements function not available");
    }
}

/**
 * Initialize event listeners for header components
 */
function initializeHeaderEvents() {
    // Initialize buttons in the header
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            if (window.showSaveDialog) {
                window.showSaveDialog();
            } else {
                openModal('save-dialog');
            }
        });
    }
    
    const downloadSvgBtn = document.getElementById('download-svg-btn');
    if (downloadSvgBtn) {
        downloadSvgBtn.addEventListener('click', function() {
            if (window.downloadSvg) {
                window.downloadSvg();
            }
        });
    }
    
    const shareBtn = document.getElementById('share-btn');
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            if (window.showShareDialog) {
                window.showShareDialog();
            } else {
                openModal('share-dialog');
            }
        });
    }
    
    // Navigation buttons
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    if (prevPageBtn && nextPageBtn) {
        prevPageBtn.addEventListener('click', function() {
            if (window.prevPage) {
                window.prevPage();
            }
        });
        
        nextPageBtn.addEventListener('click', function() {
            if (window.nextPage) {
                window.nextPage();
            }
        });
    }
    
    // Zoom controls
    const zoomInBtn = document.getElementById('zoom-in-btn');
    const zoomOutBtn = document.getElementById('zoom-out-btn');
    const resetViewBtn = document.getElementById('reset-view-btn');
    
    if (zoomInBtn && zoomOutBtn && resetViewBtn) {
        zoomInBtn.addEventListener('click', function() {
            if (window.zoomByFactor) {
                window.zoomByFactor(1.2);
            }
        });
        
        zoomOutBtn.addEventListener('click', function() {
            if (window.zoomByFactor) {
                window.zoomByFactor(0.8);
            }
        });
        
        resetViewBtn.addEventListener('click', function() {
            if (window.resetView) {
                window.resetView();
            }
        });
    }
}

/**
 * Initialize event listeners for toolbar components
 */
function initializeToolbarEvents() {
    // Tool buttons
    const toolButtons = document.querySelectorAll('.tool-button');
    toolButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all tools
            toolButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked tool
            this.classList.add('active');
            
            // Get tool id and activate tool
            const toolId = this.id;
            const toolName = toolId.replace('-tool', '');
            
            // Use the global function if available
            if (window.selectTool) {
                window.selectTool(toolName);
            } else {
                // Fallback to local activation
                activateTool(toolName);
            }
        });
    });
    
    // Initialize tool-specific options
    initializeToolOptionsControls();
}

/**
 * Initialize tool option controls
 */
function initializeToolOptionsControls() {
    // Direction tolerance slider
    const directionTolerance = document.getElementById('direction-tolerance');
    const directionToleranceValue = document.getElementById('direction-tolerance-value');
    
    if (directionTolerance && directionToleranceValue) {
        directionTolerance.addEventListener('input', function() {
            const value = this.value;
            directionToleranceValue.textContent = value + '°';
            if (window.appState) {
                window.appState.directionTolerance = parseInt(value);
            }
        });
    }
    
    // Connection threshold slider
    const connectionThreshold = document.getElementById('connection-threshold');
    const connectionThresholdValue = document.getElementById('connection-threshold-value');
    
    if (connectionThreshold && connectionThresholdValue) {
        connectionThreshold.addEventListener('input', function() {
            const value = this.value;
            connectionThresholdValue.textContent = value + 'px';
            if (window.appState) {
                window.appState.connectionThreshold = parseInt(value);
            }
        });
    }
    
    // Calibration buttons
    const calibratePointsBtn = document.getElementById('calibrate-points-btn');
    const calibrateLinesBtn = document.getElementById('calibrate-lines-btn');
    const clearCalibrationBtn = document.getElementById('clear-calibration-btn');
    
    if (calibratePointsBtn && window.startCalibration) {
        calibratePointsBtn.addEventListener('click', window.startCalibration);
    }
    
    if (calibrateLinesBtn && window.startLineCalibration) {
        calibrateLinesBtn.addEventListener('click', window.startLineCalibration);
    }
    
    if (clearCalibrationBtn && window.clearCalibration) {
        clearCalibrationBtn.addEventListener('click', window.clearCalibration);
    }
    
    // Highlight mode checkboxes
    const highlightModeCheckbox = document.getElementById('highlight-mode-checkbox');
    if (highlightModeCheckbox) {
        highlightModeCheckbox.addEventListener('change', function() {
            if (window.appState) {
                window.appState.autoHighlightEnabled = this.checked;
            }
        });
    }
    
    const highlightModeCheckboxSelect = document.getElementById('highlight-mode-checkbox-select');
    if (highlightModeCheckboxSelect) {
        highlightModeCheckboxSelect.addEventListener('change', function() {
            if (window.appState) {
                window.appState.highlightOnHover = this.checked;
            }
        });
    }
}

/**
 * Initialize event listeners for properties panel
 */
function initializePropertiesPanelEvents() {
    // Close properties button
    const closePropertiesBtn = document.getElementById('close-properties');
    const propertiesPanel = document.querySelector('.properties-panel');
    
    if (closePropertiesBtn && propertiesPanel) {
        closePropertiesBtn.addEventListener('click', function() {
            propertiesPanel.classList.add('hidden');
        });
    }
    
    // Measurement buttons
    const saveMeasurementBtn = document.getElementById('save-measurement-btn');
    const clearSelectionBtn = document.getElementById('clear-selection-btn');
    
    if (saveMeasurementBtn && window.saveMeasurement) {
        saveMeasurementBtn.addEventListener('click', window.saveMeasurement);
    }
    
    if (clearSelectionBtn && window.clearAllSelections) {
        clearSelectionBtn.addEventListener('click', window.clearAllSelections);
    }
    
    // Export measurements button
    const exportMeasurementsBtn = document.getElementById('export-measurements-btn');
    if (exportMeasurementsBtn && window.exportMeasurements) {
        exportMeasurementsBtn.addEventListener('click', window.exportMeasurements);
    }
    
    // Unit selection
    const unitSelectPanel = document.getElementById('unit-select-panel');
    if (unitSelectPanel && window.appState) {
        unitSelectPanel.addEventListener('change', function() {
            window.appState.scaleUnit = this.value;
            if (window.updateScaleDisplay) {
                window.updateScaleDisplay();
            }
            if (window.updateMeasurementsDisplay) {
                window.updateMeasurementsDisplay();
            }
        });
    }
}

/**
 * Initialize event listeners for modal dialogs
 */
function initializeModalEvents() {
    // Close buttons for modals
    const closeButtons = document.querySelectorAll('.close-button[data-target]');
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            closeModal(targetId);
        });
    });
    
    // Calibration dialog buttons
    const confirmScaleBtn = document.getElementById('confirm-scale-btn');
    const cancelScaleBtn = document.getElementById('cancel-scale-btn');
    
    if (confirmScaleBtn && window.setScale) {
        confirmScaleBtn.addEventListener('click', window.setScale);
    }
    
    if (cancelScaleBtn && window.cancelCalibration) {
        cancelScaleBtn.addEventListener('click', window.cancelCalibration);
    } else if (cancelScaleBtn) {
        cancelScaleBtn.addEventListener('click', function() {
            closeModal('#calibration-dialog');
        });
    }
    
    // Line calibration dialog buttons
    const confirmLinesScaleBtn = document.getElementById('confirm-lines-scale-btn');
    const cancelLinesScaleBtn = document.getElementById('cancel-lines-scale-btn');
    
    if (confirmLinesScaleBtn && window.setScaleFromLines) {
        confirmLinesScaleBtn.addEventListener('click', window.setScaleFromLines);
    }
    
    if (cancelLinesScaleBtn && window.cancelCalibration) {
        cancelLinesScaleBtn.addEventListener('click', window.cancelCalibration);
    } else if (cancelLinesScaleBtn) {
        cancelLinesScaleBtn.addEventListener('click', function() {
            closeModal('#line-calibration-dialog');
        });
    }
    
    // Save dialog buttons
    const confirmSaveBtn = document.getElementById('confirm-save-btn');
    const cancelSaveBtn = document.getElementById('cancel-save-btn');
    
    if (confirmSaveBtn && window.saveProject) {
        confirmSaveBtn.addEventListener('click', window.saveProject);
    }
    
    if (cancelSaveBtn) {
        cancelSaveBtn.addEventListener('click', function() {
            closeModal('#save-dialog');
        });
    }
    
    // Share dialog buttons
    const exportProjectBtn = document.getElementById('export-project-btn');
    const closeShareBtn = document.getElementById('close-share-btn');
    
    if (exportProjectBtn && window.exportProject) {
        exportProjectBtn.addEventListener('click', window.exportProject);
    }
    
    if (closeShareBtn) {
        closeShareBtn.addEventListener('click', function() {
            closeModal('#share-dialog');
        });
    }
    
    // Copy link button
    const copyLinkBtn = document.getElementById('copy-link-btn');
    if (copyLinkBtn && window.copyShareLink) {
        copyLinkBtn.addEventListener('click', window.copyShareLink);
    }
}

/**
 * Helper function to activate a tool
 * @param {string} toolName - Name of tool to activate
 */
function activateTool(toolName) {
    console.log(`${toolName} tool activated`);
    
    // Update tool options panel visibility
    const optionPanels = document.querySelectorAll('.tool-option-panel');
    optionPanels.forEach(panel => panel.classList.add('hidden'));
    
    const optionsPanel = document.getElementById(`${toolName}-options`);
    if (optionsPanel) {
        optionsPanel.classList.remove('hidden');
    }
    
    // Update cursor style
    const svgContent = document.getElementById('svg-content');
    if (svgContent) {
        switch (toolName) {
            case 'select':
                svgContent.style.cursor = 'default';
                break;
            case 'measure':
                svgContent.style.cursor = 'crosshair';
                break;
            case 'auto-select':
                svgContent.style.cursor = 'default';
                break;
            case 'calibrate':
                svgContent.style.cursor = 'crosshair';
                break;
            case 'pan':
                svgContent.style.cursor = 'move';
                break;
        }
    }
    
    // Update status bar
    const statusActiveTool = document.getElementById('status-active-tool');
    if (statusActiveTool) {
        const displayName = toolName.charAt(0).toUpperCase() + toolName.slice(1);
        statusActiveTool.textContent = `Tool: ${displayName}`;
    }
}

// Helper functions for modal handling
function openModal(modalId) {
    if (!modalId.startsWith('#')) {
        modalId = '#' + modalId;
    }
    const modal = document.querySelector(modalId);
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function closeModal(modalId) {
    if (!modalId.startsWith('#')) {
        modalId = '#' + modalId;
    }
    const modal = document.querySelector(modalId);
    if (modal) {
        modal.classList.add('hidden');
    }
}