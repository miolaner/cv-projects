/**
 * UI interactions and helper functions for PDF to SVG Renderer
 */

/**
 * Initialize drag and zoom functionality for SVG viewer
 */
function initDragAndZoom() {
    try {
        // Mouse events for dragging
        if (elements.svgContent) {
            elements.svgContent.addEventListener('mousedown', startDrag);
        }
        document.addEventListener('mousemove', drag);
        document.addEventListener('mouseup', endDrag);
        
        // Touch events for mobile
        if (elements.svgContent) {
            elements.svgContent.addEventListener('touchstart', startDragTouch);
        }
        document.addEventListener('touchmove', dragTouch);
        document.addEventListener('touchend', endDrag);
        
        // Wheel event for zooming
        if (elements.svgContainer) {
            elements.svgContainer.addEventListener('wheel', zoom);
        }
        
        // Zoom buttons
        if (elements.zoomInBtn) {
            elements.zoomInBtn.addEventListener('click', () => {
                zoomByFactor(1.2); // Zoom in by 20%
            });
        }
        
        if (elements.zoomOutBtn) {
            elements.zoomOutBtn.addEventListener('click', () => {
                zoomByFactor(0.8); // Zoom out by 20%
            });
        }
        
        // Reset view button
        if (elements.resetViewBtn) {
            elements.resetViewBtn.addEventListener('click', resetView);
        }
    } catch (error) {
        console.error("Error in initDragAndZoom:", error);
    }
}

/**
 * Start dragging with mouse
 */
function startDrag(e) {
    try {
        // Don't start dragging during calibration
        if (appState.isCalibrating) return;
        
        // Check if shift key is pressed for multi-select
        const isMultiSelect = e.shiftKey;
        
        // Don't allow drag initiating on elements we want to be selectable
        // First, attempt to find if we're near a measurable element
        const nearbyElement = findClosestMeasurableElement ? findClosestMeasurableElement(e) : null;
        
        if (nearbyElement) {
            // If we're near a measurable element, don't start dragging
            // Instead, trigger a click event to select the element
            if (window.handleSvgClick) {
                window.handleSvgClick({
                    target: nearbyElement,
                    clientX: e.clientX,
                    clientY: e.clientY,
                    stopPropagation: () => {},
                    shiftKey: isMultiSelect  // Pass the shift key state
                });
            }
            return;
        }
        
        // Otherwise, get the target element type
        const tagName = e.target.tagName.toLowerCase();
        const elementType = tagName.includes(':') ? tagName.split(':')[1] : tagName;
        
        // Don't initiate dragging if clicked on a measurable element
        if (['line', 'path', 'polyline', 'rect'].includes(elementType)) {
            return;
        }
        
        // If clicking on empty area and not using shift key, clear selections
        if (!isMultiSelect) {
            if (window.clearAllSelections) {
                window.clearAllSelections();
            }
        }
        
        // Set flag for dragging
        appState.isDragging = true;
        appState.dragStartX = e.clientX - appState.viewportX;
        appState.dragStartY = e.clientY - appState.viewportY;
        
        if (elements.svgContent) {
            elements.svgContent.style.cursor = 'grabbing';
        }
        
        // Prevent event from bubbling to avoid triggering click handlers
        e.stopPropagation();
    } catch (error) {
        console.error("Error in startDrag:", error);
    }
}

/**
 * Start dragging (touch)
 */
function startDragTouch(e) {
    appState.isDragging = true;
    appState.dragStartX = e.touches[0].clientX - appState.viewportX;
    appState.dragStartY = e.touches[0].clientY - appState.viewportY;
}

/**
 * Dragging
 */
function drag(e) {
    if (!appState.isDragging) return;
    
    appState.viewportX = e.clientX - appState.dragStartX;
    appState.viewportY = e.clientY - appState.dragStartY;
    
    if (window.updateSvgPosition) {
        window.updateSvgPosition();
    }
}

/**
 * Dragging (touch)
 */
function dragTouch(e) {
    if (!appState.isDragging) return;
    
    appState.viewportX = e.touches[0].clientX - appState.dragStartX;
    appState.viewportY = e.touches[0].clientY - appState.dragStartY;
    
    if (window.updateSvgPosition) {
        window.updateSvgPosition();
    }
}

/**
 * End dragging
 */
function endDrag() {
    appState.isDragging = false;
    if (elements.svgContent) {
        elements.svgContent.style.cursor = 'move';
    }
}

/**
 * Zoom with mouse wheel
 */
function zoom(e) {
    e.preventDefault();
    
    // Don't start another zoom if we're still rendering
    if (appState.isRendering) return;
    
    // Get the SVG container's position
    const svgContainerRect = elements.svgContainer.getBoundingClientRect();
    
    // Calculate the mouse position relative to the container
    const mouseX = e.clientX - svgContainerRect.left;
    const mouseY = e.clientY - svgContainerRect.top;
    
    // Calculate position relative to the transformed SVG content
    // This accounts for the current translation
    const svgX = mouseX - appState.viewportX;
    const svgY = mouseY - appState.viewportY;
    
    // Determine zoom direction
    const delta = e.deltaY || e.detail || e.wheelDelta;
    
    // Calculate new scale
    const oldScale = appState.currentScale;
    if (delta > 0) {
        appState.currentScale = Math.max(0.1, appState.currentScale / 1.1); // Zoom out
    } else {
        appState.currentScale = Math.min(10, appState.currentScale * 1.1); // Zoom in
    }
    
    // Calculate the scaling factor
    const scaleFactor = appState.currentScale / oldScale;
    
    // Adjust the viewport to keep the mouse position fixed
    // when zooming in or out
    appState.viewportX = mouseX - svgX * scaleFactor;
    appState.viewportY = mouseY - svgY * scaleFactor;
    
    // Update zoom level display immediately
    if (window.updateZoomLevel) {
        window.updateZoomLevel();
    }
    
    // Apply transform immediately
    if (window.applySvgTransform) {
        window.applySvgTransform();
    }
}

/**
 * Zoom by specific factor
 */
function zoomByFactor(factor) {
    if (appState.isRendering) return;
    
    const oldScale = appState.currentScale;
    appState.currentScale = appState.currentScale * factor;
    
    // Enforce min/max zoom limits
    if (appState.currentScale < 0.1) appState.currentScale = 0.1;
    if (appState.currentScale > 10) appState.currentScale = 10;
    
    // Center the zoom if we have an SVG element
    if (appState.currentSvgElement && elements.svgContainer) {
        // Get the center of the visible area
        const containerRect = elements.svgContainer.getBoundingClientRect();
        const centerX = containerRect.width / 2;
        const centerY = containerRect.height / 2;
        
        // Calculate the position in the SVG at the center of the visible area
        const svgX = centerX - appState.viewportX;
        const svgY = centerY - appState.viewportY;
        
        // Calculate scaling factor
        const scaleFactor = appState.currentScale / oldScale;
        
        // Adjust viewport to keep the center point fixed
        appState.viewportX = centerX - svgX * scaleFactor;
        appState.viewportY = centerY - svgY * scaleFactor;
    }
    
    // Update zoom level and apply transform
    if (window.updateZoomLevel) {
        window.updateZoomLevel();
    }
    
    if (window.applySvgTransform) {
        window.applySvgTransform();
    }
}

/**
 * Reset view
 */
function resetView() {
    appState.currentScale = appState.initialScale;
    appState.viewportX = 0;
    appState.viewportY = 0;
    
    // Clear all selections
    if (window.clearAllSelections) {
        window.clearAllSelections();
    }
    
    // Cancel calibration if active
    if (appState.isCalibrating && window.endCalibration) {
        window.endCalibration();
    }
    
    if (window.updateZoomLevel) {
        window.updateZoomLevel();
    }
    
    if (window.applySvgTransform) {
        window.applySvgTransform();
    }
}

// Export functions to window
window.initDragAndZoom = initDragAndZoom;
window.zoomByFactor = zoomByFactor;
window.resetView = resetView;