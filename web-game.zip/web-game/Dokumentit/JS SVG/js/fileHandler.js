/**
 * fileHandler.js - Handles file operations for PDF to SVG Workspace
 * Including file upload, loading, saving, and exporting
 */

/**
 * Handle file selection from upload
 * @param {File} file - The selected PDF file
 */
function handleFileSelection(file) {
    // Check file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
        showError('File size exceeds the 10MB limit.');
        return;
    }
    
    // Update UI to show progress
    if (elements.uploadPrompt) {
        elements.uploadPrompt.classList.add('hidden');
    }
    if (elements.uploadProgress) {
        elements.uploadProgress.classList.remove('hidden');
    }
    if (elements.progressBar) {
        elements.progressBar.style.width = '10%';
    }
    if (elements.uploadStatus) {
        elements.uploadStatus.textContent = 'Preparing file...';
    }
    
    // Generate unique project ID
    const projectId = generateId();
    
    // Process the file and redirect to workspace
    setTimeout(() => {
        processFile(file, projectId);
    }, 100); // Small delay to allow UI to update
}

/**
 * Process the PDF file and prepare for workspace
 * @param {File} file - The PDF file to process
 * @param {string} projectId - Unique project identifier
 */
async function processFile(file, projectId) {
    try {
        // Read file as ArrayBuffer
        const arrayBuffer = await readFileAsArrayBuffer(file);
        
        // Store file data in localStorage
        const fileData = {
            name: file.name,
            type: file.type,
            size: file.size,
            lastModified: file.lastModified,
            data: arrayBufferToBase64(arrayBuffer),
            dateCreated: new Date().toISOString()
        };
        
        // Update progress
        if (elements.progressBar) {
            elements.progressBar.style.width = '50%';
        }
        if (elements.uploadStatus) {
            elements.uploadStatus.textContent = 'Processing PDF...';
        }
        
        // Create new project
        const project = {
            id: projectId,
            name: file.name.replace('.pdf', ''),
            description: '',
            fileData: fileData,
            savedMeasurements: [],
            scaleValue: null,
            scaleUnit: 'units',
            dateCreated: new Date().toISOString(),
            lastModified: new Date().toISOString()
        };
        
        // Save project in localStorage
        saveProjectData(project);
        
        // Add to recent files
        addToRecentFiles({
            id: projectId,
            name: project.name,
            dateCreated: project.dateCreated,
            lastModified: project.lastModified,
            thumbnail: '' // Could generate a thumbnail in the future
        });
        
        // Update progress
        if (elements.progressBar) {
            elements.progressBar.style.width = '100%';
        }
        if (elements.uploadStatus) {
            elements.uploadStatus.textContent = 'Redirecting to workspace...';
        }
        
        // Redirect to workspace with project ID
        setTimeout(() => {
            window.location.href = `workspace.html?project=${projectId}`;
        }, 500);
        
    } catch (error) {
        console.error('Error processing file:', error);
        if (elements.uploadPrompt) {
            elements.uploadPrompt.classList.remove('hidden');
        }
        if (elements.uploadProgress) {
            elements.uploadProgress.classList.add('hidden');
        }
        showError('Error processing file: ' + error.message);
    }
}

/**
 * Load project data from URL param
 */
function loadProjectFromURL() {
    // Get project ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const projectId = urlParams.get('project');
    
    if (!projectId) {
        showNewProjectPrompt();
        return;
    }
    
    // Load project data
    const project = getProjectData(projectId);
    
    if (!project) {
        showError('Project not found.');
        showNewProjectPrompt();
        return;
    }
    
    // Load project into application state
    appState.projectId = projectId;
    appState.projectName = project.name;
    appState.scaleValue = project.scaleValue;
    appState.scaleUnit = project.scaleUnit || 'units';
    appState.savedMeasurements = project.savedMeasurements || [];
    
    // Update UI to show loading
    if (elements.loadingOverlay) {
        elements.loadingOverlay.classList.remove('hidden');
    }
    
    // Load PDF from stored data
    loadPDF(project.fileData.data)
        .then(() => {
            // Update recent files with access time
            updateRecentFileAccess(projectId);
            
            // Load saved measurements
            if (window.loadSavedMeasurements) {
                window.loadSavedMeasurements();
            }
            
            // Update calibration display
            if (window.updateScaleDisplay) {
                window.updateScaleDisplay();
            }
            
            // Hide loading overlay - FIX: Here we need to add the 'hidden' class
            if (elements.loadingOverlay) {
                elements.loadingOverlay.classList.add('hidden');
            }
        })
        .catch(error => {
            console.error('Error loading PDF:', error);
            if (elements.loadingOverlay) {
                elements.loadingOverlay.classList.add('hidden');
            }
            showError('Error loading PDF: ' + error.message);
        });
}

/**
 * Show prompt for new project if no project ID in URL
 */
function showNewProjectPrompt() {
    // Could show a dialog to upload a new file or return to landing page
    if (elements.loadingOverlay) {
        elements.loadingOverlay.classList.add('hidden');
    }
    
    // For now, just redirect back to landing page
    window.location.href = 'index.html';
}

/**
 * Load PDF from base64 data
 * @param {string} base64Data - Base64 encoded PDF data
 */
async function loadPDF(base64Data) {
    try {
        // Convert base64 to array buffer
        const arrayBuffer = base64ToArrayBuffer(base64Data);
        
        // Load the PDF document
        appState.pdfDoc = await pdfjsLib.getDocument({
            data: arrayBuffer,
            fontExtraProperties: true
        }).promise;
        
        // Update UI
        appState.totalPages = appState.pdfDoc.numPages;
        
        // Update DOM elements if they exist
        if (elements.totalPagesEl) {
            elements.totalPagesEl.textContent = appState.totalPages;
        }
        
        // Set initial scale from settings
        const settings = loadSettings();
        appState.initialScale = settings.defaultScale;
        appState.currentScale = appState.initialScale;
        
        // Reset viewport position
        appState.viewportX = 0;
        appState.viewportY = 0;
        
        // Render first page
        appState.currentPageIndex = 0;
        
        if (window.renderCurrentPageAsSVG) {
            await window.renderCurrentPageAsSVG();
        }
        
        if (window.updatePageNavigation) {
            window.updatePageNavigation();
        }
        
        // Initialize interactions
        if (window.initDragAndZoom) {
            window.initDragAndZoom();
        }
        
        return true;
    } catch (error) {
        console.error('Error loading PDF:', error);
        throw error;
    }
}

/**
 * Save current project
 */
function saveProject() {
    // Get project name from input
    const projectName = elements.projectName ? elements.projectName.value.trim() : '';
    const projectDescription = elements.projectDescription ? elements.projectDescription.value.trim() : '';
    
    if (!projectName) {
        showError('Please enter a project name.');
        return;
    }
    
    // Hide save dialog
    if (elements.saveDialog) {
        elements.saveDialog.classList.add('hidden');
    }
    
    // Get current project data
    const project = getProjectData(appState.projectId);
    
    if (!project) {
        showError('Error: Project data not found.');
        return;
    }
    
    // Update project data
    project.name = projectName;
    project.description = projectDescription;
    project.savedMeasurements = appState.savedMeasurements;
    project.scaleValue = appState.scaleValue;
    project.scaleUnit = appState.scaleUnit;
    project.lastModified = new Date().toISOString();
    
    // Save updated project
    saveProjectData(project);
    
    // Update recent files entry
    updateRecentFile(appState.projectId, projectName);
    
    // Update application state
    appState.projectName = projectName;
    appState.isModified = false;
    
    // Show confirmation
    showToast('Project saved successfully');
}

/**
 * Show save dialog
 */
function showSaveDialog() {
    // Populate dialog with current project name
    if (elements.projectName) {
        elements.projectName.value = appState.projectName;
    }
    
    // Get project description if available
    const project = getProjectData(appState.projectId);
    if (project && elements.projectDescription) {
        elements.projectDescription.value = project.description || '';
    }
    
    // Show dialog
    if (elements.saveDialog) {
        elements.saveDialog.classList.remove('hidden');
    }
    
    // Focus on project name input
    setTimeout(() => {
        if (elements.projectName) {
            elements.projectName.focus();
        }
    }, 100);
}

/**
 * Show share dialog
 */
function showShareDialog() {
    // Ensure project is saved first
    if (appState.isModified) {
        if (confirm('Project has unsaved changes. Save now?')) {
            showSaveDialog();
            return;
        }
    }
    
    // Generate share link
    const shareUrl = `${window.location.origin}${window.location.pathname}?project=${appState.projectId}`;
    if (elements.shareLink) {
        elements.shareLink.value = shareUrl;
    }
    
    // Show dialog
    if (elements.shareDialog) {
        elements.shareDialog.classList.remove('hidden');
    }
}

/**
 * Copy share link to clipboard
 */
function copyShareLink() {
    if (elements.shareLink) {
        elements.shareLink.select();
        document.execCommand('copy');
        
        // Visual feedback
        if (elements.copyLinkBtn) {
            const originalText = elements.copyLinkBtn.innerHTML;
            elements.copyLinkBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>';
            
            setTimeout(() => {
                elements.copyLinkBtn.innerHTML = originalText;
            }, 2000);
        }
    }
}

/**
 * Export project as a file
 */
function exportProject() {
    // Get export options
    const includeMeasurements = elements.includeMeasurements ? elements.includeMeasurements.checked : true;
    const includeCalibration = elements.includeCalibration ? elements.includeCalibration.checked : true;
    
    // Get project data
    const project = getProjectData(appState.projectId);
    
    if (!project) {
        showError('Error: Project data not found.');
        return;
    }
    
    // Create export package
    const exportData = {
        id: project.id,
        name: project.name,
        description: project.description,
        fileData: project.fileData,
        dateCreated: project.dateCreated,
        lastModified: project.lastModified,
        version: '1.0'
    };
    
    // Include optional data based on settings
    if (includeMeasurements) {
        exportData.savedMeasurements = project.savedMeasurements;
    }
    
    if (includeCalibration) {
        exportData.scaleValue = project.scaleValue;
        exportData.scaleUnit = project.scaleUnit;
    }
    
    // Convert to JSON and download
    const jsonData = JSON.stringify(exportData);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name.replace(/\s+/g, '_')}.pdfsvg`;
    a.click();
    
    URL.revokeObjectURL(url);
    
    // Close dialog
    if (elements.shareDialog) {
        elements.shareDialog.classList.add('hidden');
    }
}

/**
 * Download current SVG
 */
function downloadSvg() {
    if (!appState.currentSvgElement) {
        showError('No SVG to download');
        return;
    }
    
    try {
        // Clone the SVG to preserve original dimensions
        const svgClone = appState.currentSvgElement.cloneNode(true);
        
        // Ensure SVG has namespace
        if (!svgClone.getAttribute('xmlns')) {
            svgClone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        }
        
        // Add measurement annotations if present
        if (appState.savedMeasurements.length > 0 && confirm('Include measurement annotations in the SVG?')) {
            addMeasurementAnnotationsToSvg(svgClone);
        }
        
        // Convert to string
        const serializer = new XMLSerializer();
        let svgString = serializer.serializeToString(svgClone);
        
        // Add SVG declaration
        if (!svgString.startsWith('<?xml')) {
            svgString = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n' + svgString;
        }
        
        // Create download link
        const blob = new Blob([svgString], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `${appState.projectName || 'svg'}_page_${appState.currentPageIndex + 1}.svg`;
        a.click();
        
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Error downloading SVG:', error);
        showError('Error downloading SVG: ' + error.message);
    }
}

/**
 * Add measurement annotations to SVG for export
 * @param {SVGElement} svgElement - The SVG element to add annotations to
 */
function addMeasurementAnnotationsToSvg(svgElement) {
    // Implementation would create annotation elements in the SVG
    // This is a placeholder for that functionality
    
    // Example: adding a group for annotations
    const annotationsGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    annotationsGroup.setAttribute('id', 'measurement-annotations');
    
    // For each saved measurement, create annotation elements
    appState.savedMeasurements.forEach(measurement => {
        // Create text element for label
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', measurement.centerX);
        text.setAttribute('y', measurement.centerY);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('fill', measurement.color);
        text.setAttribute('font-size', '12px');
        text.textContent = `${measurement.label}: ${measurement.length.toFixed(2)} ${measurement.unit}`;
        
        annotationsGroup.appendChild(text);
    });
    
    // Add annotations group to SVG
    svgElement.appendChild(annotationsGroup);
}

/**
 * Get project data from local storage
 * @param {string} projectId - The project ID to retrieve
 * @return {Object|null} The project data or null if not found
 */
function getProjectData(projectId) {
    const projectKey = `pdfsvg_project_${projectId}`;
    const projectJson = localStorage.getItem(projectKey);
    
    if (!projectJson) {
        return null;
    }
    
    try {
        return JSON.parse(projectJson);
    } catch (error) {
        console.error('Error parsing project data:', error);
        return null;
    }
}

/**
 * Save project data to local storage
 * @param {Object} project - The project data to save
 */
function saveProjectData(project) {
    const projectKey = `pdfsvg_project_${project.id}`;
    localStorage.setItem(projectKey, JSON.stringify(project));
}

/**
 * Load recent files from local storage
 */
function loadRecentFiles() {
    const settings = loadSettings();
    if (!settings.saveRecentFiles) {
        if (elements.recentFilesSection) {
            elements.recentFilesSection.classList.add('hidden');
        }
        return;
    }
    
    const recentFilesJson = localStorage.getItem('pdfsvg_recent_files');
    
    if (!recentFilesJson) {
        if (elements.recentFilesSection) {
            elements.recentFilesSection.classList.add('hidden');
        }
        return;
    }
    
    try {
        const recentFiles = JSON.parse(recentFilesJson);
        
        if (!recentFiles.length) {
            if (elements.recentFilesSection) {
                elements.recentFilesSection.classList.add('hidden');
            }
            return;
        }
        
        // Show recent files section
        if (elements.recentFilesSection) {
            elements.recentFilesSection.classList.remove('hidden');
        }
        
        // Populate recent files grid
        if (elements.recentFilesGrid) {
            elements.recentFilesGrid.innerHTML = '';
            
            // Sort by last accessed time (most recent first)
            recentFiles.sort((a, b) => new Date(b.lastAccessed) - new Date(a.lastAccessed));
            
            // Show up to 6 most recent files
            const filesToShow = recentFiles.slice(0, 6);
            
            filesToShow.forEach(file => {
                const card = createRecentFileCard(file);
                elements.recentFilesGrid.appendChild(card);
            });
        }
    } catch (error) {
        console.error('Error loading recent files:', error);
        
        if (elements.recentFilesSection) {
            elements.recentFilesSection.classList.add('hidden');
        }
    }
}

/**
 * Create a card element for a recent file
 * @param {Object} file - The file data
 * @return {HTMLElement} The card element
 */
function createRecentFileCard(file) {
    const card = document.createElement('div');
    card.className = 'file-card';
    
    // Format date for display
    const date = new Date(file.lastAccessed || file.lastModified || file.dateCreated);
    const formattedDate = date.toLocaleDateString();
    
    card.innerHTML = `
        <div class="file-card-header">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
            </svg>
        </div>
        <div class="file-card-body">
            <h3 class="file-card-title">${file.name}</h3>
            <p class="file-card-meta">Last opened: ${formattedDate}</p>
            <div class="file-card-actions">
                <button class="icon-button delete-file" data-id="${file.id}" title="Delete">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">
                        <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                    </svg>
                </button>
                <button class="primary-button open-file" data-id="${file.id}">Open</button>
            </div>
        </div>
    `;
    
    // Add event listeners
    card.querySelector('.open-file').addEventListener('click', () => {
        window.location.href = `workspace.html?project=${file.id}`;
    });
    
    card.querySelector('.delete-file').addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm('Are you sure you want to delete this project?')) {
            deleteProject(file.id);
            card.remove();
            
            // Hide section if empty
            if (elements.recentFilesGrid && elements.recentFilesGrid.children.length === 0) {
                if (elements.recentFilesSection) {
                    elements.recentFilesSection.classList.add('hidden');
                }
            }
        }
    });
    
    // Make the entire card clickable
    card.addEventListener('click', (e) => {
        // Don't trigger if clicking on a button
        if (!e.target.closest('button')) {
            window.location.href = `workspace.html?project=${file.id}`;
        }
    });
    
    return card;
}

/**
 * Add a file to the recent files list
 * @param {Object} file - File information to add
 */
function addToRecentFiles(file) {
    const settings = loadSettings();
    if (!settings.saveRecentFiles) {
        return;
    }
    
    // Add current time as last accessed
    file.lastAccessed = new Date().toISOString();
    
    // Get existing recent files
    const recentFilesJson = localStorage.getItem('pdfsvg_recent_files');
    let recentFiles = [];
    
    if (recentFilesJson) {
        try {
            recentFiles = JSON.parse(recentFilesJson);
        } catch (error) {
            console.error('Error parsing recent files:', error);
        }
    }
    
    // Check if file already exists
    const existingIndex = recentFiles.findIndex(f => f.id === file.id);
    
    if (existingIndex !== -1) {
        // Update existing entry
        recentFiles[existingIndex] = { ...recentFiles[existingIndex], ...file };
    } else {
        // Add new entry
        recentFiles.push(file);
    }
    
    // Limit to 20 recent files
    if (recentFiles.length > 20) {
        recentFiles = recentFiles.sort((a, b) => 
            new Date(b.lastAccessed) - new Date(a.lastAccessed)
        ).slice(0, 20);
    }
    
    // Save updated list
    localStorage.setItem('pdfsvg_recent_files', JSON.stringify(recentFiles));
}

/**
 * Update last access time for a recent file
 * @param {string} fileId - ID of the file to update
 */
function updateRecentFileAccess(fileId) {
    const recentFilesJson = localStorage.getItem('pdfsvg_recent_files');
    
    if (!recentFilesJson) {
        return;
    }
    
    try {
        const recentFiles = JSON.parse(recentFilesJson);
        const fileIndex = recentFiles.findIndex(f => f.id === fileId);
        
        if (fileIndex !== -1) {
            recentFiles[fileIndex].lastAccessed = new Date().toISOString();
            localStorage.setItem('pdfsvg_recent_files', JSON.stringify(recentFiles));
        }
    } catch (error) {
        console.error('Error updating recent file access:', error);
    }
}

/**
 * Update file name in recent files
 * @param {string} fileId - ID of the file to update
 * @param {string} newName - New name for the file
 */
function updateRecentFile(fileId, newName) {
    const recentFilesJson = localStorage.getItem('pdfsvg_recent_files');
    
    if (!recentFilesJson) {
        return;
    }
    
    try {
        const recentFiles = JSON.parse(recentFilesJson);
        const fileIndex = recentFiles.findIndex(f => f.id === fileId);
        
        if (fileIndex !== -1) {
            recentFiles[fileIndex].name = newName;
            recentFiles[fileIndex].lastModified = new Date().toISOString();
            localStorage.setItem('pdfsvg_recent_files', JSON.stringify(recentFiles));
        }
    } catch (error) {
        console.error('Error updating recent file:', error);
    }
}

/**
 * Delete a project
 * @param {string} projectId - ID of the project to delete
 */
function deleteProject(projectId) {
    // Delete project data
    localStorage.removeItem(`pdfsvg_project_${projectId}`);
    
    // Remove from recent files
    const recentFilesJson = localStorage.getItem('pdfsvg_recent_files');
    
    if (recentFilesJson) {
        try {
            const recentFiles = JSON.parse(recentFilesJson);
            const updatedFiles = recentFiles.filter(f => f.id !== projectId);
            localStorage.setItem('pdfsvg_recent_files', JSON.stringify(updatedFiles));
        } catch (error) {
            console.error('Error updating recent files:', error);
        }
    }
}

/**
 * Show a toast message
 * @param {string} message - Message to show
 * @param {number} duration - Duration in milliseconds
 */
function showToast(message, duration = 3000) {
    // Check if a toast container exists, or create one
    let toastContainer = document.querySelector('.toast-container');
    
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
        
        // Add styles if not already in stylesheet
        const style = document.createElement('style');
        style.textContent = `
            .toast-container {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 1000;
            }
            .toast {
                background-color: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 12px 20px;
                border-radius: 4px;
                margin-top: 10px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
                transition: opacity 0.3s, transform 0.3s;
                opacity: 0;
                transform: translateY(20px);
            }
            .toast.show {
                opacity: 1;
                transform: translateY(0);
            }
        `;
        document.head.appendChild(style);
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toastContainer.appendChild(toast);
    
    // Show the toast with animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Hide after duration
    setTimeout(() => {
        toast.classList.remove('show');
        
        // Remove from DOM after animation
        setTimeout(() => {
            toastContainer.removeChild(toast);
        }, 300);
    }, duration);
}

// Utility functions for file handling

/**
 * Read a file as ArrayBuffer
 * @param {File} file - The file to read
 * @return {Promise<ArrayBuffer>} The file contents as ArrayBuffer
 */
function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(event) {
            resolve(event.target.result);
        };
        
        reader.onerror = function(event) {
            reject(new Error('Error reading file: ' + event.target.error));
        };
        
        reader.readAsArrayBuffer(file);
    });
}

/**
 * Convert ArrayBuffer to Base64 string
 * @param {ArrayBuffer} buffer - The ArrayBuffer to convert
 * @return {string} Base64 encoded string
 */
function arrayBufferToBase64(buffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    
    return window.btoa(binary);
}

/**
 * Convert Base64 string to ArrayBuffer
 * @param {string} base64 - The Base64 string to convert
 * @return {ArrayBuffer} The decoded ArrayBuffer
 */
function base64ToArrayBuffer(base64) {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    
    return bytes.buffer;
}

/**
 * Load application settings
 * @return {Object} The loaded settings
 */
function loadSettings() {
    const defaultSettings = {
        theme: 'system',
        saveRecentFiles: true,
        autoSave: true,
        defaultScale: 1.0,
        renderingQuality: 'standard'
    };
    
    const savedSettings = localStorage.getItem('pdfSvgSettings');
    if (!savedSettings) {
        return defaultSettings;
    }
    
    try {
        return { ...defaultSettings, ...JSON.parse(savedSettings) };
    } catch (error) {
        console.error('Error parsing settings:', error);
        return defaultSettings;
    }
}

/**
 * Clear all application data from local storage
 */
function clearLocalStorage() {
    // Keep settings but clear projects and recent files
    const settings = loadSettings();
    localStorage.clear();
    localStorage.setItem('pdfSvgSettings', JSON.stringify(settings));
}

// Export functions to window object for cross-file access
window.handleFileSelection = handleFileSelection;
window.loadProjectFromURL = loadProjectFromURL;
window.loadPDF = loadPDF;
window.saveProject = saveProject;
window.showSaveDialog = showSaveDialog;
window.showShareDialog = showShareDialog;
window.copyShareLink = copyShareLink;
window.exportProject = exportProject;
window.downloadSvg = downloadSvg;
window.getProjectData = getProjectData;
window.saveProjectData = saveProjectData;
window.loadRecentFiles = loadRecentFiles;
window.loadSettings = loadSettings;
window.clearLocalStorage = clearLocalStorage;