/**
 * app.js - Main application script for PDF to SVG Workspace
 * Handles core application functionality and initialization
 */

// Application state
const appState = {
    // Current session
    currentFile: null,
    pdfDoc: null,
    projectName: '',
    projectId: '',
    isModified: false,
    
    // PDF document state
    currentPageIndex: 0,
    totalPages: 1,
    
    // View state
    currentScale: 1.0,
    initialScale: 1.0,
    currentSvgElement: null,
    viewportX: 0,
    viewportY: 0,
    
    // Measurement state
    selectedElements: [],
    savedMeasurements: [],
    
    // Tool state
    activeTool: 'select',
    isCalibrating: false,
    dragEnabled: true,
    
    // Calibration state
    scaleValue: null,
    scaleUnit: "units",
    calibrationStep: 0,
    
    // Auto line selection settings
    directionTolerance: 20,
    connectionThreshold: 5,
    
    // Rendering state
    isRendering: false,
    pendingRender: false
};

// Cache for DOM elements
const elements = {};

/**
 * Initialize the application
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize PDF.js worker
    if (typeof pdfjsLib !== 'undefined') {
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
    }
    
    // Detect if we're in the landing page or workspace
    const isWorkspace = document.querySelector('.workspace-container') !== null;
    
    if (isWorkspace) {
        initWorkspace();
    } else {
        initLandingPage();
    }
    
    // Initialize theme based on stored preference or system default
    initTheme();
});

/**
 * Initialize theme based on preferences
 */
function initTheme() {
    const storedTheme = localStorage.getItem('theme') || 'system';
    setTheme(storedTheme);
    
    // Update theme select if it exists
    const themeSelect = document.getElementById('theme-select');
    if (themeSelect) {
        themeSelect.value = storedTheme;
        themeSelect.addEventListener('change', function() {
            setTheme(this.value);
            localStorage.setItem('theme', this.value);
        });
    }
}

/**
 * Set application theme
 * @param {string} theme - Theme to set ('light', 'dark', 'system')
 */
function setTheme(theme) {
    if (theme === 'system') {
        // Use system preference
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.body.classList.add('theme-dark');
        } else {
            document.body.classList.remove('theme-dark');
        }
        document.documentElement.classList.add('theme-system');
    } else if (theme === 'dark') {
        document.body.classList.add('theme-dark');
        document.documentElement.classList.remove('theme-system');
    } else {
        document.body.classList.remove('theme-dark');
        document.documentElement.classList.remove('theme-system');
    }
}

/**
 * Initialize the landing page
 */
function initLandingPage() {
    cacheLandingPageElements();
    initLandingPageEventListeners();
    
    // Call loadRecentFiles if it's available
    if (window.loadRecentFiles) {
        window.loadRecentFiles();
    } else {
        console.warn('loadRecentFiles function not available');
    }
}

/**
 * Initialize the workspace
 */
function initWorkspace() {
    // Cache elements after components are loaded
    window.addEventListener('componentLoaded', function(event) {
        // After all components are loaded, cache elements and initialize
        if (event.detail.id === 'modals-container') {
            setTimeout(() => {
                cacheWorkspaceElements();
                
                // Initialize workspace after elements are cached
                initTools();
                
                // Load project if loadProjectFromURL is available
                if (window.loadProjectFromURL) {
                    window.loadProjectFromURL();
                } else {
                    console.warn('loadProjectFromURL function not available');
                    
                    // Fallback: hide loading overlay
                    if (elements.loadingOverlay) {
                        elements.loadingOverlay.classList.add('hidden');
                    }
                }
            }, 100);
        }
    });
}

/**
 * Cache landing page elements
 */
function cacheLandingPageElements() {
    elements.uploadArea = document.getElementById('upload-area');
    elements.fileInput = document.getElementById('file-input');
    elements.uploadPrompt = document.getElementById('upload-prompt');
    elements.uploadProgress = document.getElementById('upload-progress');
    elements.progressBar = document.querySelector('.progress-bar');
    elements.uploadStatus = document.getElementById('upload-status');
    elements.browseFilesBtn = document.getElementById('browse-files-btn');
    elements.recentFilesGrid = document.getElementById('recent-files-grid');
    elements.recentFilesSection = document.getElementById('recent-files');
    elements.settingsBtn = document.getElementById('settings-btn');
    elements.settingsModal = document.getElementById('settings-modal');
    elements.closeSettingsBtn = document.querySelector('#settings-modal .close-button');
    elements.saveSettingsBtn = document.getElementById('save-settings-btn');
    elements.clearStorageBtn = document.getElementById('clear-storage-btn');
}

/**
 * Cache workspace elements
 */
function cacheWorkspaceElements() {
    // Header elements
    elements.saveBtn = document.getElementById('save-btn');
    elements.downloadSvgBtn = document.getElementById('download-svg-btn');
    elements.shareBtn = document.getElementById('share-btn');
    elements.prevPageBtn = document.getElementById('prev-page');
    elements.nextPageBtn = document.getElementById('next-page');
    elements.currentPageEl = document.getElementById('current-page');
    elements.totalPagesEl = document.getElementById('total-pages');
    elements.zoomInBtn = document.getElementById('zoom-in-btn');
    elements.zoomOutBtn = document.getElementById('zoom-out-btn');
    elements.resetViewBtn = document.getElementById('reset-view-btn');
    elements.zoomLevel = document.getElementById('zoom-level');
    elements.settingsBtn = document.getElementById('settings-btn');
    
    // Tool elements
    elements.selectTool = document.getElementById('select-tool');
    elements.measureTool = document.getElementById('measure-tool');
    elements.autoSelectTool = document.getElementById('auto-select-tool');
    elements.calibrateTool = document.getElementById('calibrate-tool');
    elements.panTool = document.getElementById('pan-tool');
    elements.activeToolOptions = document.getElementById('active-tool-options');
    
    // Tool option panels
    elements.autoSelectOptions = document.getElementById('auto-select-options');
    elements.calibrationOptions = document.getElementById('calibration-options');
    elements.directionTolerance = document.getElementById('direction-tolerance');
    elements.directionToleranceValue = document.getElementById('direction-tolerance-value');
    elements.connectionThreshold = document.getElementById('connection-threshold');
    elements.connectionThresholdValue = document.getElementById('connection-threshold-value');
    elements.calibratePointsBtn = document.getElementById('calibrate-points-btn');
    elements.calibrateLinesBtn = document.getElementById('calibrate-lines-btn');
    elements.clearCalibrationBtn = document.getElementById('clear-calibration-btn');
    elements.highlightModeCheckbox = document.getElementById('highlight-mode-checkbox');
    
    // Content area elements
    elements.loadingOverlay = document.getElementById('loading-overlay');
    elements.svgContainer = document.getElementById('svg-container');
    elements.svgContent = document.getElementById('svg-content');
    elements.infoPanel = document.getElementById('info-panel');
    elements.selectionCount = document.getElementById('selection-count');
    elements.selectionCountDisplay = document.getElementById('selection-count');
    elements.lineLength = document.getElementById('line-length');
    elements.lineLengthDisplay = document.getElementById('line-length');
    elements.totalLength = document.getElementById('total-length');
    elements.totalLengthDisplay = document.getElementById('total-length');
    elements.unitsDisplay = document.getElementById('units-display');
    elements.totalUnitsDisplay = document.getElementById('total-units-display');
    elements.totalLengthInfo = document.getElementById('total-length-info');
    elements.calibrationPoint1 = document.getElementById('calibration-point1');
    elements.calibrationPoint2 = document.getElementById('calibration-point2');
    elements.calibrationLine = document.getElementById('calibration-line');
    elements.measurementAnnotations = document.getElementById('measurement-annotations');
    
    // Properties panel elements
    elements.closeProperties = document.getElementById('close-properties');
    elements.noSelectionPanel = document.getElementById('no-selection-panel');
    elements.elementProperties = document.getElementById('element-properties');
    elements.elementType = document.getElementById('element-type');
    elements.elementLength = document.getElementById('element-length');
    elements.elementCoordinates = document.getElementById('element-coordinates');
    elements.measurementGroup = document.getElementById('measurement-group');
    elements.groupElementCount = document.getElementById('group-element-count');
    elements.groupTotalLength = document.getElementById('group-total-length');
    elements.measurementLabel = document.getElementById('measurement-label');
    elements.measurementColor = document.getElementById('measurement-color');
    elements.saveMeasurementBtn = document.getElementById('save-measurement-btn');
    elements.clearSelectionBtn = document.getElementById('clear-selection-btn');
    elements.currentScaleFactor = document.getElementById('current-scale-factor');
    elements.unitSelectPanel = document.getElementById('unit-select-panel');
    elements.measurementList = document.getElementById('measurement-list');
    elements.exportMeasurementsBtn = document.getElementById('export-measurements-btn');
    
    // Dialog elements
    elements.calibrationDialog = document.getElementById('calibration-dialog');
    elements.realDistance = document.getElementById('real-distance');
    elements.realDistanceInput = document.getElementById('real-distance');
    elements.unitSelectDialog = document.getElementById('unit-select-dialog');
    elements.unitSelect = document.getElementById('unit-select-dialog');
    elements.confirmScaleBtn = document.getElementById('confirm-scale-btn');
    elements.cancelScaleBtn = document.getElementById('cancel-scale-btn');
    elements.lineCalibrationDialog = document.getElementById('line-calibration-dialog');
    elements.linesScaleDialog = document.getElementById('line-calibration-dialog');
    elements.linesRealDistance = document.getElementById('lines-real-distance');
    elements.linesRealDistanceInput = document.getElementById('lines-real-distance');
    elements.linesUnitSelect = document.getElementById('lines-unit-select');
    elements.linesScaleDialog = document.getElementById('line-calibration-dialog');
    elements.confirmLinesScaleBtn = document.getElementById('confirm-lines-scale-btn');
    elements.cancelLinesScaleBtn = document.getElementById('cancel-lines-scale-btn');
    elements.saveDialog = document.getElementById('save-dialog');
    elements.projectName = document.getElementById('project-name');
    elements.projectDescription = document.getElementById('project-description');
    elements.confirmSaveBtn = document.getElementById('confirm-save-btn');
    elements.cancelSaveBtn = document.getElementById('cancel-save-btn');
    elements.shareDialog = document.getElementById('share-dialog');
    elements.shareLink = document.getElementById('share-link');
    elements.copyLinkBtn = document.getElementById('copy-link-btn');
    elements.includeMeasurements = document.getElementById('include-measurements');
    elements.includeCalibration = document.getElementById('include-calibration');
    elements.exportProjectBtn = document.getElementById('export-project-btn');
    elements.closeShareBtn = document.getElementById('close-share-btn');
    
    // Scale-related elements
    elements.scaleFactorDisplay = document.getElementById('current-scale-factor');
    elements.scaleInfo = document.getElementById('scale-settings');
    
    // Status bar elements
    elements.statusZoom = document.getElementById('status-zoom');
    elements.statusScale = document.getElementById('status-scale');
    elements.statusPage = document.getElementById('status-page');
    elements.statusSelection = document.getElementById('status-selection');
    elements.statusActiveTool = document.getElementById('status-active-tool');
}

/**
 * Initialize landing page event listeners
 */
function initLandingPageEventListeners() {
    // File upload event listeners
    if (elements.uploadArea) {
        elements.uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            elements.uploadArea.classList.add('active');
        });
        
        elements.uploadArea.addEventListener('dragleave', () => {
            elements.uploadArea.classList.remove('active');
        });
        
        elements.uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            elements.uploadArea.classList.remove('active');
            
            const file = e.dataTransfer.files[0];
            if (file && file.type === 'application/pdf') {
                if (window.handleFileSelection) {
                    window.handleFileSelection(file);
                } else {
                    showError('File handler not available. Please refresh the page.');
                }
            } else {
                showError('Please select a valid PDF file.');
            }
        });
    }
    
    // Browse files button
    if (elements.browseFilesBtn) {
        elements.browseFilesBtn.addEventListener('click', () => {
            if (elements.fileInput) {
                elements.fileInput.click();
            }
        });
    }
    
    // File input change
    if (elements.fileInput) {
        elements.fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                if (window.handleFileSelection) {
                    window.handleFileSelection(file);
                } else {
                    showError('File handler not available. Please refresh the page.');
                }
            }
        });
    }
    
    // Settings button
    if (elements.settingsBtn) {
        elements.settingsBtn.addEventListener('click', () => {
            if (elements.settingsModal) {
                elements.settingsModal.classList.remove('hidden');
            }
        });
    }
    
    // Close settings button
    if (elements.closeSettingsBtn) {
        elements.closeSettingsBtn.addEventListener('click', () => {
            if (elements.settingsModal) {
                elements.settingsModal.classList.add('hidden');
            }
        });
    }
    
    // Save settings button
    if (elements.saveSettingsBtn) {
        elements.saveSettingsBtn.addEventListener('click', () => {
            saveSettings();
            if (elements.settingsModal) {
                elements.settingsModal.classList.add('hidden');
            }
        });
    }
    
    // Clear storage button
    if (elements.clearStorageBtn) {
        elements.clearStorageBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to clear all saved data? This cannot be undone.')) {
                if (window.clearLocalStorage) {
                    window.clearLocalStorage();
                    
                    // Refresh the recent files display
                    if (window.loadRecentFiles) {
                        window.loadRecentFiles();
                    }
                }
            }
        });
    }
}

/**
 * Initialize tool selection and options
 */
function initTools() {
    // Tool buttons
    const toolButtons = [
        elements.selectTool,
        elements.measureTool,
        elements.autoSelectTool,
        elements.calibrateTool,
        elements.panTool
    ];
    
    // Add click event for each tool button
    toolButtons.forEach(button => {
        if (button) {
            button.addEventListener('click', () => {
                selectTool(button.id.replace('-tool', ''));
            });
        }
    });
    
    // Initialize with select tool active
    selectTool('select');
    
    // Initialize calibration if elements exist
    if (elements.calibratePointsBtn) {
        elements.calibratePointsBtn.addEventListener('click', function() {
            if (window.startCalibration) {
                window.startCalibration();
            } else {
                console.warn('startCalibration function not available');
            }
        });
    }
    
    if (elements.calibrateLinesBtn) {
        elements.calibrateLinesBtn.addEventListener('click', function() {
            if (window.startLineCalibration) {
                window.startLineCalibration();
            } else {
                console.warn('startLineCalibration function not available');
            }
        });
    }
    
    if (elements.clearCalibrationBtn) {
        elements.clearCalibrationBtn.addEventListener('click', function() {
            if (window.clearCalibration) {
                window.clearCalibration();
            } else {
                console.warn('clearCalibration function not available');
            }
        });
    }
    
    // Direction tolerance slider
    if (elements.directionTolerance) {
        elements.directionTolerance.addEventListener('input', function() {
            const value = this.value;
            if (elements.directionToleranceValue) {
                elements.directionToleranceValue.textContent = value + '°';
            }
            appState.directionTolerance = parseInt(value);
        });
    }
    
    // Connection threshold slider
    if (elements.connectionThreshold) {
        elements.connectionThreshold.addEventListener('input', function() {
            const value = this.value;
            if (elements.connectionThresholdValue) {
                elements.connectionThresholdValue.textContent = value + 'px';
            }
            appState.connectionThreshold = parseInt(value);
        });
    }
}

/**
 * Select a tool and update the UI
 * @param {string} toolName - The name of the tool to select
 */
function selectTool(toolName) {
    // Deactivate all tools
    const toolButtons = document.querySelectorAll('.tool-button');
    toolButtons.forEach(button => button.classList.remove('active'));
    
    // Hide all tool option panels
    const optionPanels = document.querySelectorAll('.tool-option-panel');
    optionPanels.forEach(panel => panel.classList.add('hidden'));
    
    // Activate the selected tool
    const selectedToolBtn = document.getElementById(toolName + '-tool');
    if (selectedToolBtn) {
        selectedToolBtn.classList.add('active');
    }
    
    // Show the appropriate options panel
    const optionsPanel = document.getElementById(toolName + '-options');
    if (optionsPanel) {
        optionsPanel.classList.remove('hidden');
    }
    
    // Update application state
    appState.activeTool = toolName;
    
    // Update drag behavior
    appState.dragEnabled = (toolName === 'pan');
    
    // Update status bar
    updateStatusBar();
    
    // Tool-specific behavior
    switch (toolName) {
        case 'select':
            if (elements.svgContent) {
                elements.svgContent.style.cursor = 'default';
            }
            break;
        case 'measure':
            if (elements.svgContent) {
                elements.svgContent.style.cursor = 'crosshair';
            }
            break;
        case 'auto-select':
            if (elements.svgContent) {
                elements.svgContent.style.cursor = 'default';
            }
            break;
        case 'calibrate':
            if (elements.svgContent) {
                elements.svgContent.style.cursor = 'crosshair';
            }
            break;
        case 'pan':
            if (elements.svgContent) {
                elements.svgContent.style.cursor = 'move';
            }
            break;
    }
}

/**
 * Update the status bar with current information
 */
function updateStatusBar() {
    if (elements.statusZoom) {
        elements.statusZoom.textContent = `Zoom: ${Math.round(appState.currentScale * 100)}%`;
    }
    
    if (elements.statusScale) {
        const scaleText = appState.scaleValue !== null 
            ? `Scale: 1 unit = ${appState.scaleValue.toFixed(4)} ${appState.scaleUnit}`
            : 'Scale: Not set';
        elements.statusScale.textContent = scaleText;
    }
    
    if (elements.statusPage) {
        elements.statusPage.textContent = `Page ${appState.currentPageIndex + 1} of ${appState.totalPages}`;
    }
    
    if (elements.statusSelection) {
        elements.statusSelection.textContent = `${appState.selectedElements.length} items selected`;
    }
    
    if (elements.statusActiveTool) {
        const toolName = appState.activeTool.charAt(0).toUpperCase() + appState.activeTool.slice(1);
        elements.statusActiveTool.textContent = `Tool: ${toolName}`;
    }
}

/**
 * Handle keyboard shortcuts
 * @param {KeyboardEvent} event - The keyboard event
 */
function handleKeyboardShortcuts(event) {
    // Don't process shortcuts when focused on input elements
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
        return;
    }
    
    // Tool shortcuts
    switch (event.key.toLowerCase()) {
        case 'v': // Select tool
            selectTool('select');
            break;
        case 'm': // Measure tool
            selectTool('measure');
            break;
        case 'a': // Auto-select tool
            selectTool('auto-select');
            break;
        case 'c': // Calibrate tool
            selectTool('calibrate');
            break;
        case 'h': // Pan tool
            selectTool('pan');
            break;
        case 'escape': // Clear selection
            if (window.clearAllSelections) {
                window.clearAllSelections();
            }
            break;
        case 'delete': // Delete measurement (if selected)
            if (window.deleteMeasurement) {
                window.deleteMeasurement();
            }
            break;
        case '=': // Zoom in (also catches + with shift)
        case '+':
            if (window.zoomByFactor) {
                window.zoomByFactor(1.2);
            }
            event.preventDefault();
            break;
        case '-': // Zoom out
            if (window.zoomByFactor) {
                window.zoomByFactor(0.8);
            }
            event.preventDefault();
            break;
        case '0': // Reset view
            if (window.resetView) {
                window.resetView();
            }
            break;
        case 'arrowleft': // Previous page
            if (window.prevPage) {
                window.prevPage();
            }
            break;
        case 'arrowright': // Next page
            if (window.nextPage) {
                window.nextPage();
            }
            break;
        case 's': // Save (with Ctrl/Cmd)
            if (event.ctrlKey || event.metaKey) {
                event.preventDefault();
                if (window.showSaveDialog) {
                    window.showSaveDialog();
                }
            }
            break;
    }
}

/**
 * Show an error message to the user
 * @param {string} message - The error message to display
 */
function showError(message) {
    alert(message); // Simple alert for now, could be enhanced with a custom error UI
}

/**
 * Simple utility to generate a unique ID
 * @return {string} A unique ID
 */
function generateId() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

/**
 * Save application settings
 */
function saveSettings() {
    const themeSelect = document.getElementById('theme-select');
    const saveRecentFiles = document.getElementById('save-recent-files');
    const autoSave = document.getElementById('auto-save');
    const defaultScale = document.getElementById('default-scale');
    const renderingQuality = document.getElementById('rendering-quality');
    
    const settings = {
        theme: themeSelect ? themeSelect.value : 'system',
        saveRecentFiles: saveRecentFiles ? saveRecentFiles.checked : true,
        autoSave: autoSave ? autoSave.checked : true,
        defaultScale: defaultScale ? parseFloat(defaultScale.value) : 1.0,
        renderingQuality: renderingQuality ? renderingQuality.value : 'standard'
    };
    
    localStorage.setItem('pdfSvgSettings', JSON.stringify(settings));
    
    // Apply settings immediately
    setTheme(settings.theme);
}

// Add keyboard shortcut listener
document.addEventListener('keydown', handleKeyboardShortcuts);

// Export global functions
window.showError = showError;
window.generateId = generateId;
window.updateStatusBar = updateStatusBar;
window.appState = appState;
window.elements = elements;