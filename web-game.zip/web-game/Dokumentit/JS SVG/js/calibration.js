/**
 * Scale calibration functionality for PDF to SVG Renderer
 */

/**
 * Initialize scale calibration
 */
function initScaleCalibration() {
    // Calibration buttons
    elements.calibrateScaleBtn.addEventListener('click', startCalibration);
    elements.calibrateFromLinesBtn.addEventListener('click', startLineCalibration);
    elements.clearScaleBtn.addEventListener('click', clearCalibration);
    
    // Scale dialog buttons
    elements.confirmScaleBtn.addEventListener('click', setScale);
    elements.cancelScaleBtn.addEventListener('click', cancelCalibration);
    
    // Lines scale dialog buttons
    elements.confirmLinesScaleBtn.addEventListener('click', setScaleFromLines);
    elements.cancelLinesScaleBtn.addEventListener('click', cancelCalibration);
    
    // SVG container click for calibration points
    elements.svgContainer.addEventListener('click', handleCalibrationClick);
    
    // Update displays
    updateScaleDisplay();
}

/**
 * Start calibration process using points
 */
function startCalibration() {
    appState.isCalibrating = true;
    appState.isLineCalibration = false;
    appState.calibrationStep = 1;
    
    // Show calibration message
    alert("Click on the first point of the known distance");
    
    // Prevent other interactions during calibration
    elements.svgContent.style.pointerEvents = "none";
}

/**
 * Start calibration process using selected lines
 */
function startLineCalibration() {
    // Check if we have any selected elements
    if (appState.selectedElements.length === 0) {
        alert("Please select one or more lines before calibrating from lines");
        return;
    }
    
    appState.isCalibrating = true;
    appState.isLineCalibration = true;
    
    // Calculate the total length of the selected elements
    let totalSvgLength = 0;
    appState.selectedElements.forEach(item => {
        totalSvgLength += calculateElementLength(item.element, item.elementType);
    });
    
    console.log("Total SVG length of selected lines:", totalSvgLength);
    
    // Store the total length as a global variable
    window.totalSvgLength = totalSvgLength;
    
    // Show the lines calibration dialog
    elements.linesScaleDialog.classList.remove('hidden');
}

/**
 * Set scale based on selected lines
 */
function setScaleFromLines() {
    try {
        const realDistance = parseFloat(elements.linesRealDistanceInput.value);
        const unit = elements.linesUnitSelect.value;
        
        if (isNaN(realDistance) || realDistance <= 0) {
            alert("Please enter a valid distance");
            return;
        }
        
        // Get the SVG length from the window variable
        const totalSvgLength = window.totalSvgLength;
        
        console.log("Line Calibration: SVG length =", totalSvgLength, "units");
        console.log("Line Calibration: Real-world distance =", realDistance, unit);
        
        // Calculate the simple scale factor (real distance / SVG distance)
        const scaleFactor = realDistance / totalSvgLength;
        console.log("Line Calibration: Scale factor =", scaleFactor, unit + "/unit");
        
        // Store the simple scale value and unit
        appState.scaleValue = scaleFactor;
        appState.scaleUnit = unit;
        
        console.log("Set scale values - scaleValue:", appState.scaleValue, "scaleUnit:", appState.scaleUnit);
        
        // Update the display with the new scale
        updateScaleDisplay();
        
        // Update measurements
        updateMeasurementsDisplay();
        
        // Clean up the global variable
        delete window.totalSvgLength;
    } catch (error) {
        console.error("Error in setScaleFromLines:", error);
    } finally {
        // End calibration
        endCalibration();
    }
}

/**
 * Handle clicks during calibration
 */
function handleCalibrationClick(event) {
    // Skip if we're in line calibration mode, as that doesn't use click points
    if (appState.isLineCalibration) return;
    
    if (!appState.isCalibrating) return;
    
    // Convert click to SVG coordinates
    const svgContainerRect = elements.svgContainer.getBoundingClientRect();
    const clickX = event.clientX - svgContainerRect.left;
    const clickY = event.clientY - svgContainerRect.top;
    
    if (appState.calibrationStep === 1) {
        // First point
        elements.calibrationPoint1.style.left = clickX + 'px';
        elements.calibrationPoint1.style.top = clickY + 'px';
        elements.calibrationPoint1.classList.remove('hidden');
        
        // Store position
        appState.calibrationPoint1Pos = { x: clickX, y: clickY };
        
        // Next step
        appState.calibrationStep = 2;
        alert("Now click on the second point of the known distance");
        
    } else if (appState.calibrationStep === 2) {
        // Second point
        elements.calibrationPoint2.style.left = clickX + 'px';
        elements.calibrationPoint2.style.top = clickY + 'px';
        elements.calibrationPoint2.classList.remove('hidden');
        
        // Store position
        appState.calibrationPoint2Pos = { x: clickX, y: clickY };
        
        // Draw line between points
        drawCalibrationLine();
        
        // Show scale dialog
        showScaleDialog();
    }
    
    // Stop event propagation
    event.stopPropagation();
}

/**
 * Draw line between calibration points
 */
function drawCalibrationLine() {
    // Calculate line properties
    const dx = appState.calibrationPoint2Pos.x - appState.calibrationPoint1Pos.x;
    const dy = appState.calibrationPoint2Pos.y - appState.calibrationPoint1Pos.y;
    const length = Math.sqrt(dx * dx + dy * dy);
    const angle = Math.atan2(dy, dx) * 180 / Math.PI;
    
    // Position and rotate line
    elements.calibrationLine.style.width = length + 'px';
    elements.calibrationLine.style.left = appState.calibrationPoint1Pos.x + 'px';
    elements.calibrationLine.style.top = appState.calibrationPoint1Pos.y + 'px';
    elements.calibrationLine.style.transform = `rotate(${angle}deg)`;
    elements.calibrationLine.style.transformOrigin = '0 0';
    
    // Show line
    elements.calibrationLine.classList.remove('hidden');
}

/**
 * Show scale dialog
 */
function showScaleDialog() {
    elements.scaleDialog.classList.remove('hidden');
    elements.realDistanceInput.focus();
}

/**
 * Set scale based on calibration
 */
function setScale() {
    const realDistance = parseFloat(elements.realDistanceInput.value);
    const unit = elements.unitSelect.value;
    
    if (isNaN(realDistance) || realDistance <= 0) {
        alert("Please enter a valid distance");
        return;
    }
    
    // Calculate pixel distance - important to use currentScale to account for zoom level
    const dx = appState.calibrationPoint2Pos.x - appState.calibrationPoint1Pos.x;
    const dy = appState.calibrationPoint2Pos.y - appState.calibrationPoint1Pos.y;
    const pixelDistance = Math.sqrt(dx * dx + dy * dy) / appState.currentScale;
    
    console.log("Calibration: Measured pixel distance =", pixelDistance);
    console.log("Calibration: Real-world distance =", realDistance, unit);
    
    // Calculate scale factor (real units per pixel)
    appState.scaleValue = realDistance / pixelDistance;
    appState.scaleUnit = unit;
    
    console.log("Calibration: Scale factor calculated =", appState.scaleValue, unit + "/unit");
    
    // Update display
    updateScaleDisplay();
    
    // Update any current measurements
    updateMeasurementsDisplay();
    
    // End calibration mode
    endCalibration();
}

/**
 * Cancel calibration
 */
function cancelCalibration() {
    endCalibration();
}

/**
 * Clear calibration
 */
function clearCalibration() {
    appState.scaleValue = null;
    appState.scaleUnit = "units";
    updateScaleDisplay();
    updateMeasurementsDisplay();
}

/**
 * End calibration mode
 */
function endCalibration() {
    appState.isCalibrating = false;
    appState.calibrationStep = 0;
    appState.isLineCalibration = false;
    
    // Hide calibration elements
    elements.calibrationPoint1.classList.add('hidden');
    elements.calibrationPoint2.classList.add('hidden');
    elements.calibrationLine.classList.add('hidden');
    elements.scaleDialog.classList.add('hidden');
    elements.linesScaleDialog.classList.add('hidden');
    
    // Re-enable interactions
    elements.svgContent.style.pointerEvents = "auto";
}

/**
 * Update scale display
 */
function updateScaleDisplay() {
    if (appState.scaleValue !== null) {
        elements.scaleFactorDisplay.textContent = `1 unit = ${appState.scaleValue.toFixed(6)} ${appState.scaleUnit}`;
        elements.scaleInfo.classList.remove('hidden');
        elements.unitsDisplay.textContent = appState.scaleUnit;
        elements.totalUnitsDisplay.textContent = appState.scaleUnit;
    } else {
        elements.scaleFactorDisplay.textContent = "Not set";
        elements.scaleInfo.classList.add('hidden');
        elements.unitsDisplay.textContent = "units";
        elements.totalUnitsDisplay.textContent = "units";
    }
}