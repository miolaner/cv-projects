/**
 * PDF to SVG rendering with improved SVG interactivity
 */

/**
 * Render the current page as SVG
 */
async function renderCurrentPageAsSVG() {
    if (!appState.pdfDoc) return;
    
    // If already rendering, mark as pending
    if (appState.isRendering) {
        appState.pendingRender = true;
        return;
    }
    
    try {
        appState.isRendering = true;
        const pageNum = appState.currentPageIndex + 1;
        
        console.log(`Rendering page ${pageNum} as SVG`);
        
        // Get the page
        const page = await appState.pdfDoc.getPage(pageNum);
        
        // Get the viewport for the page
        const viewport = page.getViewport({ scale: 1.0 }); // Base scale of 1.0
        
        // Create SVG and set viewport
        const opList = await page.getOperatorList();
        
        // Use the SVGGraphics class
        const svgGfx = new pdfjsLib.SVGGraphics(page.commonObjs, page.objs);
        svgGfx.embedFonts = true;
        
        // Generate SVG element
        const svg = await svgGfx.getSVG(opList, viewport);
        
        // Clear previous content
        if (elements.svgContent) {
            elements.svgContent.innerHTML = '';
            
            // Append the SVG to the container
            elements.svgContent.appendChild(svg);
            appState.currentSvgElement = svg;
            
            // Set SVG dimensions
            svg.style.width = `${viewport.width}px`;
            svg.style.height = `${viewport.height}px`;
            
            // IMPORTANT: Fix SVG element interactivity
            // Make the root SVG not capture events, but allow its children to be interactive
            svg.style.pointerEvents = 'none';
            
            // Make all measurable elements interactive
            const measurableElements = svg.querySelectorAll('path, line, polyline, rect, circle, polygon');
            measurableElements.forEach(el => {
                el.style.pointerEvents = 'all'; // Make element interactive
                el.style.cursor = 'pointer';    // Show pointer cursor on hover
                
                // Ensure each element has a unique ID
                if (!el.id) {
                    el.id = 'svg-element-' + Math.random().toString(36).substr(2, 9);
                }
                
                // Add data attribute to identify measurable elements
                el.setAttribute('data-measurable', 'true');
            });
            
            console.log(`Processed ${measurableElements.length} measurable elements`);
        }
        
        // Apply current scale and position
        applySvgTransform();
        
        // Update UI if elements exist
        if (elements.currentPageEl) {
            elements.currentPageEl.textContent = pageNum;
        }
        
        updateZoomLevel();
        
        // Add hover effect to measurable elements
        addHoverEffectToMeasurableElements();
        
        // Initialize measurement handlers
        if (window.initLineSelection) {
            window.initLineSelection();
        }
        
        // IMPORTANT: Make sure loading overlay is hidden after rendering
        if (elements.loadingOverlay) {
            elements.loadingOverlay.classList.add('hidden');
        }
    } catch (error) {
        console.error('Error rendering SVG:', error);
        // Ensure loading overlay is hidden even on error
        if (elements.loadingOverlay) {
            elements.loadingOverlay.classList.add('hidden');
        }
        showError('Error rendering SVG: ' + error.message);
    } finally {
        appState.isRendering = false;
        
        // If another render was requested, do it now
        if (appState.pendingRender) {
            appState.pendingRender = false;
            setTimeout(() => renderCurrentPageAsSVG(), 10);
        }
    }
}

/**
 * Update page navigation controls
 */
function updatePageNavigation() {
    // Update page info display
    if (elements.currentPageEl) {
        elements.currentPageEl.textContent = appState.currentPageIndex + 1;
    }
    
    if (elements.totalPagesEl) {
        elements.totalPagesEl.textContent = appState.totalPages;
    }
    
    // Enable/disable prev/next buttons
    if (elements.prevPageBtn) {
        elements.prevPageBtn.disabled = appState.currentPageIndex <= 0;
    }
    
    if (elements.nextPageBtn) {
        elements.nextPageBtn.disabled = appState.currentPageIndex >= appState.totalPages - 1;
    }
    
    // Update status bar
    if (elements.statusPage) {
        elements.statusPage.textContent = `Page ${appState.currentPageIndex + 1} of ${appState.totalPages}`;
    }
}

/**
 * Navigate to previous page
 */
function prevPage() {
    if (appState.currentPageIndex > 0) {
        appState.currentPageIndex--;
        renderCurrentPageAsSVG();
        updatePageNavigation();
    }
}

/**
 * Navigate to next page
 */
function nextPage() {
    if (appState.currentPageIndex < appState.totalPages - 1) {
        appState.currentPageIndex++;
        renderCurrentPageAsSVG();
        updatePageNavigation();
    }
}

/**
 * Add hover effect to all measurable elements
 */
function addHoverEffectToMeasurableElements() {
    // Check if highlight mode checkbox exists and is checked
    // Default to true if element doesn't exist yet
    const highlightModeEnabled = elements.highlightModeCheckbox ? 
        elements.highlightModeCheckbox.checked : true;
        
    if (!highlightModeEnabled) return;
    
    const allMeasurableElements = document.querySelectorAll('#svg-content path, #svg-content line, #svg-content polyline, #svg-content rect, #svg-content circle, #svg-content polygon');
    
    allMeasurableElements.forEach(element => {
        // Remove any existing listeners first to prevent duplicates
        element.removeEventListener('mouseenter', handleElementHoverIn);
        element.removeEventListener('mouseleave', handleElementHoverOut);
        
        // Create hover overlay instead of modifying the original element
        element.addEventListener('mouseenter', handleElementHoverIn);
        element.addEventListener('mouseleave', handleElementHoverOut);
    });
}

/**
 * Handle hover in effect
 */
function handleElementHoverIn(event) {
    console.log('Hover in:', this);
    // Don't highlight if element is already selected
    if (this === appState.highlightedElement) return;
    
    // Get the original element's geometry
    const tagName = this.tagName.toLowerCase();
    const elementType = tagName.includes(':') ? tagName.split(':')[1] : tagName;
    
    // Store the original element for reference
    this.dataset.hovering = "true";
    
    // Create overlay container if it doesn't exist
    let overlayContainer = document.getElementById('hover-overlay-container');
    if (!overlayContainer && appState.currentSvgElement) {
        overlayContainer = document.createElementNS("http://www.w3.org/2000/svg", "g");
        overlayContainer.setAttribute("id", "hover-overlay-container");
        appState.currentSvgElement.appendChild(overlayContainer);
    }
    
    if (!overlayContainer) return;
    
    // Create overlay element based on original element type
    let overlayElement;
    if (elementType === 'line') {
        overlayElement = document.createElementNS("http://www.w3.org/2000/svg", "line");
        overlayElement.setAttribute("x1", this.getAttribute("x1"));
        overlayElement.setAttribute("y1", this.getAttribute("y1"));
        overlayElement.setAttribute("x2", this.getAttribute("x2"));
        overlayElement.setAttribute("y2", this.getAttribute("y2"));
    } else if (elementType === 'rect') {
        overlayElement = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        overlayElement.setAttribute("x", this.getAttribute("x"));
        overlayElement.setAttribute("y", this.getAttribute("y"));
        overlayElement.setAttribute("width", this.getAttribute("width"));
        overlayElement.setAttribute("height", this.getAttribute("height"));
    } else if (elementType === 'circle') {
        overlayElement = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        overlayElement.setAttribute("cx", this.getAttribute("cx"));
        overlayElement.setAttribute("cy", this.getAttribute("cy"));
        overlayElement.setAttribute("r", this.getAttribute("r"));
    } else if (elementType === 'path') {
        overlayElement = document.createElementNS("http://www.w3.org/2000/svg", "path");
        overlayElement.setAttribute("d", this.getAttribute("d"));
    } else if (elementType === 'polyline') {
        overlayElement = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
        overlayElement.setAttribute("points", this.getAttribute("points"));
    } else if (elementType === 'polygon') {
        overlayElement = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
        overlayElement.setAttribute("points", this.getAttribute("points"));
    } else {
        // Unsupported element type
        return;
    }
    
    // Apply highlight styling to overlay
    overlayElement.setAttribute("stroke", "#3388ff");
    overlayElement.setAttribute("stroke-width", "2");
    overlayElement.setAttribute("fill", "none");
    overlayElement.setAttribute("stroke-opacity", "0.8");
    overlayElement.setAttribute("pointer-events", "none");
    overlayElement.setAttribute("vector-effect", "non-scaling-stroke");
    
    // Generate a unique id for this element if it doesn't have one
    if (!this.uniqueId) {
        this.uniqueId = Math.random().toString(36).substr(2, 9);
    }
    overlayElement.dataset.forElement = this.uniqueId;
    
    // Add overlay to container
    overlayContainer.appendChild(overlayElement);
}

/**
 * Handle hover out effect
 */
function handleElementHoverOut(event) {
    // Remove hovering flag
    this.dataset.hovering = "false";
    
    // Remove the overlay for this element
    if (this.uniqueId) {
        const overlay = document.querySelector(`#hover-overlay-container [data-for-element="${this.uniqueId}"]`);
        if (overlay) {
            overlay.remove();
        }
    }
}

/**
 * Update zoom level display
 */
function updateZoomLevel() {
    if (elements.zoomLevel) {
        elements.zoomLevel.textContent = Math.round(appState.currentScale * 100) + '%';
    }
    
    if (elements.statusZoom) {
        elements.statusZoom.textContent = `Zoom: ${Math.round(appState.currentScale * 100)}%`;
    }
}

/**
 * Apply scale and position transform to SVG
 */
function applySvgTransform() {
    if (!appState.currentSvgElement) return;
    
    // Apply scale
    appState.currentSvgElement.style.transform = `scale(${appState.currentScale})`;
    appState.currentSvgElement.style.transformOrigin = '0 0';
    
    // Apply position
    updateSvgPosition();
}

/**
 * Update SVG position for dragging
 */
function updateSvgPosition() {
    if (elements.svgContent) {
        elements.svgContent.style.transform = `translate(${appState.viewportX}px, ${appState.viewportY}px)`;
    }
}

/**
 * Apply interactive behavior to SVG elements
 * This improves selection and interaction
 */
function makeElementsInteractive() {
    // Find the SVG content
    const svg = appState.currentSvgElement;
    if (!svg) return;
    
    console.log('Making SVG elements interactive...');
    
    // Process all measurable elements
    const measurableTypes = ['path', 'line', 'polyline', 'rect', 'circle', 'polygon'];
    
    measurableTypes.forEach(type => {
        const elements = svg.querySelectorAll(type);
        elements.forEach(el => {
            // Set pointer-events to ensure element can be clicked
            el.style.pointerEvents = 'all';
            
            // Add cursor change on hover
            el.style.cursor = 'pointer';
            
            // Add data attribute for easier selection
            el.setAttribute('data-measurable', 'true');
            
            // Add click handler directly to element
            el.addEventListener('click', function(event) {
                // Prevent event from bubbling to container
                event.stopPropagation();
                
                // Create a synthetic event to pass to the handler
                if (window.handleSvgClick) {
                    window.handleSvgClick({
                        target: this,
                        clientX: event.clientX,
                        clientY: event.clientY,
                        stopPropagation: function() {},
                        shiftKey: event.shiftKey
                    });
                }
            });
        });
        
        console.log(`Made ${elements.length} ${type} elements interactive`);
    });
}

// Export functions to window
window.renderCurrentPageAsSVG = renderCurrentPageAsSVG;
window.updatePageNavigation = updatePageNavigation;
window.prevPage = prevPage;
window.nextPage = nextPage;
window.updateZoomLevel = updateZoomLevel;
window.applySvgTransform = applySvgTransform;
window.updateSvgPosition = updateSvgPosition;
window.makeElementsInteractive = makeElementsInteractive;