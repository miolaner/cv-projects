Documentation of Changes Made:
1. Game Room System:
Multiple Game Rooms: The game state has been updated to support multiple game rooms (gameRooms object), with each room being independent of the others. Each game room has its own players, powerups, points, game state (paused or not), and timer.

Room Creation and Management: Players can create new game rooms (createRoom message). Each room has a unique ID, a creator (the player who created the room), and the ability to manage game-related logic independently.

Join Room: Players can join existing rooms (joinRoom message). The system checks if the room exists and whether the game has already started before allowing players to join.

Game Start: Only the creator of the room can start the game (startGame message). Upon starting the game, the timer begins, and all players are informed.

Game End: The game timer counts down, and when it reaches zero, the game ends (gameEnd message). A message is sent to all players in the room to notify them of the game's conclusion.

Player Leave: Players can leave the room (leaveRoom message). If a player leaves, the system handles cleanup and ensures that the room is properly updated (e.g., if the creator leaves, a new creator is assigned).

2. Game State Updates:
Game Timer: Each room has its own timer (startGameTimer). When the timer expires, the game ends for that room.

Powerups and Points: Each room has its own powerups and points, and these are updated as players collect them (collectPoint and collectPowerup messages).

Player Movement: The player's position is updated and broadcast to others in the room (move message).

3. Broadcasting:
Room-Specific Broadcasting: A new broadcastToRoom function has been introduced, which ensures messages are sent only to players within a specific room.

Lobby Updates: When a room is created or a player joins or leaves a room, the server broadcasts updates to other players not currently in a room (roomAdded, roomRemoved, etc.).

4. Client Disconnect:
Player Cleanup: When a client disconnects (close event), the server ensures that the player is removed from the room, and any necessary cleanup occurs (e.g., reassigning the creator, removing an empty room).

Possible Changes Needed for the Frontend:
Room Management UI:

Room List: The frontend will need to handle a list of available rooms (lobbyInit message) and allow players to join existing rooms or create new ones.

Room Creation: When a player creates a new room (createRoom message), the UI should show the new room in the lobby and allow the player to start the game.

Room Joining: When a player joins a room (joinRoom message), the UI must update to show the room's details (players, powerups, points).

Game State UI:

Player Movement: The frontend will need to send player movement data (move message) based on user input (e.g., keyboard or mouse).

Game Timer: A countdown timer needs to be displayed in the UI based on the timer message sent by the server.

Score and Powerups: The frontend should track player scores and display collected points and powerups. It should listen for collectPoint and collectPowerup messages to update the UI accordingly.

Player Actions:

Start Game: The UI should only allow the creator to start the game. When the game starts, it should display the game state, and the players should see the countdown timer.

Pause/Resume: Implement a pause button that sends a togglePause message to the server, and display whether the game is paused.

Game End: The frontend should handle the gameEnd message and display a message to the player(s) indicating the game has ended.

Handling Disconnects and Reconnects:

Player Disconnect: When a player disconnects, the UI should handle the player leaving the room and update the UI accordingly (e.g., removing the player’s representation).

Room Cleanup: When a room becomes empty, it should be removed from the lobby list.

Improved User Experience:

Room Full Message: The frontend should notify players if they try to join a room that has already started or is full.

Creator Controls: Ensure that only the room creator can start the game, and this should be visually represented in the UI.

Visual Updates for Powerups/Points:

Display Powerups and Points: Powerups and points should be visible in the game world, and when a player collects them, the corresponding items should disappear.