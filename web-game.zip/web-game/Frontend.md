Game.js:
Player movement stage 1 ready:

- Player can move using ARROW keys
- Diagonal movement does not increase the speed of the player, it uses math to calculate the diagonal movement to be the same as playerSpeed

### Functions in Game.js

1. **Player Movement**

   - Handles player movement using ARROW keys.
   - Ensures diagonal movement speed is consistent with the player's speed by using mathematical calculations.

   ```javascript
   function handlePlayerMovement() {
     // ...existing code for movement logic...
   }
   ```

2. **Collision Detection**

   - Detects when a player collides with a powerup or point.
   - Sends a WebSocket message to the server with the collision details.

   ```javascript
   function detectCollision(entity) {
     if (entity.type === "powerup") {
       sendWebSocketMessage({
         type: "collectPowerup",
         id: entity.id,
         userId: player.id,
       });
     } else if (entity.type === "point") {
       sendWebSocketMessage({
         type: "collectPoint",
         id: entity.id,
         userId: player.id,
       });
     }
   }
   ```

3. **WebSocket Message Handling**

   - Listens for messages from the server to update the frontend when powerups or points are collected.

   ```javascript
   function handleWebSocketMessage(message) {
     if (message.type === "collectPowerup") {
       // Update frontend to reflect collected powerup
     } else if (message.type === "collectPoint") {
       // Update frontend to reflect collected point
     }
   }
   ```

4. **populateGrid**

   - Populates the game grid with powerups, points, and players based on the data received from the server.

   ```javascript
   function populateGrid(powerups, points, players) {
     // Creates and positions powerups, points, and players on the grid
   }
   ```

5. **checkCollisions**

   - Checks for collisions between the player and powerups or points.
   - Sends a WebSocket message to the server when a collision is detected.

   ```javascript
   function checkCollisions() {
     // Detects collisions and sends messages to the server
   }
   ```

6. **pauseResumeGame**

   - Toggles the pause state of the game based on the server's message.
   - Displays a pause menu when the game is paused.

   ```javascript
   function pauseResumeGame(status) {
     // Handles pausing and resuming the game
   }
   ```

7. **updatePlayerPosition**

   - Updates the player's position based on keyboard input.
   - Sends the new position to the server if it has changed.

   ```javascript
   function updatePlayerPosition(deltaTime) {
     // Updates player position and sends it to the server
   }
   ```

8. **updateFPScounter**

   - Calculates and updates the FPS counter on the frontend.

   ```javascript
   function updateFPScounter() {
     // Updates the FPS counter
   }
   ```

9. **gameLoop**

   - The main game loop that updates the game state every frame.

   ```javascript
   function gameLoop(timeStamp) {
     // Updates game state and requests the next animation frame
   }
   ```

### Functions in Timer.js

1. **updateTimer**

   - Updates the timer display on the frontend based on the message received from the WebSocket server.
   - Listens for messages of type `"timer"` and updates the timer element with the remaining game time.

   ```javascript
   function updateTimer(message) {
     if (message.type !== "timer") return;
     const time = message.gameTime;
     const timerElement = document.getElementById("timer");
     timerElement.textContent = `Time left: ${time}s`;
   }
   ```

### WebSocket Expectations

1. **Messages Sent to the Server**

   - When a player collects a powerup:
     ```json
     {
       "type": "collectPowerup",
       "id": "powerup.id",
       "userId": "player.id"
     }
     ```
   - When a player collects a point:
     ```json
     {
       "type": "collectPoint",
       "id": "point.id",
       "userId": "player.id"
     }
     ```
   - Player movement:
     ```json
     {
       "type": "move",
       "x": "playerPosition.x",
       "y": "playerPosition.y"
     }
     ```
   - Toggle pause:
     ```json
     {
       "type": "togglePause"
     }
     ```

2. **Messages Received from the Server**
   - Confirmation of a collected powerup:
     ```json
     {
       "type": "collectPowerup",
       "id": "powerup.id"
     }
     ```
   - Confirmation of a collected point:
     ```json
     {
       "type": "collectPoint",
       "id": "point.id"
     }
     ```
   - Timer update:
     ```json
     {
       "type": "timer",
       "gameTime": "remainingTime"
     }
     ```
   - Game initialization:
     ```json
     {
       "type": "init",
       "id": "player.id",
       "powerups": "array of powerups",
       "points": "array of points",
       "players": "object of players"
     }
     ```
   - State update:
     ```json
     {
       "type": "stateUpdate",
       "players": "object of players"
     }
     ```
   - Pause state:
     ```json
     {
       "type": "pauseState",
       "gamePaused": "true or false"
     }
     ```
