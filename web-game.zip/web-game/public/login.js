import { socket } from "./game.js"

export let roomId = null;
export let playerId = null;
let rooms = null;
let playersList = null;
let usernameVar = null;


export function MainHandleLoginScreen() {
    if (socket.readyState === WebSocket.OPEN) {
        console.log("Connected to server");
        handleLoginScreen();
    } else {
        socket.addEventListener("open", () => {
            console.log("Connected to server");
            handleLoginScreen();
        });
    }

    socket.addEventListener("message", (event) => {
        const message = JSON.parse(event.data);

        if (message.type === "error") {
            // Handle error messages
            alert(message.message);
            // If we're in the joining state, go back to room selection
            const lobbyTitle = document.querySelector("h2");
            if (lobbyTitle && lobbyTitle.innerText === "Game Lobby (Joining)") {
                handleLoginScreen();
                // After a short delay, show the join game screen again
                setTimeout(() => {
                    document.querySelector("button[innerText='Join Game']").click();
                }, 100);
            }
            return;
        }

        if (message.type === "lobbyInit") {
            rooms = message.availableRooms;
            console.log("Available rooms: ", rooms);
            
            // If the player is on the join screen, refresh the room list
            const roomSelectContainer = document.getElementById("room-select-container");
            if (roomSelectContainer) {
                displayRoomList(rooms, roomSelectContainer);
            }
        }

        if (message.type === "roomAdded") {
            // Add the new room to our rooms list
            if (!rooms) rooms = [];
            rooms.push(message.room);
            console.log("Room added: ", message.room);
            
            // If the player is on the join screen, refresh the room list
            const roomSelectContainer = document.getElementById("room-select-container");
            if (roomSelectContainer) {
                displayRoomList(rooms, roomSelectContainer);
            }
        }

        if (message.type === "roomRemoved") {
            // Remove the room from our rooms list
            if (rooms) {
                rooms = rooms.filter(room => room.id !== message.roomId);
                console.log("Room removed: ", message.roomId);
                
                // If the player is on the join screen, refresh the room list
                const roomSelectContainer = document.getElementById("room-select-container");
                if (roomSelectContainer) {
                    displayRoomList(rooms, roomSelectContainer);
                }
            }
        }
        if (message.type === "roomCreated") {
            roomId = message.roomId;
            playerId = message.playerId;
            console.log("Room ID: ", roomId, " Player ID: ", playerId);
            const loginContainer = document.getElementById("login-container");
            loginContainer.innerHTML = "";
            const lobbyTitle = document.createElement("h2");
            lobbyTitle.innerText = "Game Lobby (Hosting)";
            loginContainer.appendChild(lobbyTitle);
            const playerList = document.createElement("ul");
            playerList.id = "player-list";
            loginContainer.appendChild(playerList);
            const startGameButton = document.createElement("button");
            startGameButton.innerText = "Start Game";
            startGameButton.disabled = false;
            loginContainer.appendChild(startGameButton);
            const addressContainer = document.createElement("div");
            addressContainer.id = "address-container";
            addressContainer.innerText = `Room ID: ${roomId}`;
            loginContainer.appendChild(addressContainer);
            const playersArray = Array.isArray(message.players) ? message.players : Object.values(message.players);
            updateLobby(playersArray);
            socket.addEventListener("message", (event) => {
                const message = JSON.parse(event.data);
                if (message.type === "lobbyUpdate") {
                    updateLobby(message.players);
                }
            });
            startGameButton.addEventListener("click", () => {
                // Check that there is atleast 2 players
                if (playersList.length < 2) {
                    alert("At least 2 players are required to start the game.");
                    return;
                }
                socket.send(JSON.stringify({ type: "startGame" }));
            });
        }
        if (message.type === "roomJoined") {
            roomId = message.roomId;
            playerId = message.playerId;
            console.log("Room ID: ", roomId, " Player ID: ", playerId);
            const loginContainer = document.getElementById("login-container");
            loginContainer.innerHTML = "";
            const lobbyTitle = document.createElement("h2");
            lobbyTitle.innerText = "Game Lobby (Joining)";
            loginContainer.appendChild(lobbyTitle);
            const playerList = document.createElement("ul");
            playerList.id = "player-list";
            loginContainer.appendChild(playerList);
            const addressContainer = document.createElement("div");
            addressContainer.id = "address-container";
            addressContainer.innerText = `Room ID: ${roomId}`;
            loginContainer.appendChild(addressContainer);
            const playersArray = Array.isArray(message.players) ? message.players : Object.values(message.players);
            updateLobby(playersArray);
        }
        if (message.type === "playerJoinedRoom") {
            console.log("Player joined room: ", message);
            // if not already in the list, add the player
            if (playersList.some((player) => player.name === message.player.name)) {
                return
            }
            playersList.push(message.player);
            updateLobby(playersList);
        }
        if (message.type === "playerLeftRoom") {
            playersList = playersList.filter((player) => player.id !== message.playerId);
            updateLobby(playersList);
        }
    })
}

function displayRoomList(rooms, container) {
    container.innerHTML = "";
    
    if (rooms.length === 0) {
        const noRoomsMessage = document.createElement("div");
        noRoomsMessage.textContent = "No rooms available. Create a new one!";
        noRoomsMessage.classList.add("no-rooms-message");
        container.appendChild(noRoomsMessage);
        return;
    }
    
    const roomsGrid = document.createElement("div");
    roomsGrid.classList.add("rooms-grid");
    
    rooms.forEach(room => {
        const roomCard = document.createElement("div");
        roomCard.classList.add("room-card");
        
        const roomTitle = document.createElement("h3");
        roomTitle.textContent = `Room ${room.id}`;
        
        const playersCount = document.createElement("p");
        playersCount.textContent = `Players: ${room.playerCount} / 4`;
        
        roomCard.appendChild(roomTitle);
        roomCard.appendChild(playersCount);
        console.log(room)
        
        // Add click event to join the room
        roomCard.addEventListener("click", () => {
            // Check if the room is full
            if (room.playerCount >= 4) {
                alert("Room is full. Please select another room.");
                return;
            }
            const username = usernameVar
            
            socket.send(JSON.stringify({ type: "joinRoom", roomId: room.id, playerName: username }));
        });
        
        roomsGrid.appendChild(roomCard);
    });
    
    container.appendChild(roomsGrid);
}

export function handleLoginScreen() {
    document.getElementById("game-container").style.display = "none";
    const loginContainer = document.getElementById("login-container");
    
    // Clear existing content first
    loginContainer.innerHTML = "";
    
    // Set up container styles
    loginContainer.style.display = "flex";
    loginContainer.style.flexDirection = "column";
    loginContainer.style.alignItems = "center";
    loginContainer.style.justifyContent = "center";
    loginContainer.style.height = "auto"; // Use auto height instead of 100vh
    
    // Add game title
    const gameTitle = document.createElement("h1");
    gameTitle.innerText = "Terrain Takedown";
    loginContainer.appendChild(gameTitle);

    // Username input
    const usernameInput = document.createElement("input");
    usernameInput.type = "text";
    usernameInput.placeholder = "Enter your username";
    usernameInput.id = "username";
    loginContainer.appendChild(usernameInput);
    usernameInput.addEventListener("input", () => {
        usernameVar = document.getElementById("username").value;
    }
    );

    // Host or join game buttons
    const hostButton = document.createElement("button");
    hostButton.innerText = "Host Game";
    const joinButton = document.createElement("button");
    joinButton.innerText = "Join Game";
    loginContainer.appendChild(hostButton);
    loginContainer.appendChild(joinButton);

    // Address input/display
    const addressContainer = document.createElement("div");
    addressContainer.id = "address-container";
    loginContainer.appendChild(addressContainer);
    

    hostButton.addEventListener("click", () => {
        console.log("Username:",usernameVar)
        if (usernameVar === null) {
            alert("Please enter a username first");
            return;
        }
        addressContainer.innerText = `Hosting at: ws://localhost:3000`;
        setupLobby(true);
    });

    joinButton.addEventListener("click", () => {
        // First check if username is entered
        const username = usernameInput.value;
        if (!username) {
            alert("Please enter a username first");
            return;
        }
        
        // Clear existing elements in the login container
        loginContainer.innerHTML = "";
        
        // Add a heading
        const joinHeading = document.createElement("h2");
        joinHeading.textContent = "Select a Room to Join";
        loginContainer.appendChild(joinHeading);
        
        // Container for room selection
        const roomSelectContainer = document.createElement("div");
        roomSelectContainer.id = "room-select-container";
        loginContainer.appendChild(roomSelectContainer);
        
        // Refresh button to update room list
        const refreshButton = document.createElement("button");
        refreshButton.textContent = "Refresh Rooms";
        refreshButton.classList.add("refresh-button");
        refreshButton.addEventListener("click", () => {
            // Request updated room list from server
            socket.send(JSON.stringify({ type: "requestRooms" }));
        });
        loginContainer.appendChild(refreshButton);
        
        // Back button
        const backButton = document.createElement("button");
        backButton.textContent = "Back";
        backButton.classList.add("back-button");
        backButton.addEventListener("click", () => {
            // Simply call handleLoginScreen again to go back
            handleLoginScreen();
        });
        loginContainer.appendChild(backButton);
        
        // Display the rooms
        displayRoomList(rooms, roomSelectContainer);
        
        // Request fresh room data from server
        socket.send(JSON.stringify({ type: "requestRooms" }));
    });
}

export function setupLobby(isHost, serverAddress = null) {
    const loginContainer = document.getElementById("login-container");
    loginContainer.innerHTML = "";

    const lobbyTitle = document.createElement("h2");
    lobbyTitle.innerText = isHost ? "Game Lobby (Hosting)" : "Game Lobby (Joining)";
    loginContainer.appendChild(lobbyTitle);

    const playerList = document.createElement("ul");
    playerList.id = "player-list";
    loginContainer.appendChild(playerList);

    const startGameButton = document.createElement("button");
    startGameButton.innerText = "Start Game";
    startGameButton.disabled = true;
    loginContainer.appendChild(startGameButton);


    if (isHost) {
        // Send createRoom to server
        
        const username = usernameVar
        socket.send(JSON.stringify({ type: "createRoom", playerName: username }));
        
    } else {
        // Connect to the server
        socket.addEventListener("open", () => {
            console.log("Connected to server");
        });
        socket.addEventListener("message", (event) => {
            const message = JSON.parse(event.data);
            if (message.type === "lobbyUpdate") {
                updateLobby(message.players);
            }
        });
    }
}

export function updateLobby(players) {
    console.log("Players in the list", players)
    playersList = players;
    const playerList = document.getElementById("player-list");
    playerList.innerHTML = "";
    players.forEach((player) => {
        const playerItem = document.createElement("li");
        playerItem.innerText = `${player.name}`;
        playerList.appendChild(playerItem);
    });
}