import { GRID_SIZE, MAP_HEIGHT, MAP_WIDTH, terrainMap, TERRAIN_PROPERTIES, gamePaused, keys, collisionMap, socket, getPlayerSpeedMultiplier } from "./game.js";

// Initialize variables
let PLAYER_SPEED_MULTIPLIER_TERRAIN = 1; // Speed multiplier for the player based on terrain
let PLAYER_SPEED_MULTIPLIER = 1; // Speed multiplier for the player
const PLAYER_SPEED = 1; // Speed of the player
let oldPlayerPosition = null;

// We'll check for player existence when needed instead of at import time
function getPlayer() {
    return document.querySelector('[style*="background-color: blue"]');
}

function canMoveToBoundingBox(newX, newY, width, height) {
    // Define a smaller hitbox for the player
    const hitboxPercentage = 1;
    
    const hitboxWidth = width * hitboxPercentage;
    const hitboxHeight = height * hitboxPercentage;
    
    // Center the hitbox
    const offsetX = (width - hitboxWidth) / 2;
    const offsetY = (height - hitboxHeight) / 2;
    
    const startX = Math.floor((newX + offsetX) / GRID_SIZE);
    const startY = Math.floor((newY + offsetY) / GRID_SIZE);
    const endX = Math.floor((newX + offsetX + hitboxWidth - 1) / GRID_SIZE);
    const endY = Math.floor((newY + offsetY + hitboxHeight - 1) / GRID_SIZE);

    for (let y = startY; y <= endY; y++) {
        for (let x = startX; x <= endX; x++) {
            if (!canMoveTo(x, y)) {
                console.log("Collision detected at:", x, y);
                return false; // Collision detected
            }
        }
    }
    return true; // No collision
}

function canMoveTo(x, y) {
    // Check if the position is within bounds
    if (x < 0 || y < 0 || x >= MAP_WIDTH || y >= MAP_HEIGHT) {
        return false; // Out of bounds
    }

    // Check collision map for walls
    return !collisionMap[y][x];
}

function getMaxMoveXDistance(startX, startY, dx, width, height) {
    // If no movement, return 0
    if (dx === 0) return 0;
    
    // Normalize direction to get unit vector
    const length = Math.abs(dx);
    const dirX = dx / length;
    
    // Use a smaller step size for more precise collision detection
    const STEP_SIZE = 0.1; // Changed from 1 to 0.5 for more precise movement
    
    // Calculate how many steps we need to take
    const steps = Math.ceil(length / STEP_SIZE);
    
    // Check each step
    for (let i = 1; i <= steps; i++) {
        const distance = i * STEP_SIZE;
        const testX = startX + dirX * distance;
        
        // If this position causes a collision, return the previous safe distance
        if (!canMoveToBoundingBox(Math.floor(testX), startY, width, height)) {
            console.log("Collision detected at X:", testX, "rounded X:", Math.floor(testX));
            return (i - 1) * STEP_SIZE;
        }
    }
    
    // If no collision found, we can move the full distance
    return length;
}
function getMaxMoveYDistance(startX, startY, dy, width, height) {
    // If no movement, return 0
    if (dy === 0) return 0;
    
    // Normalize direction to get unit vector
    const length = Math.abs(dy);
    const dirY = dy / length;

    console.log("dirY", dirY);
    
    // Use a smaller step size for more precise collision detection
    const STEP_SIZE = 0.1; // Changed from 1 to 0.5 for more precise movement
    
    // Calculate how many steps we need to take
    const steps = Math.ceil(length / STEP_SIZE);

    console.log("steps", steps);
    
    // Check each step
    for (let i = 1; i <= steps; i++) {
        const distance = i * STEP_SIZE;
        const testY = startY + dirY * distance;
        
        // If this position causes a collision, return the previous safe distance
        if (!canMoveToBoundingBox(startX, Math.floor(testY), width, height)) {
            console.log("Collision detected at Y:", testY, "rounded Y:", Math.floor(testY));
            return (i - 1) * STEP_SIZE;
        }
    }
    
    // If no collision found, we can move the full distance
    return length;
}
// Updated updatePlayerPosition function with improved corner handling
export function updatePlayerPosition(deltatime) {
    const player = getPlayer();
    if (!player) return; // Exit if player not initialized yet

    // Initialize oldPlayerPosition if not already done
    if (!oldPlayerPosition) {
        oldPlayerPosition = {
            x: player.offsetLeft / GRID_SIZE,
            y: player.offsetTop / GRID_SIZE
        };
    }

    let dx = 0;
    let dy = 0;

    // Get terrain speed modifier for current position
    const gridX = Math.floor(player.offsetLeft / GRID_SIZE);
    const gridY = Math.floor(player.offsetTop / GRID_SIZE);
    
    if (gridX >= 0 && gridY >= 0 && gridX < MAP_WIDTH && gridY < MAP_HEIGHT && 
        terrainMap[gridY] && terrainMap[gridY][gridX]) {
        PLAYER_SPEED_MULTIPLIER_TERRAIN = TERRAIN_PROPERTIES[terrainMap[gridY][gridX]].speedMultiplier;
    } else {
        PLAYER_SPEED_MULTIPLIER_TERRAIN = 1.0;
    }

    // Calculate desired movement based on keys pressed
    if (!gamePaused) {
        if (keys["ArrowUp"]) {
            if (keys['ArrowLeft'] === true || keys['ArrowRight'] === true) {
                // Diagonal movement
                dy -= PLAYER_SPEED * deltatime * Math.sin(Math.PI / 4) * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            } else {
                // Straight movement
                dy -= PLAYER_SPEED * deltatime * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            }
        }
        if (keys["ArrowDown"]) {
            if (keys['ArrowLeft'] === true || keys['ArrowRight'] === true) {
                // Diagonal movement
                dy += PLAYER_SPEED * deltatime * Math.sin(Math.PI / 4) * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            } else {
                // Straight movement
                dy += PLAYER_SPEED * deltatime * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            }
        }
        if (keys["ArrowLeft"]) {
            if (keys['ArrowUp'] === true || keys['ArrowDown'] === true) {
                // Diagonal movement
                dx -= PLAYER_SPEED * deltatime * Math.cos(Math.PI / 4) * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            } else {
                // Straight movement
                dx -= PLAYER_SPEED * deltatime * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            }
        }
        if (keys["ArrowRight"]) {
            if (keys['ArrowUp'] === true || keys['ArrowDown'] === true) {
                // Diagonal movement
                dx += PLAYER_SPEED * deltatime * Math.cos(Math.PI / 4) * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            } else {
                // Straight movement
                dx += PLAYER_SPEED * deltatime * getPlayerSpeedMultiplier() * PLAYER_SPEED_MULTIPLIER_TERRAIN;
            }
        }
    }

    if (dx === 0 && dy === 0) {
        return; // No movement needed
    }

    
    // Get current position
    const currentX = player.offsetLeft;
    const currentY = player.offsetTop;
    
    // First, try the direct movement to see how far we can go
    let newX = currentX;
    let newY = currentY;

    // Check if we can move in X direction
    const maxXDistance = getMaxMoveXDistance(currentX, currentY, dx, player.offsetWidth, player.offsetHeight);
    if (maxXDistance > 1) {
        // We can move in X direction
        const moveRatioX = maxXDistance / Math.abs(dx);
        newX = currentX + dx * moveRatioX;
    }

    // Check if we can move in Y direction
    const maxYDistance = getMaxMoveYDistance(currentX, currentY, dy, player.offsetWidth, player.offsetHeight);
    if (maxYDistance > 1) {
        // We can move in Y direction
        const moveRatioY = maxYDistance / Math.abs(dy);
        newY = currentY + dy * moveRatioY;
    }

    
    // Apply boundary constraints
    const finalX = Math.max(0, Math.min(MAP_WIDTH * GRID_SIZE - player.offsetWidth, newX));
    const finalY = Math.max(0, Math.min(MAP_HEIGHT * GRID_SIZE - player.offsetHeight, newY));
    
    // Apply the final position directly to the player element
    player.style.left = `${finalX}px`;
    player.style.top = `${finalY}px`;

    // Sending position to the server
    const playerPosition = {
        x: (player.offsetLeft / GRID_SIZE),
        y: (player.offsetTop / GRID_SIZE)
    };

    if (playerPosition.x !== oldPlayerPosition.x || playerPosition.y !== oldPlayerPosition.y) {
        // Only send the new position if it has changed
        oldPlayerPosition = playerPosition;
        if (socket && socket.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({ type: "move", x: playerPosition.x, y: playerPosition.y }));
        }
    }
}