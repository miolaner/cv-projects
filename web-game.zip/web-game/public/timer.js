export function updateTimer(message) {
    // Listen for the timer update event from the server
    if (message.type !== "timer") return;
    const time = message.gameTime;
    // Update the timer display with the new time
    const timerElement = document.getElementById("timer");
    timerElement.textContent = `Time left: ${time}s`;

}
