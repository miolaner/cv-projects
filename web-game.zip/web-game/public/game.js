import { updateTimer } from "./timer.js";
import { MainHandleLoginScreen } from "./login.js";
import { updatePlayerPosition } from "./movement.js";
// This is only for the game container!!!
// Should thease come from the server? 
export const GRID_SIZE = 15; // Size of each grid cell
export const MAP_WIDTH = 50; // Number of cells in the width of the map
export const MAP_HEIGHT = 40; // Number of cells in the height of the map
export const PLAYER_SPEED_POWERUP = 2; // Speed of the player when powerup is active
export const PLAYER_SPEED_POWERUP_DURATION = 5000; // Duration of the speed powerup in milliseconds
export let PLAYER_SPEED_MULTIPLIER = 1;
export let terrainMap = []; // The terrain map
export let collisionMap = []; // The collision map
let activeSpeedPowerupTimer = null;
// Terrain propertiesß
export const TERRAIN_PROPERTIES = {
    'GRASS': { speedMultiplier: 1.0 },
    'MUD': { speedMultiplier: 0.8 },
    'WATER': { speedMultiplier: 0.6 },
    'WALL': { speedMultiplier: 1.0 }
};
export let gamePaused = false;

const FPS_BUFFER_SIZE = 60; // Store the last 60 frames (1 second at 60fps)
const fpsBuffer = new Array(FPS_BUFFER_SIZE).fill(60); // Initialize with 60 fps
let fpsBufferIndex = 0;

let output = [];
output.append

export function getPlayerSpeedMultiplier() {
    return PLAYER_SPEED_MULTIPLIER;
}

export function setPlayerSpeedMultiplier(value) {
    PLAYER_SPEED_MULTIPLIER = value;
}

// Initialize the layout structure if it doesn't exist yet
function initializeLayout() {
    // First check if our layout structure exists
    if (!document.querySelector('.game-layout')) {
        console.log("Creating game layout structure");
        
        // Get the game container
        const gameContainer = document.getElementById("game-container");
        const parentElement = gameContainer.parentElement;
        
        // Create the game layout wrapper
        const gameLayout = document.createElement("div");
        gameLayout.className = "game-layout";
        gameLayout.style.display = "none";
        
        // Create left sidebar
        const leftSidebar = document.createElement("div");
        leftSidebar.className = "left-sidebar";
        
        // Create right sidebar
        const rightSidebar = document.createElement("div");
        rightSidebar.className = "right-sidebar";
        
        // Get the HUD elements
        const fpsCounter = document.getElementById("fps-counter");
        const timer = document.getElementById("timer");
        const pointsContainer = document.getElementById("points-container");
        
        // Move the HUD elements to the left sidebar
        if (fpsCounter) parentElement.removeChild(fpsCounter);
        if (timer) parentElement.removeChild(timer);
        if (pointsContainer) parentElement.removeChild(pointsContainer);
        
        leftSidebar.appendChild(fpsCounter || createFPSCounter());
        leftSidebar.appendChild(timer || createTimer());
        leftSidebar.appendChild(pointsContainer || createPointsContainer());
        
        // Create the instructions container if it doesn't exist
        const instructionsContainer = document.getElementById("instructions-container") || createInstructionsContainer();
        rightSidebar.appendChild(instructionsContainer);
        
        // Remove the game container from its current parent
        parentElement.removeChild(gameContainer);
        
        // Add all elements to the layout wrapper
        gameLayout.appendChild(leftSidebar);
        gameLayout.appendChild(gameContainer);
        gameLayout.appendChild(rightSidebar);
        
        // Add the layout wrapper to the body
        parentElement.appendChild(gameLayout);
    }
}

// Helper functions to create elements if they don't exist
function createFPSCounter() {
    const fpsCounter = document.createElement("div");
    fpsCounter.id = "fps-counter";
    fpsCounter.innerHTML = 'FPS: <span id="fps">0</span>';
    return fpsCounter;
}

function createTimer() {
    const timer = document.createElement("div");
    timer.id = "timer";
    timer.innerHTML = '<span id="time">Time left: 0s</span>';
    return timer;
}

function createPointsContainer() {
    const pointsContainer = document.createElement("div");
    pointsContainer.id = "points-container";
    
    const heading = document.createElement("h3");
    heading.textContent = "Scoreboard";
    
    const pointsList = document.createElement("ul");
    pointsList.id = "points-list";
    
    pointsContainer.appendChild(heading);
    pointsContainer.appendChild(pointsList);
    
    return pointsContainer;
}


// Initialize the game
let gameContainer = document.getElementById("game-container");
gameContainer.style.display = "none"; // Hide initially
gameContainer.style.position = "relative"; // Make sure container uses relative positioning
gameContainer.style.width = `${GRID_SIZE * MAP_WIDTH}px`;
gameContainer.style.height = `${GRID_SIZE * MAP_HEIGHT}px`;
gameContainer.style.margin = "auto";

// Create HUD box next to the gameContainer
let hudBox = document.createElement("div");
hudBox.style.position = "absolute";
hudBox.style.top = "10px";
hudBox.style.right = "10px";
hudBox.style.backgroundColor = "rgba(255, 255, 255, 0.8)";
hudBox.style.padding = "10px";
hudBox.style.borderRadius = "5px";
hudBox.style.zIndex = "10"; // Ensure it's above the game grid
hudBox.style.display = "none"; // Hide initially
gameContainer.appendChild(hudBox);


// Load sounds
const audio = new Audio("sounds/loop-music2.mp3");
const audioCollectPowerup = new Audio("sounds/collect-powerup.mp3");
const audioCollectPoint = new Audio("sounds/collect-point.mp3");
const audioEnd = new Audio("sounds/game-over.mp3");
let soundsEnabled = true;

let gameEnded = false;

// Game loop variables
let lastTime = 0;
export let keys = {
    'ArrowUp': false,
    'ArrowDown': false,
    'ArrowLeft': false,
    'ArrowRight': false
};


// Create terrain layer first
let terrainLayer = document.createElement("div");
terrainLayer.style.width = "100%";
terrainLayer.style.height = "100%";
terrainLayer.style.display = "grid";
terrainLayer.style.gridTemplateColumns = `repeat(${MAP_WIDTH}, ${GRID_SIZE}px)`;
terrainLayer.style.gridTemplateRows = `repeat(${MAP_HEIGHT}, ${GRID_SIZE}px)`;
terrainLayer.style.position = "absolute";
terrainLayer.style.left = "0";
terrainLayer.style.top = "0";
terrainLayer.style.zIndex = "0";
gameContainer.appendChild(terrainLayer);

// Create terrain cells
let terrainCells = [];
for (let y = 0; y < MAP_HEIGHT; y++) {
    terrainCells[y] = [];
    for (let x = 0; x < MAP_WIDTH; x++) {
        const cell = document.createElement("div");
        cell.style.width = "100%";
        cell.style.height = "100%";
        cell.style.backgroundColor = "#90EE90"; // Default grass color
        cell.style.border = "1px solid rgba(0,0,0,0.2)";
        terrainLayer.appendChild(cell);
        terrainCells[y][x] = cell;
    }
}

// Create game grid on top of terrain
let gameGrid = document.createElement("div");
gameGrid.style.width = "100%";
gameGrid.style.height = "100%";
gameGrid.style.display = "grid";
gameGrid.style.gridTemplateColumns = `repeat(${MAP_WIDTH}, ${GRID_SIZE}px)`;
gameGrid.style.gridTemplateRows = `repeat(${MAP_HEIGHT}, ${GRID_SIZE}px)`;
gameGrid.style.position = "absolute";
gameGrid.style.left = "0";
gameGrid.style.top = "0";
gameGrid.style.backgroundColor = "transparent";
gameGrid.style.border = "2px solid rgba(100, 149, 237, 0.8)";
gameGrid.style.zIndex = "1";
gameContainer.appendChild(gameGrid);

let animationFrameId;
let players = [];

// Create the player with highest z-index
export let player = document.createElement("div");

function toggleHUD(switcher) {
    // Get the main game layout wrapper
    const gameLayout = document.querySelector('.game-layout');
    
    if (switcher) {
        // Show the game layout wrapper
        gameLayout.style.display = "flex";
        
        // Show the HUD elements
        document.getElementById("fps-counter").style.display = "block";
        document.getElementById("timer").style.display = "block";
        document.getElementById("points-container").style.display = "block";
        document.getElementById("instructions-container").style.display = "block";
    } else {
        // Hide the game layout wrapper and all HUD elements
        gameLayout.style.display = "none";
        document.getElementById("fps-counter").style.display = "none";
        document.getElementById("timer").style.display = "none";
        document.getElementById("points-container").style.display = "none";
        document.getElementById("instructions-container").style.display = "none";
    }
}


function createCollectEffect(x, y, type) {
    const effect = document.createElement("div");
    effect.style.position = "absolute";
    effect.style.width = `${GRID_SIZE * 2}px`;
    effect.style.height = `${GRID_SIZE * 2}px`;
    effect.style.left = `${x * GRID_SIZE - GRID_SIZE/2}px`;
    effect.style.top = `${y * GRID_SIZE - GRID_SIZE/2}px`;
    effect.style.borderRadius = "50%";
    
    if (type === "powerup" || type.includes("powerup")) {
        effect.style.background = "radial-gradient(circle, rgba(0,184,169,0.7) 0%, rgba(0,184,169,0) 70%)";
    } else {
        effect.style.background = "radial-gradient(circle, rgba(248,181,0,0.7) 0%, rgba(248,181,0,0) 70%)";
    }
    
    effect.style.zIndex = "5";
    effect.style.animation = "collect-effect 0.5s forwards";
    gameGrid.appendChild(effect);
    
    setTimeout(() => {
        if (effect.parentNode) {
            gameGrid.removeChild(effect);
        }
    }, 500);
}
// Handle pause menu
let pauseMenu = document.getElementById("pause-container");

// Websocket connection
const wsProtocol = window.location.protocol === "https:" ? "wss" : "ws";
const wsHost = window.location.host;
export const socket = new WebSocket(`${wsProtocol}://${wsHost}`);
socket.addEventListener("open", () => {
    console.log("Connected to WebSocket server")
});
socket.addEventListener("error", (event) => {console.error("WebSocket error: ", event)});
socket.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);

    // Update the timer if the message is of type 'timer'
    updateTimer(message);

    // Handle other message types
    switch (message.type) {
        case "lobbyInit":
            // What init does is not clear
            console.log("init called");
            player.id = message.clientId;

            if (message.terrainMap) {
                console.log("Initializing terrain map from lobby");
                updateTerrain(message.terrainMap);
            }

            console.log("Powerups: ", message.powerups);
            console.log("Points: ", message.points);
            populateGrid(message.powerups, message.points, message.players);
            break;
        case "playerJoined":
            // Why is this needed? There cant be any other players when the game starts
            console.log("Player joined");
            break;
        case "stateUpdate":
            // STILL NEEDS TO NOT CREATE A NEW PLAYER ELEMENT FOR HOST PLAYER!!
            //console.log("State update: ", message.players);
            for (const id in message.players) {
                const playerData = message.players[id];
                const playerElement = document.getElementById(id);
                // Update the position of the player elements, if not create a new one
                if (playerElement) {
                    playerElement.style.left = `${playerData.x * GRID_SIZE}px`;
                    playerElement.style.top = `${playerData.y * GRID_SIZE}px`;
                } else {   
                    console.log(id);
                    if (id === player.id) {
                        // Skip creating a new element for the host player
                        continue;
                    }
                    // Create a new player element if it doesn't exist
                    const newPlayerElement = document.createElement("div");
                    newPlayerElement.id = id;
                    newPlayerElement.style.width = `${GRID_SIZE}px`;
                    newPlayerElement.style.height = `${GRID_SIZE}px`;
                    newPlayerElement.style.backgroundColor = "red";
                    newPlayerElement.style.position = "absolute";
                    newPlayerElement.style.left = `${playerData.x * GRID_SIZE}px`;
                    newPlayerElement.style.top = `${playerData.y * GRID_SIZE}px`;
                    gameGrid.appendChild(newPlayerElement);
                }
            }
            break;
        case "pauseState":
            // This toggles the pause state of the game
            console.log("Toggle pause");
            console.log(message);
            pauseResumeGame(message.gamePaused, message.pausedBy);
            break;
        case "playerLeft":
            // Is this needed?
            console.log("Player left");
            const playerElement = document.getElementById(message.id);
            if (playerElement) {
                gameGrid.removeChild(playerElement);
            }
            break;
        case "collectPowerup":
            // Handle powerup collection
            console.log("Powerup collected");
            const powerupElement = document.getElementById(message.id);
            if (powerupElement) {
                gameGrid.removeChild(powerupElement);
            }
            break;
        case "collectPoint":
            // Handle point collection
            console.log("Point collected");
            const pointElement = document.getElementById(message.id);
            if (pointElement) {
                gameGrid.removeChild(pointElement);
            }
            updatePointsCounter(message)
            break;
        case "gameStart":
            initializeLayout();
            terrainMap = message.terrainMap;
            audio.loop = true;
            audio.volume = 1;
            audio.play().catch((error) => {
                console.error("Error playing audio:", error);
            });
            console.log("Audio started");
        
            // Show the HUD elements
            toggleHUD(true);
            
            // Handle game start
            console.log("Game started!");
            
            // Hide the login screen
            const loginContainer = document.getElementById("login-container");
            loginContainer.style.display = "none";
            
            // Show the game container
            gameContainer.style.display = "block";
            
            // Update terrain first
            if (message.terrainMap) {
                console.log("Initializing terrain map");
                updateTerrain(message.terrainMap);
            }
            
            // populate the grid with powerups, points and players
            populateGrid(message.powerups, message.points, message.players);
            
            // Make the points list
            createPointsList(message.players);
            players = message.players;
            
            // Start the game loop
            animationFrameId = requestAnimationFrame(gameLoop);
            break;
        case "gameEnd":
            // Stop audio loop
            audioEnd.play().catch((error) => {
                console.error("Error playing audio:", error);
            });
        
            gameEnded = true;
        
            console.log("Game ended");
            toggleHUD(false);
            
            // Show the game over screen
            const gameOverContainer = document.getElementById("game-over-container");
            gameOverContainer.style.display = "flex";
            gameContainer.style.display = "none";
            
            // Create a scoreboard and determine the winner
            const existingScoreBoard = document.getElementById("score-board");
            if (existingScoreBoard) {
                existingScoreBoard.remove(); // Remove the existing scoreboard
            }
            const scoreBoard = document.createElement("div");
            scoreBoard.id = "score-board";
            
            // Sort players by score to determine the winner
            const playerScores = Object.values(message.players).sort((a, b) => b.score - a.score);
            const winner = playerScores[0];
            
            // Create winner announcement
            const winnerAnnouncement = document.createElement("h2");
            winnerAnnouncement.textContent = `Winner: ${winner.name} with ${winner.score} points!`;
            winnerAnnouncement.classList.add("winner-text");
            scoreBoard.appendChild(winnerAnnouncement);
            
            // Create the scores list
            const scoresList = document.createElement("ul");
            scoresList.id = "final-scores";
            
            playerScores.forEach((player, index) => {
                const playerItem = document.createElement("li");
                
                // Create name and score spans for better styling
                const nameSpan = document.createElement("span");
                nameSpan.className = "player-name";
                nameSpan.textContent = `${index + 1}. ${player.name}`;
                
                const scoreSpan = document.createElement("span");
                scoreSpan.className = "player-score";
                scoreSpan.textContent = player.score;
                
                playerItem.appendChild(nameSpan);
                playerItem.appendChild(scoreSpan);
                
                // Highlight the winner
                if (index === 0) {
                    playerItem.classList.add("winner");
                }
                scoresList.appendChild(playerItem);
            });
            
            scoreBoard.appendChild(scoresList);
            gameOverContainer.appendChild(scoreBoard);
            
            const gameOverButton = document.getElementById("game-over-exit-button");
            gameOverButton.addEventListener("click", () => {
                // Reload the page
                window.location.reload();
            });
            const resetButton = document.getElementById("game-over-restart-button");
            resetButton.addEventListener("click", () => {
                // Restart the game
                console.log("Restart button clicked");
                socket.send(JSON.stringify({ type: "restartGame" }));
            });
            break;
        case "gameRestart":
            console.log("Game restarted");
            cancelAnimationFrame(animationFrameId);

            // Hide the game over screen
            const gameOverScreen = document.getElementById("game-over-container");
            gameOverScreen.style.display = "none";
            const pauseScreen = document.getElementById("pause-container");
            pauseScreen.style.display = "none";
            gamePaused = false;
            gameEnded = false;

            // Show HUD
            toggleHUD(true);
            
            // Reset the game container
            gameContainer.style.display = "none";
            gameGrid.innerHTML = ""; // Clear the grid
            //terrainLayer.innerHTML = ""; // Clear the terrain layer

            // Handle game start
            console.log("Game restarted!");
            // Show the game container
            gameContainer.style.display = "flex";
            // Update terrain first
            if (message.terrainMap) {
                console.log("Initializing terrain map");
                updateTerrain(message.terrainMap);
            }

            // populate the grid with powerups, points and players
            populateGrid(message.powerups, message.points, message.players);
            // Make the points list
            createPointsList(message.players);
            players = message.players;
            // Start the game loop
            animationFrameId = requestAnimationFrame(gameLoop);

            break;

        case "pointRespawn":
            // Handle point respawn
            console.log("Point respawned");
            const newPoint = document.createElement("div");
            newPoint.id = message.point.id;
            newPoint.style.width = `${GRID_SIZE}px`;
            newPoint.style.height = `${GRID_SIZE}px`;
            newPoint.style.backgroundColor = "yellow";
            newPoint.style.position = "absolute";
            newPoint.style.top = `${message.point.y * GRID_SIZE}px`;
            newPoint.style.left = `${message.point.x * GRID_SIZE}px`;
            newPoint.classList.add("point");
            gameGrid.appendChild(newPoint);
            break;
        case "playerLeftRoom":
            // Handle player leaving the room
            console.log("Player left room");
            const playerLeftElement = document.getElementById(message.playerId);
            if (playerLeftElement) {
                gameGrid.removeChild(playerLeftElement);
            }
            // Remove player from the points list
            const playerListElement = document.getElementById(`list-${message.playerId}`);
            if (playerListElement) {
                playerListElement.remove();
            }
            const playerName = players[message.playerId] ? players[message.playerId].name : "Unknown Player";
            // Remove player from the players object
            delete players[message.playerId];
            // Update the points list
            const pointsList = document.getElementById("points-list");
            if (pointsList) {
                const playerItem = document.getElementById(`list-${message.playerId}`);
                if (playerItem) {
                    pointsList.removeChild(playerItem);
                }
            }

            // Display a message to all players
            const messageElement = document.createElement("div");
            messageElement.className = "player-left-message";
            messageElement.innerText = `${playerName} has left the game.`;
            gameGrid.appendChild(messageElement);
            setTimeout(() => {
                if (messageElement.parentNode) {
                    gameGrid.removeChild(messageElement);
                }
            }, 3000); // Remove the message after 3 seconds


            break;
                
        }

});

function updatePointsCounter(data) {
    console.log("Update points counter: ", data);
    const playerElement = document.getElementById(`list-${data.playerId}`);
    if (playerElement) {
        const scoreSpan = playerElement.querySelector(".player-score");
        if (scoreSpan) {
            scoreSpan.textContent = data.score;
        } else {
            playerElement.innerHTML = ""; // Clear existing content
            
            const nameSpan = document.createElement("span");
            nameSpan.className = "player-name";
            nameSpan.textContent = players[data.playerId].name;
            
            const scoreSpan = document.createElement("span");
            scoreSpan.className = "player-score";
            scoreSpan.textContent = data.score;
            
            playerElement.appendChild(nameSpan);
            playerElement.appendChild(scoreSpan);
        }
    }
}

socket.addEventListener("close", (event) => {
    console.log("WebSocket connection closed");
}
);
socket.addEventListener("error", (event) => {
    console.error("WebSocket error: ", event);
}
);

// Create points list of all players
function createPointsList(players) {
    // Check if the list already exists
    const existingList = document.getElementById("points-list");
    if (existingList) {
        existingList.innerHTML = ""; // Clear the existing list
    }
    
    const pointsList = existingList || document.createElement("ul");
    pointsList.id = "points-list";
    
    // Get the current player's ID to highlight them
    const currentPlayerId = player.id;
    
    for (const id in players) {
        const playerData = players[id];
        const playerElement = document.createElement("li");
        playerElement.id = `list-${id}`;
        
        // Check if this is the current player to add special styling
        if (id === currentPlayerId) {
            playerElement.classList.add("host-player");
        }
        
        // Create name and score spans for better styling
        const nameSpan = document.createElement("span");
        nameSpan.className = "player-name";
        nameSpan.textContent = playerData.name;
        
        const scoreSpan = document.createElement("span");
        scoreSpan.className = "player-score";
        scoreSpan.textContent = playerData.score;
        
        playerElement.appendChild(nameSpan);
        playerElement.appendChild(scoreSpan);
        
        pointsList.appendChild(playerElement);
    }
    
    if (!existingList) {
        const pointsContainer = document.getElementById("points-container");
        pointsContainer.appendChild(pointsList);
    }
}

// Populate the game grid with powerups, points and players
function populateGrid(powerups, points, players) {

    //console.log("Length of powerups: ", powerups.length);

    // Create powerups
    for (let i = 0; i < powerups.length; i++) {
        console.log("Powerup: ", powerups[i]);
        const powerup = document.createElement("div");
        powerup.id = powerups[i].id;
        powerup.style.width = `${GRID_SIZE}px`;
        powerup.style.height = `${GRID_SIZE}px`;
        if (powerups[i].type === "speed") {
            powerup.style.backgroundColor = "green";
        } else if (powerups[i].type === "pointMultiplier") {
            powerup.style.backgroundColor = "orange";  
        }
        //powerup.style.backgroundColor = "green";
        powerup.style.position = "absolute";
        powerup.style.top = `${powerups[i].y * GRID_SIZE}px`;
        powerup.style.left = `${powerups[i].x * GRID_SIZE}px`;
        powerup.classList.add("powerup");
        powerup.type = powerups[i].type;
        gameGrid.appendChild(powerup);
    }
    // Create points
    for (let i = 0; i < points.length; i++) {
        const point = document.createElement("div");
        point.id = points[i].id;
        point.style.width = `${GRID_SIZE}px`;
        point.style.height = `${GRID_SIZE}px`;
        point.style.backgroundColor = "yellow";
        point.style.position = "absolute";
        point.style.top = `${points[i].y * GRID_SIZE}px`;
        point.style.left = `${points[i].x * GRID_SIZE}px`;
        point.classList.add("point");
        gameGrid.appendChild(point);
    }
    // Create players
    for (const id in players) {
        const playerData = players[id];
        if (id === player.id) {
            // Skip creating a new element for the host player
            player.style.width = `${GRID_SIZE}px`;
            player.style.height = `${GRID_SIZE}px`;
            player.style.backgroundColor = "blue";
            player.style.position = "absolute";
            player.style.top = `${playerData.y * GRID_SIZE}px`;
            player.style.left = `${playerData.x * GRID_SIZE}px`;
            player.style.transition = "all 0.1s ease-out";
            player.style.zIndex = "2";
            gameGrid.appendChild(player);
            continue;
        }
        const newPlayerElement = document.createElement("div");
        newPlayerElement.id = id;
        newPlayerElement.style.width = `${GRID_SIZE}px`;
        newPlayerElement.style.height = `${GRID_SIZE}px`;
        newPlayerElement.style.backgroundColor = "red";
        newPlayerElement.style.position = "absolute";
        newPlayerElement.style.left = `${playerData.x * GRID_SIZE}px`;
        newPlayerElement.style.top = `${playerData.y * GRID_SIZE}px`;
        gameGrid.appendChild(newPlayerElement);
    }
}

function checkCollisions() {
    // Check for collisions with powerups
    const powerups = document.querySelectorAll(".powerup");
    powerups.forEach((powerup) => {
        const powerupRect = powerup.getBoundingClientRect();
        const playerRect = player.getBoundingClientRect();
        if (
            playerRect.x < powerupRect.x + powerupRect.width &&
            playerRect.x + playerRect.width > powerupRect.x &&
            playerRect.y < powerupRect.y + powerupRect.height &&
            playerRect.y + playerRect.height > powerupRect.y
        ) {
            // Collision detected
            console.log("Collided with powerup");

            console.log("Powerup: ", powerup);
            // Check if the powerup is a speed powerup
            if (powerup.type === "speed") {
                PLAYER_SPEED_MULTIPLIER = PLAYER_SPEED_POWERUP;

                // Clear existing timer if there is one
                if (activeSpeedPowerupTimer) {
                    clearTimeout(activeSpeedPowerupTimer);
                    console.log("Cleared existing powerup timer");
                }
                
                // Set a new timer to reset the speed multiplier after the duration
                activeSpeedPowerupTimer = setTimeout(() => {
                    PLAYER_SPEED_MULTIPLIER = 1;
                    activeSpeedPowerupTimer = null;
                    console.log("Powerup effect ended");
                }, PLAYER_SPEED_POWERUP_DURATION);
                
                console.log("Powerup timer started: " + PLAYER_SPEED_POWERUP_DURATION + "ms");
            }
            
            // Play sound effect
            audioCollectPowerup.play();
            // Remove the powerup from the grid
            gameGrid.removeChild(powerup);
            // Send the powerup collection to the server
            socket.send(JSON.stringify({ type: "collectPowerup", id: powerup.id, userId: player.id }));
            const powerupX = parseInt(powerup.style.left) / GRID_SIZE;
            const powerupY = parseInt(powerup.style.top) / GRID_SIZE;
            createCollectEffect(powerupX, powerupY, "powerup");
        }
    });
    
    // Rest of collision code unchanged
    // Check for collisions with points
    const points = document.querySelectorAll(".point");
    points.forEach((point) => {
        const pointRect = point.getBoundingClientRect();
        const playerRect = player.getBoundingClientRect();
        if (
            playerRect.x < pointRect.x + pointRect.width &&
            playerRect.x + playerRect.width > pointRect.x &&
            playerRect.y < pointRect.y + pointRect.height &&
            playerRect.y + playerRect.height > pointRect.y
        ) {
            // Collision detected
            console.log("Collided with point");
            audioCollectPoint.play();
            // Remove the point from the grid
            gameGrid.removeChild(point);
            // Send the point collection to the server
            socket.send(JSON.stringify({ type: "collectPoint", id: point.id, userId: player.id }));
            const pointX = parseInt(point.style.left) / GRID_SIZE;
            const pointY = parseInt(point.style.top) / GRID_SIZE;
            createCollectEffect(pointX, pointY, "point");
        }
    });
}


// Event listeners for keydowns and keyups
document.addEventListener("keydown", (event) => {
    keys[event.key] = true;
});
document.addEventListener("keyup", (event) => {
    keys[event.key] = false;
    if (event.key === "p" || event.key === "P") {
        if (gameEnded) {
            return;
        }
        socket.send(JSON.stringify({ type: "togglePause" }));
    }
});


function pauseResumeGame(status, pausedBy) {
    // Pause the game
    console.log("Pause status:", status);
    
    if (status === true) {
        console.log("Game paused");
        gamePaused = true;
        pauseMenu.style.display = "flex";
        document.getElementById("paused-by").textContent = `Paused by: ${pausedBy || "Server"}`;
        const resumeButton = document.getElementById("resume-button");
        const exitButton = document.getElementById("exit-button");
        const restartButton = document.getElementById("restart-button");
        resumeButton.replaceWith(resumeButton.cloneNode(true));
        exitButton.replaceWith(exitButton.cloneNode(true));
        restartButton.replaceWith(restartButton.cloneNode(true));

        document.getElementById("resume-button").addEventListener("click", () => {
            console.log("Resume button clicked");
            socket.send(JSON.stringify({ type: "togglePause" }));
            pauseMenu.style.display = "none";
        });
        
        document.getElementById("exit-button").addEventListener("click", () => {
            // Exit the game
            console.log("Exit button clicked");
            // Reload for the time being.. 
            window.location.reload();
        });

        document.getElementById("restart-button").addEventListener("click", () => {
            // Restart the game
            console.log("Restart button clicked");
            socket.send(JSON.stringify({ type: "restartGame" }));
        });

        document.getElementById("sounds-off").addEventListener("click", () => {
            // Toggle sound
            soundsEnabled = !soundsEnabled;
            if (soundsEnabled) {
                audio.volume = 1;
                audioCollectPowerup.volume = 1;
                audioCollectPoint.volume = 1;
                audioEnd.volume = 1;
                document.getElementById("sounds-off").innerText = "Sounds: ON";
            } else {
                audio.volume = 0;
                audioCollectPowerup.volume = 0;
                audioCollectPoint.volume = 0;
                audioEnd.volume = 0;
                document.getElementById("sounds-off").innerText = "Sounds: OFF";
            }
        });
        console.log("Game loop stopped");
        cancelAnimationFrame(animationFrameId);
    } else {

        console.log("Game resumed");
        gamePaused = false;
        pauseMenu.style.display = "none";
        animationFrameId = requestAnimationFrame(gameLoop);
    }
}

// Last time for FPS calculation
let lastframeTime = performance.now();

function updateFPSCounter() {
    const currentTime = performance.now();
    const deltaTime = currentTime - lastframeTime;
    lastframeTime = currentTime;
    
    // Calculate current FPS and add to buffer
    const currentFps = deltaTime > 0 ? 1000 / deltaTime : 60;
    fpsBuffer[fpsBufferIndex] = currentFps;
    
    // Move to next position in circular buffer
    fpsBufferIndex = (fpsBufferIndex + 1) % FPS_BUFFER_SIZE;
    
    // Only update display every 10 frames to reduce DOM updates
    if (fpsBufferIndex % 10 === 0) {
        // Calculate average FPS from buffer
        const avgFps = Math.round(
            fpsBuffer.reduce((sum, fps) => sum + fps, 0) / FPS_BUFFER_SIZE
        );
        
        // Update the FPS counter element
        const fpsElement = document.getElementById("fps");
        if (fpsElement) {
            fpsElement.textContent = avgFps;
        }
    }
}

// Get the initial player position
// This is the position of the player when the game start

// Game loop
// This function is called EVERY frame
function gameLoop(timeStamp) {
    // Get the delta time of the last frame
    const deltaTime = Math.min(timeStamp - lastTime, 1000 / 60);
    lastTime = timeStamp;

    // Update player position
    updatePlayerPosition(deltaTime)
    checkCollisions();
    updateFPSCounter();
    
    animationFrameId = requestAnimationFrame(gameLoop);
}

// Make it first show the login screen
MainHandleLoginScreen();

// Function to update terrain visualization
function updateTerrain(terrainMap) {
    console.log("[DEBUG] Updating terrain map");
    if (!terrainMap || !Array.isArray(terrainMap)) {
        console.error("Invalid terrain map received:", terrainMap);
        return;
    }

    // Log a sample of the terrain data
    console.log("[DEBUG] First row of terrain:", terrainMap[0]);
    console.log("[DEBUG] Sample cell value:", terrainMap[0][0]);

    for (let y = 0; y < terrainMap.length; y++) {
        if (!collisionMap[y]) {
            collisionMap[y] = [];
        }
        for (let x = 0; x < terrainMap[y].length; x++) {
            const terrainType = terrainMap[y][x];
            const cell = terrainCells[y][x];
            if (cell) {
                // Remove any existing terrain classes and inline styles
                cell.className = '';
                cell.style.backgroundColor = '';
                
                // Add appropriate terrain class
                switch(terrainType) {
                    case 'GRASS':
                        cell.className = 'terrain-grass';
                        break;
                    case 'WATER':
                        cell.className = 'terrain-water';
                        break;
                    case 'MUD':
                        cell.className = 'terrain-mud';
                        break;
                    case 'WALL':
                        // Populate collision map
                        collisionMap[y][x] = true;
                        cell.className = 'terrain-wall';
                        break;
                    default:
                        cell.className = 'terrain-grass';
                }
                
                cell.style.border = "1px solid rgba(0,0,0,0.2)";
                
                // Debug output for first few cells
                if (y < 2 && x < 2) {
                    console.log(`[DEBUG] Cell [${x},${y}] type:`, terrainType);
                }
            }
        }
    }
    console.log("[DEBUG] Terrain update complete");
}


// Make sure layers are in correct order
gameGrid.style.zIndex = "1";
gameGrid.style.backgroundColor = "transparent";
gameGrid.style.border = "2px solid rgba(100, 149, 237, 0.8)"; // Cornflower blue border
player.style.zIndex = "2";