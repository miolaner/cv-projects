# Movement System Documentation

## Terrain Types and Effects

| Terrain | Speed Multiplier | Effect |
|---------|-----------------|---------|
| GRASS   | 1.0 | Normal movement speed |
| MUD     | 0.8 | 20% slower movement |
| WATER   | 0.6 | 40% slower movement |
| WALL    | 0.0 | Blocks movement |

## Map Structure
- Map size: 50x40 grid
- Each cell is one terrain type
- Walls and boundaries block movement
- Collision map provided for quick wall checks

## Helper Functions

### Get Current Terrain
```javascript
function getTerrainAt(x, y) {
    return terrainMap[y][x];
}
```

### Get Speed Multiplier
```javascript
function getSpeedMultiplierAt(x, y) {
    const terrain = getTerrainAt(x, y);
    return TERRAIN_PROPERTIES[terrain].speedMultiplier;
}
```

### Check Movement Possibility
```javascript
function canMoveTo(x, y) {
    // Check map bounds
    if (x < 0 || x >= MAP_WIDTH || y < 0 || y >= MAP_HEIGHT) {
        return false;
    }
    // Check collision map for walls
    return !collisionMap[y][x];
}
```

### Calculate Movement
```javascript
function calculateActualMovement(startX, startY, targetX, targetY, baseSpeed) {
    const multiplier = getSpeedMultiplierAt(startX, startY);
    const actualSpeed = baseSpeed * multiplier;
    
    const dx = targetX - startX;
    const dy = targetY - startY;
    
    return {
        x: startX + (dx * actualSpeed),
        y: startY + (dy * actualSpeed)
    };
}
```

## Implementation Notes

1. Movement speed is affected by the terrain the player is currently on
2. Walls and map boundaries completely block movement
3. Use collision map for efficient wall checks
4. Apply terrain multiplier to base movement speed 