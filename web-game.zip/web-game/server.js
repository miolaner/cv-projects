const WebSocket = require('ws');
const express = require('express');
const http = require('http');
const path = require('path');
const os = require('os');
const { v4: uuidv4 } = require('uuid');

// ==== Map Configuration ====
const MAP_WIDTH = 50;
const MAP_HEIGHT = 40;

const FIXED_SPAWN_POINTS = [
    { x: 5, y: 5 },
    { x: MAP_WIDTH - 6, y: 5 },
    { x: 5, y: MAP_HEIGHT - 6 },
    { x: MAP_WIDTH - 6, y: MAP_HEIGHT - 6 }
];

// Add collision map
const collisionMap = Array(MAP_HEIGHT).fill().map(() => 
    Array(MAP_WIDTH).fill(false)
);

const TERRAIN_TYPES = {
    GRASS: 'GRASS',
    MUD: 'MUD',
    WATER: 'WATER',
    WALL: 'WALL'
};

const TERRAIN_PROPERTIES = {
    [TERRAIN_TYPES.GRASS]: {
        color: '#90EE90',  // Light green
        speedMultiplier: 1.0
    },
    [TERRAIN_TYPES.MUD]: {
        color: '#8B4513',  // Saddle brown
        speedMultiplier: 0.8
    },
    [TERRAIN_TYPES.WATER]: {
        color: '#4169E1',  // Royal blue
        speedMultiplier: 0.6
    },
    [TERRAIN_TYPES.WALL]: {
        color: '#808080',  // Gray
        speedMultiplier: 0.0  // Cannot move through walls
    }
};
const POWERUP_TYPES = {
    SPEED: 'speed',
    POINT_MULTIPLIER: 'pointMultiplier'
};
const POWERUP_DURATIONS = {
    [POWERUP_TYPES.SPEED]: 10, // 10 seconds
    [POWERUP_TYPES.POINT_MULTIPLIER]: 15 // 15 seconds
};
// Initialize collision map with walls
function initializeCollisionMap(wallPositions) {
    // Reset collision map
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            collisionMap[y][x] = false;
        }
    }

    // Add map boundaries
    for (let x = 0; x < MAP_WIDTH; x++) {
        collisionMap[0][x] = true;              // Top boundary
        collisionMap[MAP_HEIGHT-1][x] = true;   // Bottom boundary
    }
    for (let y = 0; y < MAP_HEIGHT; y++) {
        collisionMap[y][0] = true;              // Left boundary
        collisionMap[y][MAP_WIDTH-1] = true;    // Right boundary
    }

    // Add walls to collision map
    wallPositions.forEach(wall => {
        if (wall.vertical) {
            for (let y = wall.y; y < wall.y + wall.length; y++) {
                if (y >= 0 && y < MAP_HEIGHT) {
                    collisionMap[y][wall.x] = true;
                }
            }
        } else {
            for (let x = wall.x; x < wall.x + wall.length; x++) {
                if (x >= 0 && x < MAP_WIDTH) {
                    collisionMap[wall.y][x] = true;
                }
            }
        }
    });
}

function generateMap() {
    // Initialize map with grass
    const map = Array(MAP_HEIGHT).fill().map(() => 
        Array(MAP_WIDTH).fill(TERRAIN_TYPES.GRASS)
    );

    // Add mud in corners
    const corners = [
        {x: 0, y: 0, width: 8, height: 7},      // Top-left
        {x: MAP_WIDTH - 8, y: 0, width: 8, height: 7},     // Top-right
        {x: 0, y: MAP_HEIGHT - 7, width: 8, height: 7},    // Bottom-left
        {x: MAP_WIDTH - 8, y: MAP_HEIGHT - 7, width: 8, height: 7}  // Bottom-right
    ];

    corners.forEach(corner => {
        for (let y = corner.y; y < corner.y + corner.height; y++) {
            for (let x = corner.x; x < corner.x + corner.width; x++) {
                if (x >= 0 && x < MAP_WIDTH && y >= 0 && y < MAP_HEIGHT) {
                    
                    const distanceFromCorner = Math.sqrt(
                        Math.pow(x - (corner.x + corner.width/2), 2) + 
                        Math.pow(y - (corner.y + corner.height/2), 2)
                    );
                    
                    
                    const maxDistance = Math.min(corner.width, corner.height) * 0.8;
                    if (distanceFromCorner <= maxDistance || Math.random() < 0.7) {
                        map[y][x] = TERRAIN_TYPES.MUD;
                    }
                }
            }
        }
    });

    // Add central water pond and mud ring
    const centerX = Math.floor(MAP_WIDTH / 2);
    const centerY = Math.floor(MAP_HEIGHT / 2);
    const waterSize = 5;
    const mudRingSize = 7;

    // Add mud ring first
    for (let y = centerY - mudRingSize; y <= centerY + mudRingSize; y++) {
        for (let x = centerX - mudRingSize; x <= centerX + mudRingSize; x++) {
            if (x >= 0 && x < MAP_WIDTH && y >= 0 && y < MAP_HEIGHT) {
                const distanceFromCenter = Math.sqrt(
                    Math.pow(x - centerX, 2) + 
                    Math.pow(y - centerY, 2)
                );
                if (distanceFromCenter <= mudRingSize) {
                    map[y][x] = TERRAIN_TYPES.MUD;
                }
            }
        }
    }

    // Add water pond on top
    for (let y = centerY - waterSize; y <= centerY + waterSize; y++) {
        for (let x = centerX - waterSize; x <= centerX + waterSize; x++) {
            if (x >= 0 && x < MAP_WIDTH && y >= 0 && y < MAP_HEIGHT) {
                const distanceFromCenter = Math.sqrt(
                    Math.pow(x - centerX, 2) + 
                    Math.pow(y - centerY, 2)
                );
                if (distanceFromCenter <= waterSize) {
                    map[y][x] = TERRAIN_TYPES.WATER;
                }
            }
        }
    }

    // Add walls
    const wallPositions = [
        // Left side walls
        {x: 10, y: 5, length: 5, vertical: true},
        {x: 10, y: MAP_HEIGHT - 10, length: 5, vertical: true},
        
        // Right side walls
        {x: MAP_WIDTH - 11, y: 5, length: 5, vertical: true},
        {x: MAP_WIDTH - 11, y: MAP_HEIGHT - 10, length: 5, vertical: true},
        
        // Center vertical wall in water area
        {x: centerX, y: centerY - waterSize + 1, length: waterSize * 2 - 1, vertical: true},
        
        // Center area walls - outer barriers
        {x: centerX - 2, y: centerY - mudRingSize - 1, length: 5, vertical: false},
        {x: centerX - 2, y: centerY + mudRingSize + 1, length: 5, vertical: false},
        
        // Mid-section diagonal-like walls (made with small segments)
        {x: 20, y: 15, length: 4, vertical: true},
        
        
        {x: MAP_WIDTH - 20, y: 15, length: 4, vertical: true},
        
        
        // Bottom mid-section walls
        {x: 20, y: MAP_HEIGHT - 18, length: 4, vertical: true},
        
        
        {x: MAP_WIDTH - 20, y: MAP_HEIGHT - 18, length: 4, vertical: true},
        
        
        // Horizontal barriers between corners and center
        {x: 15, y: Math.floor(MAP_HEIGHT/4), length: 6, vertical: false},
        {x: MAP_WIDTH - 20, y: Math.floor(MAP_HEIGHT/4), length: 6, vertical: false},
        {x: 15, y: Math.floor(3*MAP_HEIGHT/4), length: 6, vertical: false},
        {x: MAP_WIDTH - 20, y: Math.floor(3*MAP_HEIGHT/4), length: 6, vertical: false}
    ];

    // Initialize collision map with these walls
    initializeCollisionMap(wallPositions);

    // Place walls on terrain map
    wallPositions.forEach(wall => {
        if (wall.vertical) {
            for (let y = wall.y; y < wall.y + wall.length; y++) {
                if (y >= 0 && y < MAP_HEIGHT) {
                    map[y][wall.x] = TERRAIN_TYPES.WALL;
                }
            }
        } else {
            for (let x = wall.x; x < wall.x + wall.length; x++) {
                if (x >= 0 && x < MAP_WIDTH) {
                    map[wall.y][x] = TERRAIN_TYPES.WALL;
                }
            }
        }
    });

    return map;
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// ==== Game State ====
// Store multiple game rooms
const gameRooms = {};

// ==== Utils ====
function getLocalIpAddress() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return '127.0.0.1';
}

function broadcastToRoom(roomId, data) {
    const msg = JSON.stringify(data);
    const room = gameRooms[roomId];
    
    if (!room) return;

    Object.values(room.playerConnections).forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(msg);
        }
    });
}

function rand(n) {
    return Math.floor(Math.random() * n);
}

function generateMapObjects() {
    const terrainMap = generateMap();
    const powerups = [];
    const points = [];
    
    // Helper function to find valid spawn position
    function findValidPosition() {
        let x, y;
        let attempts = 0;
        const maxAttempts = 50; // Prevent infinite loop

        do {
            x = rand(MAP_WIDTH);
            y = rand(MAP_HEIGHT);
            attempts++;
        } while (terrainMap[y][x] === TERRAIN_TYPES.WALL && attempts < maxAttempts);

        return { x, y };
    }
    
    // Generate 10 powerups in valid positions with different types
    for (let i = 0; i < 10; i++) {
        const pos = findValidPosition();
        const powerupType = i < 6 ? POWERUP_TYPES.SPEED : POWERUP_TYPES.POINT_MULTIPLIER;
        
        powerups.push({ 
            id: uuidv4(), 
            x: pos.x, 
            y: pos.y, 
            type: powerupType
        });
    }

    // Generate 10 points in valid positions
    for (let i = 0; i < 10; i++) {
        const pos = findValidPosition();
        points.push({ 
            id: uuidv4(), 
            x: pos.x, 
            y: pos.y 
        });
    }
    
    return { terrainMap, collisionMap, powerups, points };
}

function createGameRoom(creatorId, creatorName) {
    const roomId = uuidv4().slice(0, 6); // Short room code
    const { terrainMap, powerups, points } = generateMapObjects();
    
    gameRooms[roomId] = {
        id: roomId,
        creatorId: creatorId,
        players: {},
        terrainMap: terrainMap,
        powerups: powerups,
        points: points,
        gameTime: 300,
        gamePaused: false,
        gameStarted: false,
        playerConnections: {},
        timerInterval: null
    };
    
    gameRooms[roomId].players[creatorId] = {
        ...FIXED_SPAWN_POINTS[0],
        score: 0,
        name: creatorName,
        isCreator: true,
        activePowerups: {} // Add this line
    };
    
    console.log(`[ROOM] Created game room ${roomId} by ${creatorName} (${creatorId})`);
    
    return {
        roomId,
        terrainMap,
        powerups,
        points,
        players: gameRooms[roomId].players
    };
}
function schedulePointRespawn(roomId) {
    const room = gameRooms[roomId];
    if (!room) return;
    
    // Schedule respawn after 15 seconds
    setTimeout(() => {
        if (!room || !gameRooms[roomId]) return; // Room might have been deleted
        
        // Only respawn if we have less than 10 points
        if (room.points.length < 10) {
            // Helper function to find valid spawn position
            function findValidPosition() {
                let x, y;
                let attempts = 0;
                const maxAttempts = 50; // Prevent infinite loop

                do {
                    x = rand(MAP_WIDTH);
                    y = rand(MAP_HEIGHT);
                    attempts++;
                } while (room.terrainMap[y][x] === TERRAIN_TYPES.WALL && attempts < maxAttempts);

                return { x, y };
            }
            
            const pos = findValidPosition();
            const newPoint = { 
                id: uuidv4(), 
                x: pos.x, 
                y: pos.y 
            };
            
            room.points.push(newPoint);
            console.log(`[RESPAWN] Room ${roomId}: New point ${newPoint.id} spawned at (${newPoint.x}, ${newPoint.y})`);
            
            // Notify all players
            broadcastToRoom(roomId, {
                type: "pointRespawn",
                point: newPoint
            });
        }
        
        // Schedule next respawn if game is still active
        if (room.gameStarted && room.gameTime > 0) {
            schedulePointRespawn(roomId);
        }
    }, 15000); // Respawn every 15 seconds
}
function startGameTimer(roomId) {
    const room = gameRooms[roomId];
    if (!room) return;
    
    // Clear existing timer if there is one
    if (room.timerInterval) {
        clearInterval(room.timerInterval);
    }
    
    room.timerInterval = setInterval(() => {
        if (!room.gamePaused && room.gameTime > 0) {
            room.gameTime--;
            //console.log(`[TIMER] Room ${roomId}: Game time left: ${room.gameTime}s`);
            broadcastToRoom(roomId, { type: "timer", gameTime: room.gameTime });
            
            // Game ended
            if (room.gameTime === 0) {
                broadcastToRoom(roomId, { 
                    type: "gameEnd", 
                    players: room.players 
                });
                clearInterval(room.timerInterval);
            }
        }
    }, 1000);
    
    // Start point respawning process
    schedulePointRespawn(roomId);
}
// ==== WebSocket Logic ====
wss.on('connection', (ws) => {
    const clientId = uuidv4();
    let currentRoomId = null;
    
    console.log(`[CONNECT] New client connected: ${clientId}`);
    
    // Send initial lobby state to new connection
    ws.send(JSON.stringify({
        type: "lobbyInit",
        clientId: clientId,
        availableRooms: Object.entries(gameRooms)
            .filter(([_, room]) => !room.gameStarted)
            .map(([id, room]) => ({
                id,
                playerCount: Object.keys(room.players).length,
                creatorName: Object.values(room.players).find(p => p.isCreator)?.name || "Unknown"
            }))
    }));

    ws.on('message', (msg) => {
        try {
            const data = JSON.parse(msg);
            
            switch (data.type) {
                case "createRoom":
                    // Player wants to create a new game room
                    const playerName = data.playerName || `Player-${clientId.slice(0, 6)}`;
                    const roomData = createGameRoom(clientId, playerName);
                    currentRoomId = roomData.roomId;
                    
                    // Store connection reference
                    gameRooms[currentRoomId].playerConnections[clientId] = ws;
                    
                    // Inform creator their room was created
                    ws.send(JSON.stringify({
                        type: "roomCreated",
                        roomId: currentRoomId,
                        isCreator: true,
                        terrainMap: roomData.terrainMap,
                        powerups: roomData.powerups,
                        points: roomData.points,
                        players: roomData.players
                    }));
                    
                    // Update lobby for all clients not in a room
                    wss.clients.forEach(client => {
                        if (client !== ws && client.readyState === WebSocket.OPEN && !client.roomId) {
                            client.send(JSON.stringify({
                                type: "roomAdded",
                                room: {
                                    id: currentRoomId,
                                    playerCount: 1,
                                    creatorName: playerName
                                }
                            }));
                        }
                    });
                    break;
                    
                    case "joinRoom":
                        const roomId = data.roomId;
                        const joinName = data.playerName || `Player-${clientId.slice(0, 6)}`;
                    
                        if (!gameRooms[roomId]) {
                            ws.send(JSON.stringify({ type: "error", message: "Room not found" }));
                            break;
                        }
                    
                        if (gameRooms[roomId].gameStarted) {
                            ws.send(JSON.stringify({ type: "error", message: "Game already in progress" }));
                            break;
                        }
                    
                        const playerCount = Object.keys(gameRooms[roomId].players).length;
                    
                        if (playerCount >= FIXED_SPAWN_POINTS.length) {
                            ws.send(JSON.stringify({ type: "error", message: "Room is full (max 4 players)" }));
                            break;
                        }

                        // Check for duplicate names
                        const isDuplicateName = Object.values(gameRooms[roomId].players).some(player => player.name === joinName);
                        if (isDuplicateName) {
                            ws.send(JSON.stringify({ type: "error", message: "A player with this name already exists in the room" }));
                            break;
                        }
                    
                        currentRoomId = roomId;
                        gameRooms[roomId].playerConnections[clientId] = ws;
                    
                        const spawnPoint = FIXED_SPAWN_POINTS[playerCount];
                    
                        gameRooms[roomId].players[clientId] = {
                            ...spawnPoint,
                            score: 0,
                            name: joinName,
                            isCreator: false,
                            activePowerups: {} // Add this line
                        };
                    
                        console.log(`[JOIN] Player ${joinName} (${clientId}) joined room ${roomId}`);
                    
                        ws.send(JSON.stringify({
                            type: "roomJoined",
                            roomId: roomId,
                            players: gameRooms[roomId].players,
                            isCreator: false
                        }));
                    
                        broadcastToRoom(roomId, {
                            type: "playerJoinedRoom",
                            playerId: clientId,
                            player: gameRooms[roomId].players[clientId]
                        });
                        break;
                    
                case "startGame":
                    // Only the creator can start the game
                    if (!currentRoomId || !gameRooms[currentRoomId]) {
                        ws.send(JSON.stringify({ type: "error", message: "Not in a valid room" }));
                        break;
                    }
                    
                    const room = gameRooms[currentRoomId];
                    if (clientId !== room.creatorId) {
                        ws.send(JSON.stringify({ type: "error", message: "Only the creator can start the game" }));
                        break;
                    }
                    
                    // Start the game
                    room.gameStarted = true;
                    startGameTimer(currentRoomId);
                    
                    console.log(`[START] Game started in room ${currentRoomId}`);
                    
                    // Inform all players in the room that the game has started
                    broadcastToRoom(currentRoomId, {
                        type: "gameStart",
                        players: room.players,
                        powerups: room.powerups,
                        points: room.points,
                        terrainMap: room.terrainMap,
                        gameTime: room.gameTime
                    });
                    break;
                    
                case "move":
                    if (!currentRoomId || !gameRooms[currentRoomId]) return;
                    const player = gameRooms[currentRoomId].players[clientId];
                    if (!player) return;
                    
                    player.x = data.x;
                    player.y = data.y;
                    broadcastToRoom(currentRoomId, { 
                        type: "stateUpdate", 
                        players: gameRooms[currentRoomId].players 
                    });
                    break;
                case "requestRooms":
                        // Send available rooms list to the requesting client
                        ws.send(JSON.stringify({
                            type: "lobbyInit",
                            clientId: clientId,
                            availableRooms: Object.entries(gameRooms)
                                .filter(([_, room]) => !room.gameStarted)
                                .map(([id, room]) => ({
                                    id,
                                    playerCount: Object.keys(room.players).length,
                                    creatorName: Object.values(room.players).find(p => p.isCreator)?.name || "Unknown"
                                }))
                        }));
                        break;
                        case "restartGame":
                            if (!currentRoomId || !gameRooms[currentRoomId]) return;
                            const room4 = gameRooms[currentRoomId];
                            
                            // Only creator can restart the game
                            if (clientId !== room4.creatorId) {
                                ws.send(JSON.stringify({ type: "error", message: "Only the creator can restart the game" }));
                                break;
                            }
                            
                            // Reset game state
                            console.log(`[RESTART] Room ${currentRoomId}: Game restarted by ${room4.players[clientId].name}`);
// Reset scores
Object.keys(room4.players).forEach(playerId => {
    room4.players[playerId].score = 0;
});
// Reset powerups status
Object.keys(room4.players).forEach(playerId => {
    room4.players[playerId].activePowerups = {};
});
// Reset positions
const playerIds = Object.keys(room4.players);
playerIds.forEach((playerId, index) => {
    const spawn = FIXED_SPAWN_POINTS[index] || { x: 1, y: 1 };
    room4.players[playerId].x = spawn.x;
    room4.players[playerId].y = spawn.y;
});

// Reset timer
room4.gameTime = 300;
if (room4.timerInterval) clearInterval(room4.timerInterval);

// Reset map objects
const { powerups, points } = generateMapObjects();
room4.powerups = powerups;
room4.points = points;

                            
                            // Unpause if paused
                            room4.gamePaused = false;
                            
                            // Restart timer
                            startGameTimer(currentRoomId);
                            
                            // Notify all players
                            broadcastToRoom(currentRoomId, {
                                type: "gameRestart",
                                players: room4.players,
                                powerups: room4.powerups,
                                points: room4.points,
                                gameTime: room4.gameTime
                            });
                            break;
                            case "collectPoint":
                                if (!currentRoomId || !gameRooms[currentRoomId]) return;
                                const room1 = gameRooms[currentRoomId];
                                const pointIndex = room1.points.findIndex(p => p.id === data.id);
                                
                                if (pointIndex !== -1) {
                                    room1.points.splice(pointIndex, 1);
                                    
                                    // Check if point multiplier is active
                                    let pointValue = 10;
                                    let multiplierActive = false;
                                    
                                    if (room1.players[clientId].activePowerups && 
                                        room1.players[clientId].activePowerups[POWERUP_TYPES.POINT_MULTIPLIER] && 
                                        room1.players[clientId].activePowerups[POWERUP_TYPES.POINT_MULTIPLIER].active) {
                                        pointValue = 20; // Double points
                                        multiplierActive = true;
                                    }
                                    
                                    room1.players[clientId].score += pointValue;
                                    
                                    console.log(`[POINT] Room ${currentRoomId}: ${clientId} collected point ${data.id} — Score: ${room1.players[clientId].score} ${multiplierActive ? '(with multiplier)' : ''}`);
                                    
                                    broadcastToRoom(currentRoomId, { 
                                        type: "collectPoint", 
                                        id: data.id, 
                                        playerId: clientId, 
                                        score: room1.players[clientId].score,
                                        pointValue: pointValue,
                                        multiplierActive: multiplierActive
                                    });
                                    
                                    // Schedule respawn for collected point
                                    schedulePointRespawn(currentRoomId);
                                }
                                break;

                            case "collectPowerup":
                                if (!currentRoomId || !gameRooms[currentRoomId]) return;
                                const room2 = gameRooms[currentRoomId];
                                const powerupIndex = room2.powerups.findIndex(p => p.id === data.id);
                                
                                if (powerupIndex !== -1) {
                                    const powerup = room2.powerups[powerupIndex];
                                    room2.powerups.splice(powerupIndex, 1);
                                    room2.players[clientId].score += 5;
                                    
                                    // Apply powerup effect based on type
                                    const powerupType = powerup.type;
                                    const duration = POWERUP_DURATIONS[powerupType];
                                    
                                    // Set active powerup
                                    room2.players[clientId].activePowerups[powerupType] = {
                                        active: true,
                                        expiresAt: Date.now() + (duration * 1000)
                                    };
                                    
                                    console.log(`[POWERUP] Room ${currentRoomId}: ${clientId} collected ${powerupType} powerup ${data.id} — Score: ${room2.players[clientId].score}`);
                                    
                                    broadcastToRoom(currentRoomId, { 
                                        type: "collectPowerup", 
                                        id: data.id, 
                                        playerId: clientId, 
                                        score: room2.players[clientId].score,
                                        powerupType: powerupType,
                                        duration: duration
                                    });
                                    
                                    // Schedule powerup expiration
                                    setTimeout(() => {
                                        if (!room2 || !room2.players[clientId]) return; // Player or room may be gone
                                        
                                        if (room2.players[clientId].activePowerups[powerupType]) {
                                            room2.players[clientId].activePowerups[powerupType] = { active: false };
                                            
                                            broadcastToRoom(currentRoomId, {
                                                type: "powerupExpired",
                                                playerId: clientId,
                                                powerupType: powerupType
                                            });
                                            
                                            console.log(`[POWERUP] Room ${currentRoomId}: ${powerupType} powerup expired for ${clientId}`);
                                        }
                                    }, duration * 1000);
                                }
                                break;
                case "togglePause":
                    if (!currentRoomId || !gameRooms[currentRoomId]) return;
                    const room3 = gameRooms[currentRoomId];
                    room3.gamePaused = !room3.gamePaused;
                    
                    console.log(`[PAUSE] Room ${currentRoomId}: Game paused: ${room3.gamePaused} by ${room3.players[clientId].name}`);
                    
                    broadcastToRoom(currentRoomId, {
                        type: "pauseState",
                        gamePaused: room3.gamePaused,
                        pausedBy: room3.players[clientId].name
                    });
                    break;
                    
                case "leaveRoom":
                    if (currentRoomId && gameRooms[currentRoomId]) {
                        handlePlayerLeave(clientId, currentRoomId);
                        currentRoomId = null;
                        
                        // Update client that they left
                        ws.send(JSON.stringify({
                            type: "roomLeft"
                        }));
                        
                        // Send available rooms list again
                        ws.send(JSON.stringify({
                            type: "lobbyInit",
                            clientId: clientId,
                            availableRooms: Object.entries(gameRooms)
                                .filter(([_, room]) => !room.gameStarted)
                                .map(([id, room]) => ({
                                    id,
                                    playerCount: Object.keys(room.players).length,
                                    creatorName: Object.values(room.players).find(p => p.isCreator)?.name || "Unknown"
                                }))
                        }));
                    }
                    break;
            }
        } catch (error) {
            console.error("Error processing message:", error);
        }
    });

    ws.on('close', () => {
        console.log(`[DISCONNECT] Client disconnected: ${clientId}`);
        
        if (currentRoomId && gameRooms[currentRoomId]) {
            handlePlayerLeave(clientId, currentRoomId);
        }
    });
    
    function handlePlayerLeave(playerId, roomId) {
        if (!gameRooms[roomId]) return;
        
        const playerName = gameRooms[roomId].players[playerId]?.name || "Unknown";
        const wasCreator = gameRooms[roomId].creatorId === playerId;
        
        console.log(`[LEAVE] Player ${playerName} (${playerId}) left room ${roomId}`);
        
        // Remove from connections and players
        delete gameRooms[roomId].playerConnections[playerId];
        delete gameRooms[roomId].players[playerId];
        
        // If room is now empty, clean it up
        if (Object.keys(gameRooms[roomId].players).length === 0) {
            console.log(`[CLEANUP] Room ${roomId} is empty, removing it`);
            if (gameRooms[roomId].timerInterval) {
                clearInterval(gameRooms[roomId].timerInterval);
            }
            delete gameRooms[roomId];
            
            // Notify lobby of room removal
            wss.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN && !client.roomId) {
                    client.send(JSON.stringify({
                        type: "roomRemoved",
                        roomId
                    }));
                }
            });
            return;
        }
        
        // Notify others in room that player left
        broadcastToRoom(roomId, {
            type: "playerLeftRoom",
            playerId
        });
        
        // If creator left, assign a new creator
        if (wasCreator) {
            const newCreatorId = Object.keys(gameRooms[roomId].players)[0];
            gameRooms[roomId].creatorId = newCreatorId;
            gameRooms[roomId].players[newCreatorId].isCreator = true;
            
            console.log(`[CREATOR] New creator in room ${roomId}: ${gameRooms[roomId].players[newCreatorId].name} (${newCreatorId})`);
            
            broadcastToRoom(roomId, {
                type: "newCreator",
                creatorId: newCreatorId,
                creatorName: gameRooms[roomId].players[newCreatorId].name
            });
        }
    }
});

// ==== Logging Game State ====
setInterval(() => {
    if (Object.keys(gameRooms).length === 0) return;
    
    console.log("[ROOMS]", Object.keys(gameRooms).length, "active rooms");
    
    Object.entries(gameRooms).forEach(([roomId, room]) => {
        const playerCount = Object.keys(room.players).length;
        if (playerCount === 0) return;
        
        console.log(`[ROOM ${roomId}] ${playerCount} players | Started: ${room.gameStarted} | Time left: ${room.gameTime}s`);
        
        if (room.gameStarted) {
            console.log(`[POSITIONS] Room ${roomId}:`);
            Object.entries(room.players).forEach(([id, p]) =>
                console.log(` - ${p.name} (ID: ${id}): (${p.x}, ${p.y}) | Score: ${p.score}`)
            );
        }
    });
}, 10000);

// ==== Server Startup ====
const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
    const ip = getLocalIpAddress();
    console.log(`Server running at http://${ip}:${PORT}`);
    console.log(`Players can connect to http://${ip}:${PORT}`);
});