const fs = require("fs");
const readline = require("readline");

// Initialize readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

// Function to ask for a key and save it to the .env file
const askForKey = (keyName) => {
  return new Promise((resolve) => {
    rl.question(`Enter ${keyName} key: `, (key) => {
      resolve(key.trim());
    });
  });
};

const updateEnvFile = async () => {
  const envFilePath = ".env";

  if (fs.existsSync(envFilePath)) {
    console.log(".env file exists. Reading keys from the file.");

    const envContent = fs.readFileSync(envFilePath, "utf-8");
    const envVars = envContent.split("\n").reduce((acc, line) => {
      const [key, value] = line.split("=");
      if (key && value) {
        acc[key.trim()] = value.trim();
      }
      return acc;
    }, {});

    console.log("Keys from .env file:");
    console.log(`RECEPTIONIST_KEY=${envVars.RECEPTIONIST_KEY}`);
    console.log(`OBSERVER_KEY=${envVars.OBSERVER_KEY}`);
    console.log(`SAFETY_KEY=${envVars.SAFETY_KEY}`);

    rl.close();
  } else {
    const receptionistKey = await askForKey("Receptionist");
    const observerKey = await askForKey("Observer");
    const safetyKey = await askForKey("Safety");

    // Read the .env file to update it
    let envContent = "";

    // Replace the existing keys with the new ones (if they exist)
    envContent += `RECEPTIONIST_KEY=${receptionistKey}\n`;
    envContent += `OBSERVER_KEY=${observerKey}\n`;
    envContent += `SAFETY_KEY=${safetyKey}\n`;

    // Write the updated content back to the .env file
    fs.writeFileSync(envFilePath, envContent, "utf-8");

    console.log("Keys have been updated in the .env file.");

    rl.close();
  }
};

// Start the process
updateEnvFile();
