const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const path = require("path");
require("dotenv").config();
const fs = require("fs");
const bodyParser = require("body-parser");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  allowRequest: (req, callback) => {
    const { key, role } = req._query;
    if (keys[role] === key) {
      callback(null, true);
    } else {
      callback("Invalid access key", false);
    }
  }
});
function sanitizeRaceData(race) {
  if (!race) return null;

  return {
    sessionId: race.sessionId,
    sessionName: race.sessionName,
    startTime: race.startTime,
    drivers: Array.isArray(race.drivers) ? race.drivers.map(driver => ({
      driverName: driver.driverName,
      carNumber: driver.carNumber
    })) : [],
    laps: Object.fromEntries(
      Object.entries(race.laps || {}).map(([key, value]) => [
        key,
        Array.isArray(value) ? value.slice() : []
      ])
    ),
    raceStatus: race.raceStatus || 'waiting',
    timer: race.timer || 0,
    flagStatus: race.flagStatus || 'danger'
  };
}

app.use(bodyParser.json());

// Environment-based security keys
const keys = {
  frontDesk: process.env.RECEPTIONIST_KEY,
  raceControl: process.env.SAFETY_KEY,
  lapLineTracker: process.env.OBSERVER_KEY,
};
// Serve static files (frontend)
app.use(express.static(path.join(__dirname, "public")));

// Path to the JSON file to store race data
const racesFilePath = path.join(__dirname, "races.json");

// Function to read races from the file
function readRacesFromFile() {
  if (fs.existsSync(racesFilePath)) {
    const data = fs.readFileSync(racesFilePath, "utf-8");
    return JSON.parse(data);
  }
  return [];
}
const RACE_DURATION = {
  development: 60, // 1 minute in seconds
  production: 600, // 10 minutes in seconds
};
function getRaceDuration() {
  return RACE_DURATION[process.env.NODE_ENV || "production"];
}
// Function to write races to races.json file
function writeRacesToFile(races) {
  const filePath = path.join(__dirname, "races.json");

  fs.writeFile(filePath, JSON.stringify(races, null, 2), (err) => {
    if (err) {
      console.error("Error writing to races.json:", err);
    } else {
      console.log("Successfully wrote updated races to races.json");
    }
  });
}

// Load the initial race data from the file
let races = readRacesFromFile();

// In-memory data to track race sessions
let currentRace = {
  startTime: null,
  sessionId: null,
  drivers: [],
  laps: {},
  raceStatus: "waiting", // Can be: waiting, started, hazard, danger, finished
  flagStatus: "safe", // Can be: safe, hazard, danger, finish
  timer: null,
  timerActive: false,
  timerInterval: null,
};

// Function to save the current race state to a file
function saveRaceState() {
  let raceState = {}

  if (currentRace.startTime !== null) {
    raceState = {
      ...currentRace,
      timerInterval: null, // Don't persist the interval reference
      timerActive: currentRace.timer > 0 && currentRace.timer !== getRaceDuration() ? true : false // Ensure timerActive is saved
    }
  }

  console.log(raceState)
  try {
    fs.writeFileSync("raceState.json", JSON.stringify(raceState, null, 2));
    console.log("Race state saved successfully.");
  } catch (err) {
    console.error("Error saving race state:", err);
  }
}

function raceFinished() {
  console.log("Race has finished!")
  currentRace.raceStatus = "finished";
  if (currentRace.timerInterval) {
    clearInterval(currentRace.timerInterval);
    currentRace.timerInterval = null;
  }
  currentRace.timer = 0; // Set the timer to 0
  currentRace.flagStatus = "finish"
  io.emit("currentRaceUpdated", currentRace);
  io.emit("timerUpdated", currentRace.timer);
  io.emit("raceFinished"); // Why its emiting tha same thing?

  // Clear the race state file when the race finishes
  clearRaceState();

  // Check for upcoming races
  const hasUpcomingRaces = races.some(race => race.raceStatus === "waiting");
  console.log("Has upcomming race: " + hasUpcomingRaces)
  io.emit("proceedToPaddock", hasUpcomingRaces);
}

function setTimerOn() {
  currentRace.timerInterval = setInterval(() => {
    if (currentRace.timer <= 0) {
      raceFinished()
    } else {
      currentRace.timer--;
      io.emit("timerUpdated", currentRace.timer);
    }
    console.log(currentRace.timer)
  }, 1000);
}

// Function to load the race state from a file
function loadRaceState() {
  try {
    if (fs.existsSync("raceState.json")) {
      const data = fs.readFileSync("raceState.json", "utf8");
      const savedState = JSON.parse(data);

      console.log(savedState.timerActive)
      console.log(savedState.startTime)

      // Restore the state but recalculate the timer if race was active
      if (savedState.timerActive && savedState.startTime) {
        const elapsedSeconds = Math.floor(
          (Date.now() - savedState.startTime) / 1000
        );
        savedState.timer = Math.max(0, getRaceDuration() - elapsedSeconds);
      }
      return savedState;
    }
  } catch (error) {
    console.error("Error loading race state:", error);
  }
  return null;
}

// Function to clear the race state file
function clearRaceState() {
  fs.writeFileSync("raceState.json", JSON.stringify({}), (err) => {
    if (err) console.error("Error clearing race state:", err);
  });
}

// Load the persisted race state on server startup
const savedState = loadRaceState();
if (savedState) {
  currentRace = { ...currentRace, ...savedState };
  if (currentRace.timerActive && currentRace.timer > 0) {
    // Restart the timer if it was active
    io.emit("currentRaceUpdated", sanitizeRaceData(currentRace))
    setTimerOn();
  } else if (currentRace.timerActive && currentRace.timer <= 0) {
    // Case where the timer has gone to 0 when the server started up again. 
    raceFinished();
  }
}

// Socket.IO connections
io.on("connection", (socket) => {
  console.log("New client connected");

  // Emit all the races when connecting
  socket.emit('currentRaceUpdated', sanitizeRaceData(currentRace));
  socket.emit("raceUpdated", races);

  // Add the new handler to send the current race ID when requested
  socket.on("requestCurrentRaceId", () => {
    if (currentRace.sessionId) {
      socket.emit("currentRaceId", currentRace.sessionId);
    }
  });

  function removeFinishedRace() {
    // Check if the current race is finished
    if (currentRace.raceStatus === "finished") {
      // Find the index of the race in the races array with the same sessionId as currentRace
      const currentRaceIndex = races.findIndex(race => race.sessionId === currentRace.sessionId);


      if (currentRaceIndex !== -1) {
        // Remove the race from the races array
        races.splice(currentRaceIndex, 1);
      }
      // Clear currentRace data as it is no longer in the races list
      currentRace = {
        startTime: null,
        sessionId: null,
        drivers: [],
        laps: {},
        raceStatus: "waiting",
        flagStatus: "danger",
        timer: getRaceDuration(),
        timerActive: false,
        timerInterval: null
      };

      // Write updated races to file
      writeRacesToFile(races);

      // Broadcast the updated race list and reset current race to all clients
      io.emit("raceUpdated", races);
      io.emit("currentRaceUpdated", sanitizeRaceData(currentRace));

    }

  }


  // If requested, send the currentRace
  socket.on("requestCurrentRaceData", () => {
    console.log("Current race:")
    console.log(currentRace)
    socket.emit("currentRaceUpdated", sanitizeRaceData(currentRace));
  });

  // Add a new race session
  socket.on("addRaceSession", (newSession) => {
    // Validation: Max 8 drivers
    if (newSession.drivers.length > 8) {
      socket.emit("validationError", "A race cannot have more than 8 drivers.");
      return;
    }

    // Validation: Check for duplicate names or car numbers
    const names = new Set();
    const carNumbers = new Set();
    for (const driver of newSession.drivers) {
      if (names.has(driver.driverName) || carNumbers.has(driver.carNumber)) {
        socket.emit(
          "validationError",
          "Driver names and car numbers must be unique."
        );
        return;
      }
      names.add(driver.driverName);
      carNumbers.add(driver.carNumber);
    }

    // Add the new race session if validation passes
    races.push(newSession);
    writeRacesToFile(races); // Save the updated race list
    io.emit("raceUpdated", races); // Broadcast the updated race list
  });

  // Edit an existing race session
  socket.on("editRaceSession", (updatedSession) => {
    // Replace the race object if the sessionId matches
    races = races.map((race) =>
      Number(race.sessionId) === Number(updatedSession.sessionId)
        ? updatedSession
        : race
    );

    // Write updated races to file
    writeRacesToFile(races);
    io.emit("raceUpdated", races); // Broadcast the updated race list
  });

  // Remove a race session
  socket.on("removeRaceSession", (sessionId) => {
    // Filter out the race with the matching sessionId
    races = races.filter(
      (race) => Number(race.sessionId) !== Number(sessionId)
    );

    writeRacesToFile(races); // Save updated race data
    io.emit("raceUpdated", races); // Broadcast the updated race list
  });

  // Update race order
  socket.on("updateRaceOrder", (updatedRaces) => {
    races = updatedRaces; // Update the in-memory races array
    writeRacesToFile(races); // Save the updated race list to the file
    io.emit("raceUpdated", races); // Broadcast the updated race list
  });


  // For race updates
  socket.on("startRace", () => {
    setCurrentRace(races[0].sessionId);
    currentRace.raceStatus = "started";
    currentRace.flagStatus = "safe";
    currentRace.startTime = Date.now();
    currentRace.timer = process.env.NODE_ENV === "development" ? 60 : 600; // 1 or 10 minutes
    io.emit("currentRaceUpdated", sanitizeRaceData(currentRace));
    io.emit("clearLeaderboard", sanitizeRaceData(currentRace));
    setTimerOn();
  });

  // Lap-line observer submits lap times, leaderboard listens to lapTimeUpdated emit
  socket.on("recordLap", (carNumber) => {
    console.log("Lap recored CAR: " + carNumber + " LAP TIME: " + Date.now())
    if (!currentRace.laps[carNumber]) currentRace.laps[carNumber] = [];
    currentRace.laps[carNumber].push(Date.now());
    io.emit("lapTimesUpdated", sanitizeRaceData(currentRace));
  });

  socket.on("changeRaceMode", (mode) => {
    console.log("Current race racemode changed to " + mode)
    if (["safe", "hazard", "danger", "finish"].includes(mode)) {
      if (mode === 'finish') {
        clearInterval(currentRace.timerInterval)
      }
      switch (mode) {
        case 'safe':
          currentRace.raceStatus = 'started'
          break;
        case 'hazard':
          currentRace.raceStatus = 'hazard'
          break;
        case 'dange':
          currentRace.raceStatus = 'danger'
          break;
        case 'finish':
          currentRace.raceStatus = 'finished';
          break;
        default:
          break;
      }
      currentRace.flagStatus = mode;
      io.emit("raceModeUpdated", currentRace.flagStatus);
      io.emit("currentRaceUpdated", sanitizeRaceData(currentRace));
    }
  });

  socket.on("endRaceSession", () => {
    removeFinishedRace();
  });

  // Race control emits raceFinished
  socket.on("raceFinished", () => {
    raceFinished();
  });

  function setCurrentRace(raceSessionID) {
    const selectedRace = races.find((race) => race.sessionId === raceSessionID);
    if (selectedRace) {
      currentRace = sanitizeRaceData({
        ...selectedRace,
        raceStatus: "waiting",
        laps: {},
        timer: 0,
        flagStatus: "danger",
        startTime: null,
      });
      io.emit("currentRaceUpdated", sanitizeRaceData(currentRace));
      io.emit("currentRaceId", currentRace.sessionId); // Emit the current race ID
    }
  }

  // Handle disconnection
  socket.on("disconnect", () => {
    if (currentRace.timerInterval) {
      // Don't clear the interval on disconnect - race might still be ongoing
      // Just persist the state
      saveRaceState();
    }
    console.log("Client disconnected");
  });

  // THis should sent the races data only.
  socket.on("askRaceData", () => {
    io.emit("sendRaceDataReq", sanitizeRaceData(currentRace));
    io.emit("currentRaceId", currentRace.sessionId); // Emit the current race ID
    io.emit("currentRaceUpdated", sanitizeRaceData(currentRace));
  });
});

// Validation route for access key
app.post("/validate-key", (req, res) => {
  const { key, role } = req.body;

  if (!key || !role) {
    return res.status(400).json({ success: false, message: "Missing key or role" });
  }

  // Validate the provided key against the environment variable
  if (keys[role] === key) {
    return res.json({ success: true, socketUrl: `ws://${req.headers.host}` });
  } else {
    return setTimeout(() => {
      res.json({ success: false, message: 'Invalid access key. Please try again.' });
    }, 500);
  }
});
// Routes to serve pages
app.get("/front-desk", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "front-desk.html"));
});

app.get("/race-control", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "race-control.html"));
});

app.get("/lap-line-tracker", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "lap-line-tracker.html"));
});

// Public interfaces (no security required)
app.get("/leader-board", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "leaderboard.html"));
});

app.get("/next-race", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "next-race.html"));
});

app.get("/race-flags", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "race-flags.html"));
});
app.get("/race-countdown", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "race-countdown.html"));
});

// Save the race state on server crash
process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err);
  saveRaceState();
  process.exit(1); // Exit the process after saving the state
});

process.on("SIGTERM", () => {
  saveRaceState();
  process.exit(0);
});

process.on("SIGINT", () => {
  saveRaceState();
  process.exit(0);
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
