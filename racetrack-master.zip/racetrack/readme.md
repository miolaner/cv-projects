# Racetrack Info-Screens

Beachside Racetrack's **Racetrack Info-Screens** project delivers a real-time system for managing race operations and keeping spectators informed. This MVP solution empowers employees to efficiently control race sessions and provides guests and drivers with instant updates.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Environment Variables](#environment-variables)
3. [Starting the Server](#starting-the-server)
4. [User Guide](#user-guide)
   - [Interfaces Overview](#interfaces-overview)
   - [Receptionist Interface](#receptionist-interface)
   - [Safety Official Interface](#safety-official-interface)
   - [Lap-line Observer Interface](#lap-line-observer-interface)
   - [Public Displays](#public-displays)
5. [Technology Stack](#technology-stack)
6. [Extra Features](#extra-features)
7. [Using ngrok](#using-ngrok)

---

## Getting Started

This system requires **Node.js**, **npm**, and **Socket.IO**. Follow the steps below to set up the project:

1. Clone the repository:
```bash
git clone <repository-url>
cd racetrack-info-screens
```
2. Install dependencies:

```bash
npm install
```

3. Set the required environment variables as described below.

## Environment Variables

Before starting the server, define the following environment variables to secure the employee interfaces:

- receptionist_key: Access key for the Front Desk interface.
- observer_key: Access key for the Lap-line Tracker interface.
- safety_key: Access key for the Race Control interface.

Keys are stored in .env file on the root of the server. Change them as you need feel like. 

If any of these keys are not set, the server will not start.

## Starting the Server

Start the server in production or development mode:

Production mode:

```bash
npm start
```

In this mode, each race session lasts 10 minutes.

Development mode:

```bash
npm run dev
```

In this mode, race sessions last 1 minute for faster testing.

Access the interfaces at the following routes (replace <host> with your server's URL or IP):

- /front-desk: Receptionist Interface
- /race-control: Safety Official Interface
- /lap-line-tracker: Lap-line Observer Interface
- /leader-board: Spectator Leaderboard
- /next-race: Next Race Information
- /race-countdown: Countdown Display
- /race-flags: Flag Display

## User Guide

### Interfaces Overview

Each interface is optimized for specific personas to streamline race operations and enhance guest experience. All interfaces react in real-time using Socket.IO.

Receptionist Interface (/front-desk)

#### Access

- Use the Receptionist Key to log in.
- Accessible via any static computer.

#### Features

- View, add, remove, and edit upcoming race sessions.
- Assign drivers to race cars (manual or automatic allocation).
- Display a list of drivers for the next race session.

#### Example Usage

- Log in with the receptionist key.
- Add a new race session and assign drivers.
- Save changes to update the schedule in real-time.

## Safety Official Interface (/race-control)

#### Access

- Use the Safety Key to log in.
- Accessible via portable devices.

#### Features

- Start and stop race sessions.
- Switch between race modes (Safe, Hazard, Danger, Finish).
- End race sessions to queue up the next race.

#### Example Usage

- Log in with the safety key.
- Start a race by pressing the Start Race button.
- Use race mode buttons to control safety instructions.
- End the session once all cars have returned to the pit lane.

## Lap-line Observer Interface (/lap-line-tracker)

#### Access

- Use the Observer Key to log in.
- Accessible via tablets.

#### Features

- Large tappable buttons for recording lap times.
- Disable buttons after the race concludes.

#### Example Usage

- Log in with the observer key.
- Press the corresponding button as each car crosses the lap line.
- View real-time lap times on the leaderboard.

## Public Displays

#### Leaderboard (/leader-board)

- Displays the current race session’s fastest lap times.
- Shows race time remaining and flag status.

#### Next Race (/next-race)

- Displays the list of drivers and assigned cars for the next session.
- Updates in real-time when the session is configured.

#### Race Countdown (/race-countdown)

- Displays a countdown timer for the ongoing race session.

Each public screen contains Fullscreen button. When entering fullscreen, the button disappears.
Exit fullscreen by hitting ESC key on your keyboard.

#### Race Flags (/race-flags)

- Displays the current race mode as a full-screen flag:
  - Safe: Solid green.
  - Hazard: Solid yellow.
  - Danger: Solid red.
  - Finish: Chequered black/white.

## Technology Stack

- Backend: Node.js with Express.js.
- Frontend: Good old JavaScript.
- Real-time Communication: Socket.IO.

## Extra Features

#### Data Persistence

- Persist race data to maintain state across server restarts. Data is stored in a local file called raceState.json. 

#### Manual Car Assignment

- Receptionists can assign specific cars to drivers instead of relying on automatic assignment.

## Using ngrok

If you want other people get access to your server, you can do it by installing ngork. and sharing the public link to everybody you wish.


### Installation

Linux: 
```bash
curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | \
  sudo gpg --dearmor -o /etc/apt/keyrings/ngrok.gpg && \
  echo "deb [signed-by=/etc/apt/keyrings/ngrok.gpg] https://ngrok-agent.s3.amazonaws.com buster main" | \
  sudo tee /etc/apt/sources.list.d/ngrok.list && \
  sudo apt update && sudo apt install ngrok
```

Mac OS:
```bash
brew install ngrok/ngrok/ngrok
```

Windows:
```bash
choco install ngrok
```

### Adding authtoken

Make account with ngrok from here: 
https://dashboard.ngrok.com/login

then copy the authtoken and insert that to your ngrok installation with this command.

```bash
ngrok config add-authtoken <TOKEN>
```

### Using ngrok

Start the server on your local system first with

```bash
npm start
```

and make the server public with

```bash
ngrok http http://localhost:3000
```

After this, ngrok CLI will give you the public URL which you can send to anybody with whom you want to share your server!