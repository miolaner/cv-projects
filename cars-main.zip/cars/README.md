# Car Models Web Application

## Overview
This is a web application that lets users browse through a collection of car models, view details about them, and compare selected models. Users can also filter cars by manufacturer and category. Additionally, there's a feedback submission feature for users to provide their opinions about the application.

## Components

### Server-Side (Go/Express)
- **Server File (`server.go`)**:
  - Initializes the HTTP server.
  - Defines API endpoints for car models, manufacturers, categories, and feedback.
  - Loads sample data from the API server.
  - Handles error responses, CORS configuration, and static file serving.

  - **API server (`api`)**:
  - Creates the JSON server.
  - Defines API endpoints for car models, manufacturers and categories.
  - Server logic in file "main.js"

### Client-Side (HTML, CSS, JavaScript)
- **HTML File (`index.html`)**:
  - Defines the structure of the web page.
  - Contains elements for displaying car models, search input, filters, feedback form, and comparison modal.

- **CSS File (`styles.css`)**:
  - Defines styles for various HTML elements to ensure a visually appealing layout.
  - Provides responsiveness for different screen sizes using media queries.

- **JavaScript File (`script.js`)**:
  - Handles client-side logic such as fetching data from the server, filtering car models, displaying car details, handling feedback submission, and comparison functionality.
  - Dynamically populates dropdown menus for filters based on available manufacturers and categories.
  - Implements event listeners for user interactions like selecting cars, submitting feedback, and displaying comparison details.

## Features
- **Display Car Models**: Users can view a list of car models with their details including name, year, manufacturer, and category.
- **Filtering**: Users can filter car models based on manufacturer and category to narrow down their search.
- **Comparison**: Users can select multiple cars and compare their details in a modal popup.
- **Feedback Submission**: Users can submit feedback about the application via a form.
- **Dynamic CSS For Mobile**: When used on mobile (or simulated on chrome terminal), UI stays usable.

## How to Run
1. Make sure Go is installed on your machine.
2. Clone the repository containing the source code.
3. Navigate to the project directory in your terminal.
4. Navigate to folder "api" in the project.
5. Make sure "express" is installed.
6. Run command "node main.js".
7. Open another terminal.
8. Run `go run server.go` to start the server.
9. Open a web browser and go to `http://localhost:8080` to access the application.

## Future Improvements
- Implement user authentication for personalized features.
- Enhance error handling and logging for better debugging.
- Optimize data loading and processing for scalability.
- Save feedback to actual server, currently its saved in file "feedback.txt"
- improve the more info / comparison UI