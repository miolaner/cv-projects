package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
    "os"
	"sync"
)

// Define global variables for car models, categories, and manufacturers
var (
	carModels     []CarModel
	categories    []Category
	manufacturers []Manufacturer
)

// Define structs for data types
type CarModel struct {
	ID             int         `json:"id"`
	Name           string      `json:"name"`
	ManufacturerID int         `json:"manufacturerId"`
	CategoryID     int         `json:"categoryId"`
	Year           int         `json:"year"`
	Specifications Specifications `json:"specifications"`
	Image          string      `json:"image"`
}

type Specifications struct {
	Engine       string `json:"engine"`
	Horsepower   int    `json:"horsepower"`
	Transmission string `json:"transmission"`
	Drivetrain   string `json:"drivetrain"`
}


type Category struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
	// Add other fields as needed
}

type Manufacturer struct {
	ID            int    `json:"id"`
	Name          string `json:"name"`
	Country       string `json:"country"`
	FoundingYear  int    `json:"foundingYear"`
	// Add other fields as needed
}

// Load data from API endpoints concurrently
func loadDataConcurrently(apiURL string, endpoints map[string]string) {
	var wg sync.WaitGroup
	wg.Add(len(endpoints))

	for key, endpoint := range endpoints {
		go func(key, endpoint string) {
			defer wg.Done()
			resp, err := http.Get(apiURL + endpoint)
			if err != nil {
				log.Fatalf("Error fetching data from %s: %v", key, err)
				return
			}
			defer resp.Body.Close()

			switch key {
			case "models":
				if err := json.NewDecoder(resp.Body).Decode(&carModels); err != nil {
					log.Fatalf("Error decoding car models data: %v", err)
				}
			case "categories":
				if err := json.NewDecoder(resp.Body).Decode(&categories); err != nil {
					log.Fatalf("Error decoding categories data: %v", err)
				}
			case "manufacturers":
				if err := json.NewDecoder(resp.Body).Decode(&manufacturers); err != nil {
					log.Fatalf("Error decoding manufacturers data: %v", err)
				}
			}
		}(key, endpoint)
	}

	wg.Wait()
}

// Define handler functions
func carModelsHandler(w http.ResponseWriter, r *http.Request) {
	
		json.NewEncoder(w).Encode(carModels)
	}

func carModelByIDHandler(w http.ResponseWriter, r *http.Request) {
	// Extract car model ID from URL path
	idStr := strings.TrimPrefix(r.URL.Path, "/api/models/")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid car model ID", http.StatusBadRequest)
		return
	}

	// Find the car model by ID
	for _, model := range carModels {
		if model.ID == id {
			json.NewEncoder(w).Encode(model)
			return
		}
	}

	// If car model not found, return 404 status
	http.Error(w, "Car model not found", http.StatusNotFound)
}

func categoriesHandler(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(categories)
}
func feedbackHandler(w http.ResponseWriter, r *http.Request) {
    // Allow only POST requests
    if r.Method != http.MethodPost {
        http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
        return
    }

    // Decode the JSON data from the request body into a struct
    var feedback struct {
        Feedback string `json:"feedback"`
    }
    if err := json.NewDecoder(r.Body).Decode(&feedback); err != nil {
        http.Error(w, "Failed to decode request body", http.StatusBadRequest)
        return
    }

    // Log the feedback
    log.Printf("Received feedback: %s\n", feedback.Feedback)

    // Write the feedback to a file
    file, err := os.OpenFile("feedback.txt", os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0644)
    if err != nil {
        log.Printf("Error opening file: %v", err)
        http.Error(w, "Internal Server Error", http.StatusInternalServerError)
        return
    }
    defer file.Close()

    if _, err := file.WriteString(feedback.Feedback + "\n"); err != nil {
        log.Printf("Error writing to file: %v", err)
        http.Error(w, "Internal Server Error", http.StatusInternalServerError)
        return
    }

    // Send a response indicating successful submission
    w.WriteHeader(http.StatusOK)
    w.Write([]byte("Feedback submitted successfully"))
}
func categoryByIDHandler(w http.ResponseWriter, r *http.Request) {
	// Extract category ID from URL path
	idStr := strings.TrimPrefix(r.URL.Path, "/api/categories/")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid category ID", http.StatusBadRequest)
		return
	}

	// Find the category by ID
	for _, category := range categories {
		if category.ID == id {
			json.NewEncoder(w).Encode(category)
			return
		}
	}

	// If category not found, return 404 status
	http.Error(w, "Category not found", http.StatusNotFound)
}

func manufacturersHandler(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(manufacturers)
}

func manufacturerByIDHandler(w http.ResponseWriter, r *http.Request) {
	// Extract manufacturer ID from URL path
	idStr := strings.TrimPrefix(r.URL.Path, "/api/manufacturers/")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid manufacturer ID", http.StatusBadRequest)
		return
	}

	// Find the manufacturer by ID
	for _, manufacturer := range manufacturers {
		if manufacturer.ID == id {
			json.NewEncoder(w).Encode(manufacturer)
			return
		}
	}

	// If manufacturer not found, return 404 status
	http.Error(w, "Manufacturer not found", http.StatusNotFound)
}

func serveImageHandler(w http.ResponseWriter, r *http.Request) {
	// Extract the image filename from the URL
	imagePath := strings.TrimPrefix(r.URL.Path, "/api/images/")
	// Construct the path to the image file
	imageFile := filepath.Join("api/img", imagePath)

	// Use a buffered channel to communicate image data
	imageDataChan := make(chan []byte, 1)
	errorChan := make(chan error, 1)

	// Start a goroutine to read the image file concurrently
	go func() {
		// Read the image file
		image, err := os.ReadFile(imageFile)
		if err != nil {
			errorChan <- err
			return
		}

		// Send the image data to the channel
		imageDataChan <- image
	}()

	// Wait for either the image data or an error
	select {
	case imageData := <-imageDataChan:
		// Set the appropriate content type header
		contentType := http.DetectContentType(imageData)
		w.Header().Set("Content-Type", contentType)

		// Write the image data to the response
		w.Write(imageData)
	case err := <-errorChan:
		// If an error occurred while reading the image file, return a 404 status
		http.Error(w, "Image not found", http.StatusNotFound)
		log.Println("Error serving image:", err)
	}
}


// Main function
func main() {
	apiURL := "http://localhost:3000" // Change the URL accordingly
	endpoints := map[string]string{
		"models":       "/api/models",
		"categories":   "/api/categories",
		"manufacturers": "/api/manufacturers",
	}

	// Load data from API endpoints concurrently
	loadDataConcurrently(apiURL, endpoints)

	// Define routes and handlers
	http.HandleFunc("/api/models", carModelsHandler)
	http.HandleFunc("/api/models/", carModelByIDHandler)
	http.HandleFunc("/api/categories", categoriesHandler)
	http.HandleFunc("/api/categories/", categoryByIDHandler)
	http.HandleFunc("/api/manufacturers", manufacturersHandler)
	http.HandleFunc("/api/manufacturers/", manufacturerByIDHandler)
	http.HandleFunc("/api/images/", serveImageHandler)
    http.HandleFunc("/api/submit-feedback", feedbackHandler)


    fs := http.FileServer(http.Dir("./public"))
    http.Handle("/", fs)
    http.HandleFunc("/styles.css", func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "text/css")
        http.ServeFile(w, r, "./public/styles.css")
    })
	// Start the server
	fmt.Println("Server is running on port 8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}