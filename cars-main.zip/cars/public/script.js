let carModels; // Declare carModels globally
let manufacturers; // Declare manufacturers globally
let categories; // Declare categories globally

document.addEventListener("DOMContentLoaded", function() {
    Promise.all([
        fetch("/api/models").then(response => response.json()),
        fetch("/api/manufacturers").then(response => response.json()),
        fetch("/api/categories").then(response => response.json())
    ])
    .then(data => {
        carModels = data[0]; // Assign data to carModels
        manufacturers = data[1]; // Assign data to manufacturers
        categories = data[2]; // Assign data to categories

        console.log("Car models data:", carModels);
        console.log("Manufacturers data:", manufacturers);
        console.log("Categories data:", categories);

        const carContainer = document.getElementById("carContainer");

        // Populate manufacturer filter dropdown
        const manufacturerFilter = document.getElementById("manufacturerFilter");
        manufacturers.forEach(manufacturer => {
            const option = document.createElement("option");
            option.value = manufacturer.id;
            option.textContent = manufacturer.name;
            manufacturerFilter.appendChild(option);
        });

        // Populate category filter dropdown
        const categoryFilter = document.getElementById("categoryFilter");
        categories.forEach(category => {
            const option = document.createElement("option");
            option.value = category.id;
            option.textContent = category.name;
            categoryFilter.appendChild(option);
        });

        // Filter cars when dropdowns are changed
        manufacturerFilter.addEventListener("change", filterCars);
        categoryFilter.addEventListener("change", filterCars);

        // Display all cars initially
        displayCars(carModels, carContainer);
    })
    .catch(error => {
        console.error("Error fetching data:", error);
        displayErrorMessage("Failed to fetch data. Please try again later.");
    });
});

document.getElementById("compareBtn").addEventListener("click", compareSelectedCars);

// Add event listener to feedback form
const feedbackForm = document.getElementById("feedbackForm");

feedbackForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    const feedbackTextarea = document.getElementById("feedback");
    const feedback = feedbackTextarea.value.trim(); // Get the feedback value

    if (feedback === "") {
        alert("Please enter your feedback.");
        return;
    }

    const endpoint = "/api/submit-feedback"; // Define the endpoint to submit feedback

    // Create an object to hold the feedback data
    const feedbackData = {
        feedback: feedback
    };

    // Send a POST request to the server with JSON data
    fetch(endpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(feedbackData)
    })
    .then(response => {
        if (response.ok) {
            feedbackTextarea.value = ""; // Clear the feedback textarea
            alert("Feedback sent successfully!");
        } else {
            throw new Error("Failed to submit feedback.");
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Failed to submit feedback. Please try again later.");
    });
});

function filterCars() {
    const manufacturerFilterValue = document.getElementById("manufacturerFilter").value;
    const categoryFilterValue = document.getElementById("categoryFilter").value;

    const filteredCars = carModels.filter(car => {
        return (manufacturerFilterValue === "" || car.manufacturerId === parseInt(manufacturerFilterValue)) &&
               (categoryFilterValue === "" || car.categoryId === parseInt(categoryFilterValue));
    });

    const carContainer = document.getElementById("carContainer");
    displayCars(filteredCars, carContainer);
}

function displayCars(cars, container) {
    // Clear existing car cards
    container.innerHTML = "";

    cars.forEach(car => {
        // Create a card element for each car model
        const card = createCarCard(car);
        container.appendChild(card);
    });
}

function createCarCard(car) {
    // Create card elements
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.id = car.id; // Set dataset id to car id
    card.dataset.manufacturerId = car.manufacturerId; // Add data attribute for manufacturer ID
    card.dataset.categoryId = car.categoryId; // Add data attribute for category ID

    // Add checkbox
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    card.appendChild(checkbox);

    // Add image (if available)
    if (car.image) {
        const img = document.createElement("img");
        // Construct the correct image URL
        img.src = `/api/images/${car.image}`;
        img.alt = car.name;
        card.appendChild(img);
    }

    // Get manufacturer's information based on manufacturerId
    const manufacturer = manufacturers.find(m => m.id === car.manufacturerId); // Use global manufacturers variable
    const manufacturerInfo = manufacturer
        ? `${manufacturer.name} (${manufacturer.country}, founded in ${manufacturer.foundingYear})`
        : 'Unknown';

    // Get category's name based on categoryId
    const category = categories.find(c => c.id === car.categoryId); // Use global categories variable
    const categoryName = category ? category.name : 'Unknown';

    // Add car details
    const details = document.createElement("div");
    details.classList.add("details");
    details.innerHTML = `
        <h2>${car.name}</h2>
        <p>Year: ${car.year}</p>
        <p>Manufacturer: ${manufacturerInfo}</p>
        <p>Category: ${categoryName}</p>
    `;
    card.appendChild(details);

    return card;
}

function compareSelectedCars() {
    const selectedCars = Array.from(document.querySelectorAll("#carContainer .card input[type=checkbox]:checked"))
                             .map(checkbox => checkbox.closest(".card"));
    if (selectedCars.length < 1) {
        alert("Please select at one car to show more info, or at least two cars to compare them.");
        return;
    }

    // Extract car IDs for comparison
    const carIds = selectedCars.map(car => car.dataset.id);

    // Retrieve car details for the selected IDs
    const selectedCarsDetails = carModels.filter(car => carIds.includes(String(car.id)));

    // Generate comparison details HTML
    const comparisonHTML = selectedCarsDetails.map(car => {
        // Find manufacturer information
        const manufacturer = manufacturers.find(m => m.id === car.manufacturerId);
        const manufacturerInfo = manufacturer
            ? `${manufacturer.name} (${manufacturer.country}, founded in ${manufacturer.foundingYear})`
            : 'Unknown';

        // Check if specifications are available for the car
        const specificationsInfo = car.specifications
            ? `
                <p>Engine: ${car.specifications.engine}</p>
                <p>Horsepower: ${car.specifications.horsepower}</p>
                <p>Transmission: ${car.specifications.transmission}</p>
                <p>Drivetrain: ${car.specifications.drivetrain}</p>
              `
            : '<p>Specifications not available</p>';

        // Construct the comparison details HTML
        return `
            <div class="car-comparison">
                <h3>${car.name}</h3>
                <p>Manufacturer: ${manufacturerInfo}</p>
                <p>Year: ${car.year}</p>
                <div class="specifications">
                    <h4>Specifications</h4>
                    ${specificationsInfo}
                </div>
                <!-- Add more details as needed -->
            </div>
        `;
    }).join('');

    // Populate comparison modal with HTML
    const comparisonModal = document.getElementById('comparisonModal');
    const comparisonDetails = document.getElementById('comparisonDetails');
    comparisonDetails.innerHTML = comparisonHTML;

    // Show the modal
    comparisonModal.style.display = 'block';

    // Close the modal when the user clicks on the close button
    const closeModal = document.querySelector('.close');
    closeModal.onclick = function() {
        comparisonModal.style.display = 'none';
    }

    // Close the modal when the user clicks anywhere outside of it
    window.onclick = function(event) {
        if (event.target == comparisonModal) {
            comparisonModal.style.display = 'none';
        }
    }
}


// Function to handle search logic
function handleSearch() {
    const searchQuery = document.getElementById("searchInput").value.toLowerCase();
    const filteredCars = carModels.filter(car => {
        // Check if the car name, manufacturer name, or category name contains the search query
        return car.name.toLowerCase().includes(searchQuery) ||
               manufacturers.find(m => m.id === car.manufacturerId).name.toLowerCase().includes(searchQuery) ||
               categories.find(c => c.id === car.categoryId).name.toLowerCase().includes(searchQuery);
    });

    // Display the filtered cars
    displayCars(filteredCars, document.getElementById("carContainer"));
}

// Event listener for search input changes
document.getElementById("searchInput").addEventListener("input", handleSearch);

function displayErrorMessage(message) {
    // Display an error message to the user
    const errorContainer = document.getElementById("errorContainer");
    errorContainer.textContent = message;
    errorContainer.style.display = "block"; // Make the error message visible
}